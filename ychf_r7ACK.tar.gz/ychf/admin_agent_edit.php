<?php
// admin_agent_edit.php - 人员编辑 (v2.4: 终极修复白屏与CDN问题)
session_start();
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>人员档案编辑</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">

    <script src="https://cdn.staticfile.org/vue/3.3.4/vue.global.prod.min.js"></script>
    
    <link href="https://cdn.staticfile.org/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        body { background: #f8fafc; font-family: sans-serif; }
        .search-res-item { @apply px-3 py-2 border-b cursor-pointer hover:bg-blue-50 text-xs flex justify-between items-center transition; }
        .search-res-item.added { @apply bg-gray-50 text-gray-400 cursor-default hover:bg-gray-50; }
        
        .selected-tag { @apply bg-blue-100 text-blue-700 px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1 border border-blue-200 animate-[fadeIn_0.2s_ease-out]; }
        .selected-tag i { @apply cursor-pointer hover:text-red-500 opacity-50 hover:opacity-100 transition; }
        
        @keyframes fadeIn { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }
        /* 避免未加载完时的闪烁 */
        [v-cloak] { display: none; }
    </style>
</head>
<body class="p-6">
<div id="app" class="max-w-xl mx-auto bg-white rounded-xl shadow-2xl p-6" v-cloak>
    <div class="flex justify-between items-center mb-6 border-b pb-4">
        <h1 class="text-xl font-bold text-slate-800">{{ form.id ? '编辑人员' : '新增人员' }}</h1>
        <button @click="closeWin" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
    </div>

    <div class="space-y-5 h-[600px] overflow-y-auto pr-2">
        <div class="grid grid-cols-2 gap-4">
            <div><label class="block text-xs font-bold text-gray-500 mb-1">姓名</label><input v-model="form.username" class="w-full border rounded p-2 text-sm focus:ring-2 focus:ring-blue-100 outline-none"></div>
            <div><label class="block text-xs font-bold text-gray-500 mb-1">手机号</label><input v-model="form.phone" class="w-full border rounded p-2 text-sm focus:ring-2 focus:ring-blue-100 outline-none"></div>
        </div>
        
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-xs font-bold text-gray-500 mb-1">归属部门</label>
                <select v-model="form.department_id" class="w-full border rounded p-2 text-sm bg-white">
                    <option :value="0">-- 未分配 --</option>
                    <template v-for="d in flatDepts" :key="d.id">
                        <option :value="d.id">{{ d.name }}</option>
                    </template>
                </select>
            </div>
            <div>
                <label class="block text-xs font-bold text-gray-500 mb-1">系统角色</label>
                <select v-model="form.role" class="w-full border rounded p-2 text-sm bg-white">
                    <option value="channel">渠道经纪人</option>
                    <option value="staff">案场人员</option>
                    <option value="finance">财务</option>
                    <option value="admin">管理员</option>
                </select>
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-xs font-bold text-gray-500 mb-1">上级经理</label>
                <select v-model="form.manager_id" class="w-full border rounded p-2 text-sm bg-white">
                    <option :value="0">-- 无上级 --</option>
                    <template v-for="agent in allAgents" :key="agent ? agent.id : 'null'">
                        <option v-if="agent && agent.id != (form.id || 0)" :value="agent.id">
                            {{ agent.username }} ({{ agent.dept_name || '未分配' }})
                        </option>
                    </template>
                </select>
            </div>
        </div>

        <div>
            <label class="block text-xs font-bold text-gray-500 mb-1">登录密码</label>
            <input v-model="form.password" class="w-full border rounded p-2 text-sm" placeholder="默认: 123456">
        </div>



    </div>

    <div class="flex justify-end gap-3 mt-4 pt-4 border-t">
        <button @click="closeWin" class="px-6 py-2 border rounded text-sm text-gray-600 hover:bg-gray-50">取消</button>
        <button @click="save" class="px-6 py-2 bg-indigo-600 text-white rounded text-sm hover:bg-indigo-700 shadow-lg">保存配置</button>
    </div>
</div>

<script>
const { createApp, ref, onMounted, computed } = Vue;
createApp({
    setup() {
        const form = ref({
            id: '', username: '', phone: '', department_id: 0, role: 'channel', password: '123456', manager_id: 0
        });
        const departments = ref([]);
        const allAgents = ref([]);
        const id = new URLSearchParams(window.location.search).get('id');

        // 扁平化部门 (防崩处理)
        const flatDepts = computed(() => {
            const list = [];
            const traverse = (nodes, prefix='') => {
                if(!nodes || !Array.isArray(nodes)) return;
                for(let node of nodes) {
                    if(node) {
                        list.push({id: node.id, name: prefix + node.name});
                        if(node.children) traverse(node.children, prefix + '-- ');
                    }
                }
            };
            traverse(departments.value);
            return list;
        });

        const loadData = async () => {
            try {
                // 加载基础数据
                const resInit = await fetch('api.php?action=get_structure');

                // 安全解析
                let dataInit = {};
                
                if(resInit.ok) dataInit = await resInit.json();

                // 强制转为数组，防止 null
                departments.value = Array.isArray(dataInit.departments) ? dataInit.departments : [];
                
                // 过滤掉 null 的 agent
                const rawAgents = Array.isArray(dataInit.agents) ? dataInit.agents : [];
                allAgents.value = rawAgents.filter(a => a && a.id);

                if(id) {
                    const resDetail = await fetch('api.php?action=get_agent_detail&id=' + id);
                    if(resDetail.ok) {
                        const target = await resDetail.json();
                        if(target) {
                            form.value.id = target.id;
                            form.value.username = target.username || '';
                            form.value.phone = target.phone || '';
                            form.value.department_id = target.department_id || 0;
                            form.value.role = target.role || 'channel';
                            form.value.password = target.password || ''; 
                            form.value.manager_id = target.manager_id || 0;
                        }
                    }
                }
            } catch (error) {
                console.error('加载数据失败:', error);
            }
        };



        const save = async () => {
            try {
                const fd = new FormData();

                for(let k in form.value) {
                    fd.append(k, form.value[k] === null ? '' : form.value[k]);
                }
                
                const res = await fetch('api.php?action=save_agent_full', {method:'POST', body:fd});
                const d = await res.json();
                if(d.status === 'success') { alert('保存成功'); window.opener && window.opener.location.reload(); window.close(); }
                else alert(d.msg || '失败');
            } catch (e) {
                alert('保存请求出错');
            }
        };

        const closeWin = () => window.close();
        onMounted(loadData);

        return { 
            form, flatDepts, allAgents, save, closeWin
        };
    }
}).mount('#app');
</script>
</body>
</html>