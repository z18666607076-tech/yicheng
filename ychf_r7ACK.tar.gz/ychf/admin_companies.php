<?php
// admin_companies.php - 商户/中介独立管理页 (v2.0: 分页+高级筛选)
session_start();
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>商户资源管理</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        .glass-nav { background: #0f172a; color: #94a3b8; }
        .nav-item.active { background: #2563eb; color: white; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.5); }
        .col-label { font-size: 10px; color: #94a3b8; display: block; margin-bottom: 2px; }
        .tag-badge { padding: 2px 6px; border-radius: 4px; font-size: 10px; margin-right: 4px; white-space: nowrap; }
        /* 分页按钮样式 */
        .page-btn { @apply px-3 py-1 border rounded bg-white text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition text-sm; }
        .page-btn.active { @apply bg-blue-600 text-white border-blue-600; }
        .filter-input { @apply border rounded-lg px-3 py-2 text-sm w-full outline-none focus:ring-2 focus:ring-blue-100 transition; }
    </style>
</head>
<body>
<div id="app" class="flex h-screen overflow-hidden">
    
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 flex flex-col overflow-hidden bg-slate-50">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 shadow-sm flex-shrink-0 z-10">
            <div class="flex items-center gap-4">
                <button @click="sidebarOpen = !sidebarOpen" class="md:hidden text-gray-500"><i class="fas fa-bars"></i></button>
                <h2 class="text-lg font-bold text-slate-800">商户资源管理</h2>
            </div>
            <div class="flex items-center gap-4">
                <button @click="loadData" class="text-gray-500 hover:text-blue-600 transition" title="刷新数据"><i class="fas fa-sync-alt" :class="{'animate-spin': loading}"></i></button>
                <button @click="openEdit()" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition shadow-lg flex items-center gap-2">
                    <i class="fas fa-plus"></i> 新增商户
                </button>
            </div>
        </header>

        <div class="flex-1 overflow-auto p-6 flex flex-col">
            
            <div class="bg-white p-4 rounded-xl shadow-sm mb-4 border border-gray-100">
                <div v-if="selectedCompanies.length > 0" class="flex items-center gap-3 mb-3 p-2 bg-blue-50 rounded-lg border border-blue-100">
                    <span class="text-xs font-bold text-blue-700">已选择 {{ selectedCompanies.length }} 个商户</span>
                    <button @click="openBatchEditModal" class="bg-blue-600 text-white text-xs px-3 py-1 rounded hover:bg-blue-700 transition flex items-center gap-1">
                        <i class="fas fa-users-cog"></i> 批量修改跟进人
                    </button>
                    <button @click="selectedCompanies = []" class="text-blue-600 text-xs px-3 py-1 rounded hover:bg-blue-100 transition">
                        取消选择
                    </button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-5 gap-3">
                    <div class="md:col-span-2">
                        <label class="text-[10px] font-bold text-gray-400 mb-1 block uppercase">关键词搜索</label>
                        <div class="relative">
                            <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                            <input v-model="filters.kw" @keyup.enter="handleSearch" class="pl-9 filter-input" placeholder="公司名 / 门店 / 姓名 / 电话">
                        </div>
                    </div>
                    <div>
                        <label class="text-[10px] font-bold text-gray-400 mb-1 block uppercase">板块 (Region)</label>
                        <input v-model="filters.plate" @keyup.enter="handleSearch" class="filter-input" placeholder="如: 陈江">
                    </div>
                    <div>
                        <label class="text-[10px] font-bold text-gray-400 mb-1 block uppercase">地区 (Area)</label>
                        <input v-model="filters.area" @keyup.enter="handleSearch" class="filter-input" placeholder="如: 五一片区">
                    </div>
                    <div>
                        <label class="text-[10px] font-bold text-gray-400 mb-1 block uppercase">跟进人</label>
                        <div class="flex gap-2">
                            <input v-model="filters.follower" @keyup.enter="handleSearch" class="filter-input" placeholder="姓名">
                            <button @click="handleSearch" class="bg-blue-600 text-white px-4 rounded-lg hover:bg-blue-700 transition"><i class="fas fa-arrow-right"></i></button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex-1 overflow-y-auto space-y-3 pr-2">
                <div v-if="companies.length===0 && !loading" class="text-center py-20 bg-white rounded-xl border border-dashed border-gray-200">
                    <div class="text-gray-300 text-4xl mb-3"><i class="fas fa-inbox"></i></div>
                    <p class="text-gray-400 text-sm">暂无数据，请尝试调整搜索条件</p>
                </div>

                <div v-for="c in companies" :key="c.id" class="bg-white rounded-xl p-4 shadow-sm border border-slate-100 hover:shadow-md transition group relative">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="text-xs text-gray-400 font-mono bg-gray-50 px-2 py-0.5 rounded">ID: {{ c.id }}</span>
                        <div class="flex items-center gap-2">
                            <span v-if="c.region_main" class="bg-blue-50 text-blue-600 text-[10px] font-bold px-2 py-0.5 rounded border border-blue-100">{{ c.region_main }}</span>
                            <span v-if="c.region_sub" class="text-gray-400 text-xs bg-gray-50 px-1.5 py-0.5 rounded">{{ c.region_sub }}</span>
                        </div>
                    </div>
                    <div class="flex justify-between items-start">
                        
                        <div class="w-1/3 border-r border-gray-100 pr-4">
                            <h3 class="font-bold text-base text-slate-800 mb-1 flex items-center gap-2">
                                {{ c.name }}
                                <span v-if="c.store_name" class="text-xs font-normal text-gray-500 bg-gray-100 px-2 rounded-full"><i class="fas fa-store mr-1"></i>{{ c.store_name }}</span>
                            </h3>
                            <div class="flex flex-wrap gap-1 mt-2">
                                <span v-if="c.store_type" class="tag-badge bg-orange-50 text-orange-600 border border-orange-100">{{ c.store_type }}</span>
                                <span v-if="c.franchise_brand" class="tag-badge bg-purple-50 text-purple-600 border border-purple-100">盟:{{ c.franchise_brand }}</span>
                                <span v-if="c.related_store" class="tag-badge bg-cyan-50 text-cyan-600 border border-cyan-100">联:{{ c.related_store }}</span>
                            </div>
                        </div>

                        <div class="w-1/3 px-4 border-r border-gray-100">
                            <div class="mb-2">
                                <span class="col-label">店东/联系人</span>
                                <div class="flex items-center gap-2">
                                    <span class="font-bold text-slate-700 text-sm">{{ c.contact_name || '-' }}</span>
                                    <span class="text-blue-600 font-mono bg-blue-50 px-1.5 rounded text-xs tracking-wide">{{ c.contact_phone }}</span>
                                </div>
                            </div>
                            <div>
                                <span class="col-label">地址</span>
                                <p class="text-xs text-gray-500 leading-relaxed truncate" :title="c.address">{{ c.address || '-' }}</p>
                            </div>
                        </div>

                        <div class="w-1/4 pl-4 flex flex-col justify-between h-full min-h-[80px]">
                            <div>
                                <span class="col-label">跟进人</span>
                                <div class="flex items-center gap-2">
                                    <div class="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 text-xs border border-slate-200"><i class="fas fa-user"></i></div>
                                    <span class="font-bold text-sm text-slate-600">{{ c.follower || '公池' }}</span>
                                </div>
                            </div>
                            <div class="flex justify-end items-center gap-3 mt-auto">
                                <button @click="openEdit(c)" class="text-blue-600 text-xs hover:underline font-bold flex items-center"><i class="fas fa-edit mr-1"></i>编辑</button>
                                <button @click="delComp(c.id)" class="text-red-400 text-xs hover:underline flex items-center"><i class="fas fa-trash-alt mr-1"></i>删除</button>
                                <input type="checkbox" v-model="selectedCompanies" :value="c.id" class="rounded text-blue-600 focus:ring-blue-500">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white border-t border-gray-200 p-3 flex justify-between items-center mt-2 rounded-xl shadow-lg z-20">
                <div class="text-xs text-gray-500">
                    共 <span class="font-bold text-slate-700">{{ pagination.total }}</span> 条数据，
                    当前第 <span class="font-bold text-blue-600">{{ pagination.page }}</span> / {{ totalPages }} 页
                </div>
                <div class="flex items-center gap-2">
                    <select v-model="pagination.limit" @change="handleSearch" class="border rounded px-2 py-1 text-xs outline-none bg-gray-50">
                        <option :value="10">10条/页</option>
                        <option :value="20">20条/页</option>
                        <option :value="50">50条/页</option>
                        <option :value="100">100条/页</option>
                    </select>
                    <div class="flex gap-1">
                        <button @click="changePage(1)" :disabled="pagination.page===1" class="page-btn">首页</button>
                        <button @click="changePage(pagination.page-1)" :disabled="pagination.page===1" class="page-btn">上一页</button>
                        <button @click="changePage(pagination.page+1)" :disabled="pagination.page>=totalPages" class="page-btn">下一页</button>
                    </div>
                </div>
            </div>

        </div>

        <!-- 批量修改跟进人模态框 -->
        <div v-if="showBatchEditModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white rounded-xl p-6 w-full max-w-md shadow-xl">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="font-bold text-lg text-slate-800">批量修改跟进人</h3>
                    <button @click="showBatchEditModal = false" class="text-gray-400 hover:text-gray-600 text-xl">&times;</button>
                </div>
                <div class="space-y-4">
                    <div>
                        <label class="text-sm font-bold text-gray-600 mb-2 block">跟进人姓名</label>
                        <select v-model="batchFollower" class="filter-input" @click="agents.length === 0 && loadAgents()">
                            <option value="">请选择跟进人</option>
                            <option v-for="agent in agents" :key="agent" :value="agent">{{ agent }}</option>
                        </select>
                    </div>
                    <div class="text-sm text-gray-500">
                        本次将修改 <span class="font-bold text-blue-600">{{ selectedCompanies.length }}</span> 个商户的跟进人
                    </div>
                </div>
                <div class="flex gap-3 mt-6">
                    <button @click="showBatchEditModal = false" class="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg hover:bg-gray-200 transition">取消</button>
                    <button @click="batchUpdateFollower" class="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition">确定修改</button>
                </div>
            </div>
        </div>

    </main>
</div>

<script>
const { createApp, ref, onMounted, computed, watch } = Vue;
createApp({
    setup() {
        const sidebarOpen = ref(false);
        const view = ref('companies'); // 侧边栏高亮用
        const loading = ref(false);
        const companies = ref([]);
        const selectedCompanies = ref([]);
        const showBatchEditModal = ref(false);
        const batchFollower = ref('');
        const agents = ref([]); // 内部架构人员列表
        
        // 搜索条件
        const filters = ref({
            kw: '',
            plate: '',
            area: '',
            follower: ''
        });

        // 分页状态
        const pagination = ref({
            page: 1,
            limit: 20,
            total: 0
        });

        const totalPages = computed(() => Math.ceil(pagination.value.total / pagination.value.limit) || 1);

        const loadData = async () => {
            loading.value = true;
            try {
                // 构建查询参数
                const params = new URLSearchParams({
                    action: 'get_companies',
                    page: pagination.value.page,
                    limit: pagination.value.limit,
                    kw: filters.value.kw,
                    plate: filters.value.plate,
                    area: filters.value.area,
                    follower: filters.value.follower
                });

                const res = await fetch('api.php?' + params.toString());
                const json = await res.json();
                
                if (json.data) {
                    companies.value = json.data;
                    pagination.value.total = parseInt(json.count || 0);
                } else {
                    // 兼容旧接口格式（如果只返回了数组）
                    companies.value = Array.isArray(json) ? json : [];
                    pagination.value.total = companies.value.length;
                }
            } catch(e) {
                console.error("加载失败", e);
            } finally {
                loading.value = false;
            }
        };

        const loadAgents = async () => {
            try {
                const res = await fetch('api.php?action=get_structure');
                const json = await res.json();
                
                if (json.agents) {
                    // 提取所有人员名称，去重
                    const agentNames = [...new Set(json.agents.map(agent => agent.username).filter(Boolean))];
                    agents.value = agentNames.sort();
                }
            } catch(e) {
                console.error("加载人员列表失败", e);
            }
        };

        // 搜索事件（重置页码）
        const handleSearch = () => {
            pagination.value.page = 1;
            loadData();
        };

        // 翻页事件
        const changePage = (newPage) => {
            if (newPage < 1 || newPage > totalPages.value) return;
            pagination.value.page = newPage;
            loadData();
        };

        const openEdit = (item = null) => {
            const url = item ? `admin_company_edit.php?id=${item.id}` : 'admin_company_edit.php';
            window.open(url, 'company_edit', 'width=900,height=600,top=100,left=100');
        };

        const delComp = async (id) => {
            if(!confirm('确定删除该商户？')) return;
            const fd = new FormData(); fd.append('id', id);
            await fetch('api.php?action=delete_company', {method:'POST', body:fd});
            loadData();
        };

        const openBatchEditModal = () => {
            batchFollower.value = '';
            showBatchEditModal.value = true;
        };

        const batchUpdateFollower = async () => {
            if (!batchFollower.value.trim()) {
                alert('请输入跟进人姓名');
                return;
            }
            
            if(!confirm(`确定将 ${selectedCompanies.value.length} 个商户的跟进人修改为 ${batchFollower.value}？`)) return;
            
            try {
                const fd = new FormData();
                fd.append('ids', selectedCompanies.value.join(','));
                fd.append('follower', batchFollower.value);
                
                const res = await fetch('api.php?action=batch_update_company_follower', {method:'POST', body:fd});
                const data = await res.json();
                
                if (data.status === 'success') {
                    alert('批量修改成功');
                    showBatchEditModal.value = false;
                    selectedCompanies.value = [];
                    loadData();
                } else {
                    alert('修改失败：' + (data.msg || '未知错误'));
                }
            } catch (e) {
                console.error('修改失败', e);
                alert('修改失败，请重试');
            }
        };

        onMounted(() => {
            loadData();
            loadAgents(); // 加载内部架构人员列表
            // 监听子窗口关闭（简单轮询或事件监听太复杂，这里用简单的焦点刷新）
            window.addEventListener('focus', loadData); 
        });

        return {
            sidebarOpen, view, loading, companies, filters, pagination, totalPages,
            selectedCompanies, showBatchEditModal, batchFollower, agents,
            loadData, handleSearch, changePage, openEdit, delComp,
            openBatchEditModal, batchUpdateFollower, loadAgents
        };
    }
}).mount('#app');
</script>
</body>
</html>