<?php
// admin_filing_edit.php - 报备详情/修改
session_start();
$host='127.0.0.1'; $db='ychf'; $user='ychf'; $pass='rjX5DESSbGXbewfa';
try{ $pdo=new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4",$user,$pass); }catch(PDOException $e){die("DB Error");}

$id = $_GET['id'] ?? 0;
$action = $_GET['action'] ?? '';

// [API] 获取详情
if ($action == 'get_detail') {
    $stmt = $pdo->prepare("SELECT f.*, p.name as project_name FROM filings f LEFT JOIN projects p ON f.project_id = p.id WHERE f.id = ?");
    $stmt->execute([$id]);
    echo json_encode($stmt->fetch(PDO::FETCH_ASSOC)); exit;
}

// [API] 保存修改
if ($action == 'save') {
    $d = $_POST;
    // 更新主表
    $sql = "UPDATE filings SET 
            client_name=?, client_phone=?, client_num=?, 
            broker_name=?, broker_phone=?, broker_num=?,
            visit_time=?, designated_sales=?, remark=?, 
            status=?, company_name=?,
            deal_price=?, commission_amount=?, commission_status=?,
            subscriber_name=?, subscribed_room_number=?, transaction_area=?,
            salesperson=?, subscription_phone_full=?, subscription_date=?, transaction_recorder=?
            WHERE id=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $d['client_name'], $d['client_phone'], $d['client_num'],
        $d['broker_name'], $d['broker_phone'], $d['broker_num'],
        $d['visit_time'], $d['designated_sales'], $d['remark'], 
        $d['status'], $d['company_name'],
        $d['deal_price'] ?? 0, $d['commission_amount'] ?? 0, $d['commission_status'] ?? 0,
        $d['subscriber_name'] ?? null, $d['subscribed_room_number'] ?? null, $d['transaction_area'] ?? null,
        $d['salesperson'] ?? null, $d['subscription_phone_full'] ?? null, $d['subscription_date'] ?? null, $d['transaction_recorder'] ?? null,
        $id
    ]);
    
    // 记录日志
    $log = "\n" . date('Y-m-d H:i') . " [管理员] 修改信息/状态变更为: " . $d['status'];
    if ($d['status'] == 4) {
        $log .= "\n" . date('Y-m-d H:i') . " [管理员] 设置成交信息 - 总价: " . ($d['deal_price'] ?? 0) . " 佣金: " . ($d['commission_amount'] ?? 0);
    }
    $pdo->prepare("UPDATE filings SET status_log = CONCAT(IFNULL(status_log,''), ?) WHERE id=?")->execute([$log, $id]);
    
    echo json_encode(['status'=>'success']); exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>报备详情</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
</head>
<body class="bg-gray-50 p-8">
<div id="app" class="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8">
    <div class="flex justify-between items-center mb-6 border-b pb-4">
        <h1 class="text-2xl font-bold text-slate-800">报备详情 #{{ form.id }}</h1>
        <div class="text-sm text-gray-500">当前项目：{{ form.project_name }}</div>
    </div>

    <div class="space-y-6">
        <div class="bg-blue-50 p-4 rounded-lg flex items-center gap-4">
            <label class="font-bold text-blue-800">当前状态:</label>
            <select v-model="form.status" class="bg-white border border-blue-200 rounded px-3 py-1 text-sm outline-none">
                <option value="0">待审核</option>
                <option value="1">有效/待接待</option>
                <option value="2">已到访</option>
                <option value="3">已下定</option>
                <option value="4">已成交</option>
                <option value="5">已失效</option>
            </select>
            <span class="text-xs text-blue-400">* 修改状态会自动记录日志</span>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div><label class="text-xs text-gray-400 block mb-1">客户姓名</label><input v-model="form.client_name" class="w-full border rounded p-2"></div>
            <div><label class="text-xs text-gray-400 block mb-1">客户电话</label><input v-model="form.client_phone" class="w-full border rounded p-2"></div>
            <div><label class="text-xs text-gray-400 block mb-1">客户人数</label><input v-model="form.client_num" class="w-full border rounded p-2"></div>
            <div><label class="text-xs text-gray-400 block mb-1">带看日期</label><input v-model="form.visit_time" type="date" class="w-full border rounded p-2"></div>
        </div>

        <div class="border-t pt-4 grid grid-cols-2 gap-4">
            <div><label class="text-xs text-gray-400 block mb-1">业务员姓名</label><input v-model="form.broker_name" class="w-full border rounded p-2"></div>
            <div><label class="text-xs text-gray-400 block mb-1">业务员电话</label><input v-model="form.broker_phone" class="w-full border rounded p-2"></div>
            <div><label class="text-xs text-gray-400 block mb-1">所属公司</label><input v-model="form.company_name" class="w-full border rounded p-2"></div>
            <div><label class="text-xs text-gray-400 block mb-1">指定销售</label><input v-model="form.designated_sales" class="w-full border rounded p-2"></div>
        </div>

        <!-- 佣金结算相关字段 - 仅在已成交状态下显示 -->
        <div v-if="form.status == 4" class="border-t pt-4 bg-purple-50 p-4 rounded-lg border border-purple-100">
            <h3 class="font-bold text-purple-800 text-sm mb-3">佣金结算信息</h3>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="text-xs text-purple-600 block mb-1">成交总价 (元)</label>
                    <input v-model.number="form.deal_price" type="number" class="w-full border border-purple-200 rounded p-2" placeholder="请输入成交总价">
                </div>
                <div>
                    <label class="text-xs text-purple-600 block mb-1">佣金金额 (元)</label>
                    <input v-model.number="form.commission_amount" type="number" class="w-full border border-purple-200 rounded p-2" placeholder="请输入佣金金额">
                </div>
                <div class="col-span-2">
                    <label class="text-xs text-purple-600 block mb-1">佣金状态</label>
                    <select v-model.number="form.commission_status" class="w-full border border-purple-200 rounded p-2">
                        <option value="0">待确认业绩</option>
                        <option value="1">待发放佣金</option>
                        <option value="2">佣金已发放</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- 成交详情字段 -->
        <div class="border-t pt-4 bg-green-50 p-4 rounded-lg border border-green-100">
            <h3 class="font-bold text-green-800 text-sm mb-3">成交详情信息</h3>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="text-xs text-green-600 block mb-1">认购人姓名</label>
                    <input v-model="form.subscriber_name" type="text" class="w-full border border-green-200 rounded p-2" placeholder="请输入认购人姓名">
                </div>
                <div>
                    <label class="text-xs text-green-600 block mb-1">认购房号</label>
                    <input v-model="form.subscribed_room_number" type="text" class="w-full border border-green-200 rounded p-2" placeholder="请输入认购房号">
                </div>
                <div>
                    <label class="text-xs text-green-600 block mb-1">成交面积 (㎡)</label>
                    <input v-model.number="form.transaction_area" type="number" step="0.01" class="w-full border border-green-200 rounded p-2" placeholder="请输入成交面积">
                </div>
                <div>
                    <label class="text-xs text-green-600 block mb-1">销售人员</label>
                    <input v-model="form.salesperson" type="text" class="w-full border border-green-200 rounded p-2" placeholder="请输入销售人员姓名">
                </div>
                <div>
                    <label class="text-xs text-green-600 block mb-1">认购电话全号</label>
                    <input v-model="form.subscription_phone_full" type="tel" class="w-full border border-green-200 rounded p-2" placeholder="请输入认购电话全号">
                </div>
                <div>
                    <label class="text-xs text-green-600 block mb-1">认购日期</label>
                    <input v-model="form.subscription_date" type="date" class="w-full border border-green-200 rounded p-2">
                </div>
                <div class="col-span-2">
                    <label class="text-xs text-green-600 block mb-1">成交录入人</label>
                    <input v-model="form.transaction_recorder" type="text" class="w-full border border-green-200 rounded p-2" placeholder="请输入成交录入人">
                </div>
            </div>
        </div>

        <!-- 附件展示 -->
        <div class="border-t pt-4">
            <h3 class="font-bold text-gray-800 text-sm mb-3">附件文件</h3>
            <div v-if="form.attachments" class="grid grid-cols-3 gap-3">
                <div v-for="(url, index) in form.attachments.split(',').filter(x => x)" :key="index" class="relative aspect-square rounded-lg overflow-hidden border border-gray-200">
                    <img :src="url" class="w-full h-full object-cover cursor-pointer hover:opacity-90 transition" @click="openImage(url)">
                    <div class="absolute top-1 right-1 bg-white/80 rounded-full p-1 shadow-sm">
                        <span class="text-xs font-bold text-gray-600">{{ index + 1 }}</span>
                    </div>
                </div>
            </div>
            <div v-else class="text-center py-4 text-gray-400 text-xs">
                暂无附件
            </div>
        </div>

        <div class="border-t pt-4">
            <label class="text-xs text-gray-400 block mb-1">备注信息</label>
            <textarea v-model="form.remark" class="w-full border rounded p-2 h-20"></textarea>
        </div>
        
        <div class="bg-gray-50 p-4 rounded text-xs text-gray-500 max-h-40 overflow-y-auto whitespace-pre-wrap">
            <div class="font-bold mb-2">操作日志：</div>
            {{ form.status_log }}
        </div>

        <div class="flex justify-end gap-4 pt-4">
            <button @click="closeWin" class="px-6 py-2 border rounded text-gray-600 hover:bg-gray-50">关闭</button>
            <button @click="save" class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 shadow-lg">保存修改</button>
        </div>
    </div>
</div>
<script>
const { createApp, ref, onMounted } = Vue;
createApp({
    setup() {
        const form = ref({
            commission_status: 0 // 默认佣金状态
        });
        const id = new URLSearchParams(window.location.search).get('id');

        const loadData = async () => {
            const res = await fetch('?action=get_detail&id=' + id);
            form.value = await res.json();
            // 处理日期格式
            if(form.value.visit_time) form.value.visit_time = form.value.visit_time.substring(0,10);
            // 确保佣金状态有默认值
            if(form.value.commission_status === undefined) form.value.commission_status = 0;
        };

        const save = async () => {
            const fd = new FormData();
            for(let k in form.value) fd.append(k, form.value[k]);
            const res = await fetch('?action=save&id=' + id, {method:'POST', body:fd});
            const d = await res.json();
            if(d.status === 'success') { alert('保存成功'); loadData(); } else { alert('失败'); }
        };

        const closeWin = () => window.close();

        const openImage = (url) => {
            window.open(url, '_blank');
        };

        onMounted(loadData);
        return { form, save, closeWin, openImage };
    }
}).mount('#app');
</script>