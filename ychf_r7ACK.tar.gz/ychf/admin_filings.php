<?php
// admin_filings.php - 报备审核独立管理页
session_start();
header('Content-Type: text/html; charset=utf-8');

// === 数据库 ===
$host = '127.0.0.1'; $db = 'ychf'; $user = 'ychf'; $pass = 'rjX5DESSbGXbewfa'; $charset = 'utf8mb4';
try { $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass); } catch (PDOException $e) { die("DB Error"); }

$action = $_GET['action'] ?? 'view';

// [API] 获取报备列表 (含分页与筛选)
if ($action == 'get_filings') {
    header('Content-Type: application/json');
    
    // 参数
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
    $kw = $_GET['kw'] ?? '';
    $status = $_GET['status'] ?? '';
    $offset = ($page - 1) * $limit;

    // 构建查询
    $where = "WHERE 1=1";
    $params = [];

    if ($kw) {
        $where .= " AND (f.client_name LIKE ? OR f.client_phone LIKE ? OR f.broker_name LIKE ? OR p.name LIKE ?)";
        $params = array_merge($params, ["%$kw%", "%$kw%", "%$kw%", "%$kw%"]);
    }
    if ($status !== '') {
        $where .= " AND f.status = ?";
        $params[] = $status;
    }

    // 查总数
    $countStmt = $pdo->prepare("SELECT count(*) FROM filings f LEFT JOIN projects p ON f.project_id = p.id $where");
    $countStmt->execute($params);
    $total = $countStmt->fetchColumn();

    // 查数据
    $sql = "SELECT f.*, p.name as project_name, 
            COALESCE(NULLIF(f.broker_name,''), a.username) as display_broker_name,
            COALESCE(NULLIF(f.broker_phone,''), a.phone) as display_broker_phone
            FROM filings f 
            LEFT JOIN projects p ON f.project_id = p.id 
            LEFT JOIN agents a ON f.agent_id = a.id
            $where 
            ORDER BY f.id DESC LIMIT $limit OFFSET $offset";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $list = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['code'=>0, 'count'=>$total, 'data'=>$list]); 
    exit;
}

// [API] 快捷审核状态
if ($action == 'audit_status') {
    header('Content-Type: application/json');
    $id = $_POST['id'];
    $status = $_POST['status']; // 1=有效, 5=无效/驳回
    $reason = $_POST['reason'] ?? '';
    
    // 记录日志
    $statusText = ($status == 1) ? '审核通过' : '审核驳回';
    $log = "\n" . date('Y-m-d H:i') . " [管理员] " . $statusText . ($reason ? " (原因: $reason)" : "");
    
    $sql = "UPDATE filings SET status = ?, status_log = CONCAT(IFNULL(status_log,''), ?) WHERE id = ?";
    $pdo->prepare($sql)->execute([$status, $log, $id]);
    
    echo json_encode(['status'=>'success']);
    exit;
}

// [API] 导出 XLS
if ($action == 'export_xls') {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="报备数据_' . date('YmdHis') . '.xls"');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    $kw = $_GET['kw'] ?? '';
    $status = $_GET['status'] ?? '';
    
    $where = "WHERE 1=1";
    $params = [];
    
    if ($kw) {
        $where .= " AND (f.client_name LIKE ? OR f.client_phone LIKE ? OR f.broker_name LIKE ? OR p.name LIKE ?)";
        $params = array_merge($params, ["%$kw%", "%$kw%", "%$kw%", "%$kw%"]);
    }
    if ($status !== '') {
        $where .= " AND f.status = ?";
        $params[] = $status;
    }
    
    $sql = "SELECT f.*, p.name as project_name 
            FROM filings f 
            LEFT JOIN projects p ON f.project_id = p.id 
            $where 
            ORDER BY f.id DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $statusMap = [0=>'待审核', 1=>'有效', 2=>'已到访', 3=>'已下定', 4=>'已成交', 5=>'无效'];
    
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>客户姓名</th>";
    echo "<th>客户电话</th>";
    echo "<th>项目名称</th>";
    echo "<th>业务员姓名</th>";
    echo "<th>业务员电话</th>";
    echo "<th>所属公司</th>";
    echo "<th>认购人姓名</th>";
    echo "<th>认购房号</th>";
    echo "<th>成交面积</th>";
    echo "<th>销售人员</th>";
    echo "<th>认购电话全号</th>";
    echo "<th>认购日期</th>";
    echo "<th>成交录入人</th>";
    echo "<th>成交总价</th>";
    echo "<th>佣金金额</th>";
    echo "<th>状态</th>";
    echo "<th>报备时间</th>";
    echo "</tr>";
    
    foreach ($list as $row) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . ($row['client_name'] ?? '') . "</td>";
        echo "<td>" . ($row['client_phone'] ?? '') . "</td>";
        echo "<td>" . ($row['project_name'] ?? '') . "</td>";
        echo "<td>" . ($row['broker_name'] ?? '') . "</td>";
        echo "<td>" . ($row['broker_phone'] ?? '') . "</td>";
        echo "<td>" . ($row['company_name'] ?? '') . "</td>";
        echo "<td>" . ($row['subscriber_name'] ?? '') . "</td>";
        echo "<td>" . ($row['subscribed_room_number'] ?? '') . "</td>";
        echo "<td>" . ($row['transaction_area'] ?? '') . "</td>";
        echo "<td>" . ($row['salesperson'] ?? '') . "</td>";
        echo "<td>" . ($row['subscription_phone_full'] ?? '') . "</td>";
        echo "<td>" . ($row['subscription_date'] ?? '') . "</td>";
        echo "<td>" . ($row['transaction_recorder'] ?? '') . "</td>";
        echo "<td>" . ($row['deal_price'] ?? 0) . "</td>";
        echo "<td>" . ($row['commission_amount'] ?? 0) . "</td>";
        echo "<td>" . ($statusMap[$row['status']] ?? '未知') . "</td>";
        echo "<td>" . $row['created_at'] . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    exit;
}

// [API] 删除记录
if ($action == 'delete') {
    header('Content-Type: application/json');
    $id = $_POST['id'];
    
    $stmt = $pdo->prepare("DELETE FROM filings WHERE id = ?");
    $stmt->execute([$id]);
    
    echo json_encode(['status'=>'success']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>报备审核管理</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: sans-serif; }
        .nav-item.active { background: #2563eb; color: white; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.5); }
        /* 状态标签色 */
        .status-0 { @apply bg-gray-100 text-gray-500 border-gray-200; }
        .status-1 { @apply bg-blue-50 text-blue-600 border-blue-200; }
        .status-2 { @apply bg-yellow-50 text-yellow-600 border-yellow-200; }
        .status-3 { @apply bg-orange-50 text-orange-600 border-orange-200; }
        .status-4 { @apply bg-green-50 text-green-600 border-green-200; }
        .status-5 { @apply bg-red-50 text-red-500 border-red-200; }
        /* 时间轴 */
        .timeline-item { position: relative; padding-left: 20px; padding-bottom: 25px; border-left: 2px solid #e2e8f0; }
        .timeline-item:last-child { border-left: 2px solid transparent; }
        .timeline-dot { position: absolute; left: -6px; top: 0; width: 10px; height: 10px; border-radius: 50%; background: #cbd5e1; border: 2px solid #fff; }
        .timeline-dot.active { background: #3b82f6; }
        /* 分页 */
        .page-btn { @apply px-3 py-1 border rounded bg-white text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition text-sm; }
    </style>
</head>
<body>
<div id="app" class="flex h-screen overflow-hidden">
    
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 flex flex-col overflow-hidden bg-slate-50">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 shadow-sm flex-shrink-0">
            <div class="flex items-center gap-4">
                <button @click="sidebarOpen = !sidebarOpen" class="md:hidden text-gray-500"><i class="fas fa-bars"></i></button>
                <h2 class="text-lg font-bold text-slate-800">报备审核管理</h2>
            </div>
            <div class="flex items-center gap-3">
                <span class="text-sm text-gray-500">共 {{ pagination.total }} 条记录</span>
                <button @click="loadData" class="text-blue-600 hover:bg-blue-50 px-3 py-1 rounded transition"><i class="fas fa-sync-alt mr-1"></i> 刷新</button>
                <button @click="exportXls" class="bg-green-600 text-white px-4 py-1.5 rounded-lg text-sm hover:bg-green-700 transition"><i class="fas fa-file-excel mr-1"></i> 导出XLS</button>
            </div>
        </header>

        <div class="flex-1 overflow-auto p-6 flex flex-col">
            
            <div class="bg-white p-4 rounded-xl shadow-sm mb-4 border border-gray-100 flex flex-wrap gap-4 items-center">
                <div class="relative w-64">
                    <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                    <input v-model="filters.kw" @keyup.enter="handleSearch" class="w-full pl-10 pr-4 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-100 outline-none" placeholder="搜客户/电话/项目/经纪人">
                </div>
                <div>
                    <select v-model="filters.status" @change="handleSearch" class="border rounded-lg px-3 py-2 text-sm outline-none bg-white focus:ring-2 focus:ring-blue-100">
                        <option value="">全部状态</option>
                        <option value="0">⏳ 待审核</option>
                        <option value="1">✅ 有效/待接待</option>
                        <option value="2">👣 已到访</option>
                        <option value="3">📝 已认筹</option>
                        <option value="4">💰 已成交</option>
                        <option value="5">❌ 已失效/驳回</option>
                    </select>
                </div>
                <button @click="handleSearch" class="bg-blue-600 text-white px-5 py-2 rounded-lg text-sm hover:bg-blue-700 transition">查询</button>
            </div>

            <div class="flex-1 overflow-y-auto bg-white rounded-xl shadow-sm border border-gray-200">
                <table class="w-full text-sm text-left text-gray-500">
                    <thead class="bg-gray-50 text-xs uppercase text-gray-700 sticky top-0 z-10">
                        <tr>
                            <th class="px-6 py-3">客户信息</th>
                            <th class="px-6 py-3">报备项目</th>
                            <th class="px-6 py-3">归属经纪人</th>
                            <th class="px-6 py-3">当前状态</th>
                            <th class="px-6 py-3">报备时间</th>
                            <th class="px-6 py-3 text-right">操作</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <tr v-if="list.length===0"><td colspan="6" class="px-6 py-10 text-center text-gray-400">暂无数据</td></tr>
                        <tr v-for="item in list" :key="item.id" class="hover:bg-slate-50 transition">
                            <td class="px-6 py-4">
                                <div class="font-bold text-slate-800">{{ item.client_name }}</div>
                                <div class="text-xs text-gray-400 font-mono">{{ item.client_phone }}</div>
                            </td>
                            <td class="px-6 py-4">
                                <span class="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs font-bold">{{ item.project_name }}</span>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-slate-700">{{ item.display_broker_name || '未知' }}</div>
                                <div class="text-xs text-gray-400">{{ item.display_broker_phone }}</div>
                            </td>
                            <td class="px-6 py-4">
                                <span class="px-2.5 py-1 rounded-full text-xs font-bold border inline-block" :class="'status-'+item.status">
                                    {{ statusText[item.status] || '未知' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 text-xs text-gray-400">
                                {{ item.created_at }}
                            </td>
                            <td class="px-6 py-4 text-right space-x-2">
                                <button v-if="item.status==0" @click="audit(item.id, 1)" class="text-green-600 hover:bg-green-50 px-2 py-1 rounded font-bold text-xs transition border border-transparent hover:border-green-200">
                                    <i class="fas fa-check"></i> 通过
                                </button>
                                <button v-if="item.status==0" @click="audit(item.id, 5)" class="text-red-500 hover:bg-red-50 px-2 py-1 rounded font-bold text-xs transition border border-transparent hover:border-red-200">
                                    <i class="fas fa-times"></i> 驳回
                                </button>
                                
                                <button @click="showTimeline(item)" class="text-gray-500 hover:text-blue-600 text-xs font-bold"><i class="fas fa-history"></i> 进度</button>
                                <button @click="openDetail(item.id)" class="text-blue-600 hover:underline text-xs">详情</button>
                                <button @click="deleteItem(item.id)" class="text-red-600 hover:bg-red-50 px-2 py-1 rounded font-bold text-xs transition border border-transparent hover:border-red-200">
                                    <i class="fas fa-trash"></i> 删除
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="bg-white border-t border-gray-200 p-3 flex justify-between items-center mt-auto flex-shrink-0">
                <div class="text-xs text-gray-500">
                    第 <span class="font-bold text-blue-600">{{ pagination.page }}</span> / {{ totalPages }} 页
                </div>
                <div class="flex gap-1">
                    <button @click="changePage(pagination.page-1)" :disabled="pagination.page===1" class="page-btn">上一页</button>
                    <button @click="changePage(pagination.page+1)" :disabled="pagination.page>=totalPages" class="page-btn">下一页</button>
                </div>
            </div>

        </div>
    </main>

    <div v-if="showModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm" @click.self="showModal=false">
        <div class="bg-white w-[500px] max-h-[80vh] rounded-xl shadow-2xl flex flex-col overflow-hidden animate-fade-in">
            <div class="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                <h3 class="font-bold text-slate-800">订单进度详情</h3>
                <button @click="showModal=false" class="text-gray-400 hover:text-slate-800"><i class="fas fa-times"></i></button>
            </div>
            <div class="p-6 overflow-y-auto flex-1">
                <div class="mb-4">
                    <div class="text-sm font-bold text-slate-700">{{ currentItem.client_name }} - {{ currentItem.project_name }}</div>
                    <div class="text-xs text-gray-400 mt-1">报备单号: #{{ currentItem.id }}</div>
                </div>
                <div class="pl-2">
                    <div v-for="(log, idx) in parseLog(currentItem.status_log)" :key="idx" class="timeline-item">
                        <div class="timeline-dot" :class="idx===0?'active':''"></div>
                        <div class="text-xs text-gray-400 mb-1">{{ log.time }}</div>
                        <div class="text-sm font-bold text-slate-700">{{ log.title }}</div>
                        <div v-if="log.desc" class="text-xs text-gray-500 mt-1 bg-gray-50 p-2 rounded">{{ log.desc }}</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
const { createApp, ref, onMounted, computed } = Vue;
createApp({
    setup() {
        const sidebarOpen = ref(false);
        const view = ref('filings'); // 用于侧边栏高亮
        const list = ref([]);
        const filters = ref({ kw: '', status: '' });
        const pagination = ref({ page: 1, limit: 20, total: 0 });
        
        const showModal = ref(false);
        const currentItem = ref({});

        const statusText = {0:'待审核', 1:'有效', 2:'已到访', 3:'已下定', 4:'已成交', 5:'无效'};
        const totalPages = computed(() => Math.ceil(pagination.value.total / pagination.value.limit) || 1);

        const loadData = async () => {
            const params = new URLSearchParams({
                action: 'get_filings',
                page: pagination.value.page,
                limit: pagination.value.limit,
                kw: filters.value.kw,
                status: filters.value.status
            });
            const res = await fetch('?' + params.toString());
            const json = await res.json();
            list.value = json.data;
            pagination.value.total = parseInt(json.count);
        };

        const handleSearch = () => { pagination.value.page = 1; loadData(); };
        const changePage = (p) => { if(p>=1 && p<=totalPages.value) { pagination.value.page = p; loadData(); } };

        const audit = async (id, status) => {
            let reason = '';
            if (status === 5) {
                reason = prompt("请输入驳回/无效原因 (选填):");
                if (reason === null) return; // 取消
            } else {
                if(!confirm('确定审核通过该报备吗？')) return;
            }

            const fd = new FormData();
            fd.append('id', id);
            fd.append('status', status);
            fd.append('reason', reason);

            const res = await fetch('?action=audit_status', {method:'POST', body:fd});
            const d = await res.json();
            if (d.status === 'success') loadData();
        };

        const showTimeline = (item) => { currentItem.value = item; showModal.value = true; };
        
        const parseLog = (logStr) => {
            if(!logStr) return [];
            return logStr.split('\n').filter(l => l.trim()).map(l => {
                const parts = l.split('] ');
                return { 
                    time: parts[0] ? parts[0].replace('[', '').trim() : '', 
                    title: parts[1]?.split(' (')[0] || parts[1], 
                    desc: parts[1]?.includes('(') ? parts[1].split('(')[1].replace(')', '') : '' 
                };
            }).reverse();
        };

        const openDetail = (id) => {
            window.open('admin_filing_edit.php?id=' + id, 'filing_edit', 'width=800,height=700');
        };

        const exportXls = () => {
            const params = new URLSearchParams({
                action: 'export_xls',
                kw: filters.value.kw,
                status: filters.value.status
            });
            window.location.href = '?' + params.toString();
        };

        const deleteItem = async (id) => {
            if (!confirm('确定要删除这条记录吗？此操作不可恢复！')) return;
            
            const fd = new FormData();
            fd.append('id', id);
            
            const res = await fetch('?action=delete', {method:'POST', body:fd});
            const d = await res.json();
            if (d.status === 'success') {
                alert('删除成功');
                loadData();
            } else {
                alert('删除失败');
            }
        };

        onMounted(loadData);

        return {
            sidebarOpen, view, list, filters, pagination, totalPages, statusText,
            showModal, currentItem,
            loadData, handleSearch, changePage, audit, showTimeline, parseLog, openDetail, exportXls, deleteItem
        };
    }
}).mount('#app');
</script>
</body>
</html>
