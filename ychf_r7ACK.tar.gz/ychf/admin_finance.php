<?php
// admin_finance.php - 佣金结算独立管理页 (修复版)
// 开启输出缓冲，防止 PHP 警告/错误破坏 JSON 数据结构
ob_start();

session_start();
header('Content-Type: text/html; charset=utf-8');

// === 调试设置 ===
// 默认开启错误显示，但在 API 响应时我们会自动关闭它
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// === 数据库配置 ===
$host = '127.0.0.1';
$db = 'ychf';
$user = 'ychf';
$pass = 'rjX5DESSbGXbewfa';
$charset = 'utf8mb4';

$debug_info = []; // 全局调试数组

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $debug_info['db_status'] = "数据库连接成功";
} catch (PDOException $e) {
    // 如果是 API 请求，返回 JSON 错误
    if (isset($_GET['action'])) {
        ob_clean();
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => "数据库连接失败: " . $e->getMessage()]);
        exit;
    }
    die("数据库连接失败: " . $e->getMessage());
}

$action = $_GET['action'] ?? '';

// === API 处理逻辑 ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' || !empty($action)) {
    // 清除缓冲区中的任何 PHP 警告或 HTML，确保只输出纯 JSON
    ob_clean();
    header('Content-Type: application/json');
    
    // API 模式下关闭错误打印，防止破坏 JSON 格式
    ini_set('display_errors', 0);
    
    $debug_info['action'] = $action;
    $debug_info['request_method'] = $_SERVER['REQUEST_METHOD'];

    // 1. 获取财务数据
    if ($action == 'get_finance_data') {
        try {
            // 调试：统计一下 filings 表总数，确认表里有没有数据
            $total_count = $pdo->query("SELECT COUNT(*) FROM filings")->fetchColumn();
            $debug_info['total_filings_count'] = $total_count;

            // 调试：专门查一下 status=4 的有多少个
            $status_4_count = $pdo->query("SELECT COUNT(*) FROM filings WHERE status=4")->fetchColumn();
            $debug_info['status_4_count'] = $status_4_count;

            // 统计金额 (GMV, 待确认, 待发, 已发)
            $stats = [
                'gmv' => $pdo->query("SELECT SUM(deal_price) FROM filings WHERE status=4")->fetchColumn() ?: 0,
                'pending' => $pdo->query("SELECT SUM(commission_amount) FROM filings WHERE status=4 AND commission_status=0")->fetchColumn() ?: 0,
                'confirmed' => $pdo->query("SELECT SUM(commission_amount) FROM filings WHERE status=4 AND commission_status=1")->fetchColumn() ?: 0,
                'paid' => $pdo->query("SELECT SUM(commission_amount) FROM filings WHERE status=4 AND commission_status=2")->fetchColumn() ?: 0
            ];

            // === 核心查询逻辑 (已修复注释干扰) ===
            // 注意：这里去掉了 SQL 内部的 "--" 注释，防止语法错误
// === 修复版 SQL ===
            // 1. 去掉了 broker_name (因为没这个字段)
            // 2. 去掉了 LEFT JOIN ... broker_id (因为会导致报错)
            // 3. 排序改为 f.id (防止 updated_at 报错)
            $sql = "SELECT f.*, 
                           p.name as project_name, 
                           a.username as agent_name, a.department
                    FROM filings f
                    LEFT JOIN projects p ON f.project_id = p.id
                    LEFT JOIN agents a ON f.agent_id = a.id
                    WHERE f.status = 4 
                    ORDER BY f.id DESC";

            $debug_info['sql_query'] = $sql; // 将 SQL 返回给前端查看

            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $deals = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // 数据清洗：防止前端出现 null 报错
            foreach ($deals as &$deal) {
                $deal['project_name'] = $deal['project_name'] ?? '未知项目';
                $deal['client_name'] = $deal['client_name'] ?? '未知客户';
                $deal['room_number'] = $deal['room_number'] ?? '';
                $deal['deal_price'] = $deal['deal_price'] ?? 0;
                $deal['commission_amount'] = $deal['commission_amount'] ?? 0;
                $deal['commission_status'] = $deal['commission_status'] ?? 0; // 0=待确认, 1=待发放, 2=已发
            }

            echo json_encode([
                'status' => 'success',
                'stats' => $stats,
                'deals' => $deals,
                'debug' => $debug_info
            ]);
            exit;

        } catch (Exception $e) {
            echo json_encode([
                'status' => 'error',
                'message' => $e->getMessage(),
                'debug' => $debug_info
            ]);
            exit;
        }
    }

    // 2. 更新佣金状态
    if ($action == 'update_commission') {
        $id = $_POST['id'] ?? 0;
        $status = $_POST['status'] ?? 0;
        $amount = $_POST['amount'] ?? 0;
        $proof = $_POST['proof'] ?? '';

        try {
            $stmt = $pdo->prepare("UPDATE filings SET commission_status=?, commission_amount=?, commission_proof=? WHERE id=?");
            $result = $stmt->execute([$status, $amount, $proof, $id]);
            
            echo json_encode([
                'status' => 'success', 
                'msg' => '更新成功',
                'affected_rows' => $stmt->rowCount()
            ]);
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
        }
        exit;
    }

    // 未知 API
    echo json_encode(['status' => 'error', 'msg' => 'Unknown action']);
    exit;
}
// 结束缓冲，开始输出 HTML
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>佣金结算 - 易城好房Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <style>
        .fade-in { animation: fadeIn 0.5s ease-in; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        /* 调试面板样式 */
        .debug-box {
            background: #1e293b; color: #818cf8; font-family: monospace;
            padding: 15px; margin-bottom: 20px; border-radius: 8px; font-size: 12px;
            white-space: pre-wrap; word-break: break-all;
            max-height: 200px; overflow-y: auto;
        }
        [v-cloak] { display: none; } /* 防止 Vue 加载前闪烁 */
    </style>
</head>
<body class="bg-slate-50 text-slate-800 min-h-screen">

    <div id="app" class="flex h-screen overflow-hidden" v-cloak>
        <div id="sidebar-container" style="min-width: 250px;"></div>

        <div class="flex-1 overflow-y-auto flex flex-col">
            <header class="sticky top-0 bg-white border-b border-gray-200 shadow-sm z-40 shrink-0">
                <div class="flex justify-between items-center px-6 h-16">
                    <h1 class="text-xl font-bold text-slate-800">
                        <i class="fas fa-file-invoice-dollar mr-2 text-blue-600"></i>佣金结算中心
                    </h1>
                    <div class="flex items-center space-x-4">
                        <button @click="loadFinance" class="text-sm text-blue-600 hover:text-blue-800">
                            <i class="fas fa-sync-alt mr-1"></i>刷新数据
                        </button>
                    </div>
                </div>
            </header>

            <main class="p-6 flex-1">
                
                <div v-if="debugData && debugData.status_4_count === 0" class="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                    <div class="flex">
                        <div class="flex-shrink-0"><i class="fas fa-exclamation-triangle text-yellow-400"></i></div>
                        <div class="ml-3">
                            <p class="text-sm text-yellow-700">
                                提示：数据库中似乎没有状态为"已成交 (status=4)"的订单。当前已成交订单数为：0。
                            </p>
                        </div>
                    </div>
                </div>

                <!-- <div class="mb-4 text-right">
                    <button @click="showDebug = !showDebug" class="text-xs text-gray-400 hover:text-gray-600">
                        {{ showDebug ? '隐藏调试信息' : '显示调试信息' }}
                    </button>
                </div>
                <div v-if="showDebug" class="debug-box">
                    API Response Debug:
                    {{ debugData }}
                </div> -->

                <div class="space-y-6 fade-in">
                    <div class="grid grid-cols-4 gap-4">
                        <div class="bg-white p-4 rounded-xl shadow-sm border-l-4 border-blue-500">
                            <div class="text-xs text-gray-400 font-bold uppercase">累计 GMV (已成交)</div>
                            <div class="text-xl font-bold text-slate-800 mt-1">
                                ¥{{ formatMoney(financeData.stats.gmv) }}
                            </div>
                        </div>
                        <div class="bg-white p-4 rounded-xl shadow-sm border-l-4 border-orange-400">
                            <div class="text-xs text-gray-400 font-bold uppercase">待确认业绩</div>
                            <div class="text-xl font-bold text-orange-600 mt-1">
                                ¥{{ formatMoney(financeData.stats.pending) }}
                            </div>
                        </div>
                        <div class="bg-white p-4 rounded-xl shadow-sm border-l-4 border-purple-500">
                            <div class="text-xs text-gray-400 font-bold uppercase">待发佣金</div>
                            <div class="text-xl font-bold text-purple-600 mt-1">
                                ¥{{ formatMoney(financeData.stats.confirmed) }}
                            </div>
                        </div>
                        <div class="bg-white p-4 rounded-xl shadow-sm border-l-4 border-green-500">
                            <div class="text-xs text-gray-400 font-bold uppercase">已发佣金</div>
                            <div class="text-xl font-bold text-green-600 mt-1">
                                ¥{{ formatMoney(financeData.stats.paid) }}
                            </div>
                        </div>
                    </div>

                    <div class="bg-white rounded-xl shadow-sm border border-gray-200">
                        <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                            <span class="font-bold text-slate-700">已成交订单 (Status=4)</span>
                            <span class="text-xs text-gray-400">共 {{ financeData.deals.length }} 条</span>
                        </div>
                        
                        <div class="overflow-x-auto">
                            <table class="w-full text-sm text-left text-gray-500">
                                <thead class="bg-gray-50 text-xs uppercase text-gray-700">
                                    <tr>
                                        <th class="px-6 py-3">房源/项目</th>
                                        <th class="px-6 py-3">客户/经纪人</th>
                                        <th class="px-6 py-3">成交价</th>
                                        <th class="px-6 py-3">佣金</th>
                                        <th class="px-6 py-3">状态</th>
                                        <th class="px-6 py-3 text-right">操作</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100">
                                    <tr v-for="deal in financeData.deals" :key="deal.id" class="hover:bg-gray-50 transition-colors">
                                        <td class="px-6 py-4">
                                            <div class="font-bold text-slate-800">{{ deal.project_name }}</div>
                                            <div class="text-xs text-blue-600">{{ deal.room_number }}</div>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="text-slate-700">{{ deal.client_name }}</div>
                                            <div class="text-xs text-gray-400 mt-1">
                                                <i class="fas fa-user-tie mr-1"></i>
                                                {{ deal.agent_name || deal.broker_name || '无' }}
                                                <span v-if="deal.department" class="ml-1">({{ deal.department }})</span>
                                            </div>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="text-slate-800">¥{{ parseFloat(deal.deal_price).toLocaleString() }}</div>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="text-red-600 font-bold">¥{{ parseFloat(deal.commission_amount).toLocaleString() }}</div>
                                        </td>
                                        <td class="px-6 py-4">
                                            <span v-if="deal.commission_status == 0" class="px-2 py-1 bg-orange-100 text-orange-700 text-xs rounded-full font-medium">待确认</span>
                                            <span v-else-if="deal.commission_status == 1" class="px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded-full font-medium">待发放</span>
                                            <span v-else-if="deal.commission_status == 2" class="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full font-medium">已发放</span>
                                            <span v-else class="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">未知</span>
                                        </td>
                                        <td class="px-6 py-4 text-right space-x-2">
                                            <button v-if="deal.commission_status==0" @click="openModal(deal, 1)" class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-xs transition">确认业绩</button>
                                            <button v-if="deal.commission_status==1" @click="openModal(deal, 2)" class="bg-purple-600 hover:bg-purple-700 text-white px-3 py-1 rounded text-xs transition">发放佣金</button>
                                            <button v-if="deal.commission_proof" @click="viewProof(deal.commission_proof)" class="text-gray-400 hover:text-blue-600" title="查看凭证"><i class="fas fa-file-invoice"></i></button>
                                        </td>
                                    </tr>
                                    <tr v-if="financeData.deals.length === 0">
                                        <td colspan="6" class="px-6 py-12 text-center">
                                            <div class="text-gray-300 text-4xl mb-3"><i class="fas fa-inbox"></i></div>
                                            <div class="text-gray-500">暂无已成交订单 (Status=4)</div>
                                            <div class="text-xs text-gray-400 mt-2">请确认 filings 表中有 status 字段为 4 的数据</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div v-if="showModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 fade-in">
                    <div class="bg-white rounded-xl shadow-xl w-full max-w-md p-6 transform transition-all">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-lg font-bold text-slate-800">{{ modalStep === 1 ? '确认业绩金额' : '确认发放佣金' }}</h3>
                            <button @click="showModal = false" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
                        </div>
                        
                        <div class="space-y-4">
                            <div class="bg-gray-50 p-3 rounded text-sm text-gray-600">
                                <div class="flex justify-between"><span>项目：</span><span class="font-bold">{{ modalForm.projectName }}</span></div>
                                <div class="flex justify-between mt-1"><span>成交价：</span><span>¥{{ modalForm.dealPrice.toLocaleString() }}</span></div>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">
                                    {{ modalStep === 1 ? '确认佣金金额 (元)' : '实际发放金额 (元)' }}
                                </label>
                                <input type="number" v-model="modalForm.amount" class="w-full border border-gray-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                            </div>

                            <div v-if="modalStep === 2">
                                <label class="block text-sm font-medium text-gray-700 mb-1">上传转账凭证</label>
                                <input type="file" @change="handleFileUpload" class="w-full border border-gray-300 rounded p-2 text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                                <div v-if="modalForm.proof" class="mt-2 text-xs text-green-600"><i class="fas fa-check-circle mr-1"></i>已上传</div>
                            </div>

                            <div class="flex justify-end space-x-3 mt-6">
                                <button @click="showModal = false" class="px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50">取消</button>
                                <button @click="submitForm" class="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700 shadow-sm">
                                    {{ isSubmitting ? '提交中...' : '确认提交' }}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </main>
        </div>
    </div>

    <script>
        const { createApp, ref, onMounted } = Vue;

        const app = createApp({
            setup() {
                // 数据状态
                const financeData = ref({
                    stats: { gmv: 0, pending: 0, confirmed: 0, paid: 0 },
                    deals: []
                });
                const debugData = ref(null);
                const showDebug = ref(true); // 默认开启调试方便您看

                // 弹窗状态
                const showModal = ref(false);
                const modalStep = ref(1);
                const isSubmitting = ref(false);
                const modalForm = ref({
                    id: '',
                    projectName: '',
                    dealPrice: 0,
                    amount: 0,
                    proof: ''
                });

                // 工具函数：金额格式化
                const formatMoney = (val) => {
                    if (!val) return '0.00';
                    return (parseFloat(val) / 10000).toFixed(2) + 'w';
                };

                // 加载数据
                const loadFinance = async () => {
                    try {
                        const res = await fetch('?action=get_finance_data');
                        // 尝试解析 JSON，如果 PHP 报错返回了 HTML，这里会抛出错误
                        const text = await res.text();
                        let data;
                        try {
                            data = JSON.parse(text);
                        } catch (e) {
                            console.error("JSON 解析失败，后端返回了:", text);
                            alert("数据加载失败，请按 F12 查看控制台中的详细错误");
                            return;
                        }

                        // 保存调试信息
                        if (data.debug) debugData.value = data.debug;

                        if (data.status === 'success') {
                            financeData.value = {
                                stats: data.stats,
                                deals: data.deals
                            };
                        } else {
                            alert('错误: ' + data.message);
                        }
                    } catch (error) {
                        console.error('API 请求错误:', error);
                    }
                };

                // 打开弹窗
                const openModal = (deal, step) => {
                    modalStep.value = step;
                    modalForm.value = {
                        id: deal.id,
                        projectName: deal.project_name,
                        dealPrice: deal.deal_price,
                        amount: deal.commission_amount,
                        proof: deal.commission_proof || ''
                    };
                    showModal.value = true;
                };

                // 文件上传
                const handleFileUpload = async (e) => {
                    const file = e.target.files[0];
                    if (!file) return;
                    
                    const fd = new FormData();
                    fd.append('file', file);
                    
                    // 这里假设您有一个 upload.php
                    try {
                        const res = await fetch('upload.php', { method: 'POST', body: fd });
                        const data = await res.json();
                        if (data.status === 'success') {
                            modalForm.value.proof = data.url;
                        } else {
                            alert('上传失败');
                        }
                    } catch (e) {
                        console.error(e);
                        alert('上传接口异常');
                    }
                };

                // 提交表单
                const submitForm = async () => {
                    if (isSubmitting.value) return;
                    isSubmitting.value = true;

                    const fd = new FormData();
                    fd.append('id', modalForm.value.id);
                    fd.append('status', modalStep.value); // 1=已确认, 2=已发放
                    fd.append('amount', modalForm.value.amount);
                    fd.append('proof', modalForm.value.proof);

                    try {
                        const res = await fetch('?action=update_commission', {
                            method: 'POST',
                            body: fd
                        });
                        const data = await res.json();
                        if (data.status === 'success') {
                            showModal.value = false;
                            loadFinance(); // 刷新列表
                        } else {
                            alert(data.msg);
                        }
                    } catch (e) {
                        alert('网络错误');
                    } finally {
                        isSubmitting.value = false;
                    }
                };

                const viewProof = (url) => {
                    window.open(url, '_blank');
                };

                // 挂载侧边栏 (保持您原有的逻辑)
                const loadSidebar = () => {
                    fetch('sidebar.php')
                        .then(res => res.text())
                        .then(html => {
                            document.getElementById('sidebar-container').innerHTML = html;
                            // 简单的脚本执行逻辑，防止 Vue 冲突
                            const scripts = document.getElementById('sidebar-container').getElementsByTagName('script');
                            for (let script of scripts) {
                                eval(script.innerText);
                            }
                        });
                };

                onMounted(() => {
                    loadFinance();
                    loadSidebar();
                });

                return {
                    financeData,
                    debugData,
                    showDebug,
                    showModal,
                    modalForm,
                    modalStep,
                    isSubmitting,
                    formatMoney,
                    loadFinance,
                    openModal,
                    handleFileUpload,
                    submitForm,
                    viewProof
                };
            }
        });

        app.mount('#app');
    </script>
</body>
</html>