<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>项目编辑</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <!-- 引入CKEditor 5富文本编辑器 -->
    <script src="https://cdn.ckeditor.com/ckeditor5/36.0.1/classic/ckeditor.js"></script>
</head>
<body class="bg-gray-50 p-8">
<div id="app" class="max-w-3xl mx-auto bg-white rounded-xl shadow-lg p-8">
    <div class="flex justify-between items-center mb-6 border-b pb-4">
        <h1 class="text-2xl font-bold text-slate-800">{{ form.id ? '编辑项目' : '新增项目' }}</h1>
        <div class="flex items-center gap-4">
            <div class="flex items-center gap-2">
                <span class="text-sm font-bold text-gray-500">项目类型:</span>
                <label class="flex items-center gap-2 cursor-pointer bg-gray-100 px-3 py-1 rounded-lg">
                    <input type="checkbox" v-model="form.is_agent" :true-value="1" :false-value="0" class="w-4 h-4 text-blue-600">
                    <span :class="form.is_agent ? 'text-blue-600 font-bold' : 'text-gray-400'">{{ form.is_agent ? '代理项目 (在售)' : '市场数据 (仅展示)' }}</span>
                </label>
            </div>
            <div class="flex items-center gap-2">
                <span class="text-sm font-bold text-gray-500">项目状态:</span>
                <label class="flex items-center gap-2 cursor-pointer bg-gray-100 px-3 py-1 rounded-lg">
                    <input type="checkbox" v-model="form.status" :true-value="1" :false-value="0" class="w-4 h-4 text-green-600">
                    <span :class="form.status ? 'text-green-600 font-bold' : 'text-red-600 font-bold'">{{ form.status ? '上架' : '下架' }}</span>
                </label>
            </div>
        </div>
    </div>

    <div class="space-y-6">
        <div class="flex gap-6">
            <div class="w-48 h-48 bg-gray-100 border-2 border-dashed rounded-lg flex items-center justify-center relative hover:bg-gray-50 cursor-pointer">
                <img v-if="form.image" :src="form.image" class="w-full h-full object-cover rounded-lg">
                <div v-else class="text-center text-gray-400">点击上传封面</div>
                <input type="file" @change="handleUpload" class="absolute inset-0 opacity-0 w-full h-full">
            </div>
            <div class="flex-1 space-y-4">
                <div><label class="block text-xs font-bold text-gray-500 mb-1">项目名称</label><input v-model="form.name" class="w-full border rounded p-2"></div>
                <div class="grid grid-cols-2 gap-4">
                    <div><label class="block text-xs font-bold text-gray-500 mb-1">均价 (元/㎡)</label><input v-model="form.price" type="number" class="w-full border rounded p-2"></div>
                    <div><label class="block text-xs font-bold text-gray-500 mb-1">佣金点数</label><input v-model="form.commission_rate" class="w-full border rounded p-2" placeholder="如 3%"></div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div><label class="block text-xs font-bold text-gray-500 mb-1">税点</label><input v-model="form.tax_rate" class="w-full border rounded p-2" placeholder="如 5%"></div>
                    <div><label class="block text-xs font-bold text-gray-500 mb-1">保护期 (天)</label><input v-model="form.protect_days" type="number" class="w-full border rounded p-2" placeholder="如 30"></div>
                </div>
                <div v-if="form.is_agent" class="bg-blue-50 p-3 rounded border border-blue-100 grid grid-cols-2 gap-4 animate-pulse">
                    <div><label class="block text-xs font-bold text-blue-600 mb-1">驻场管理员</label><input v-model="form.manager_name" class="w-full border border-blue-200 rounded p-2 text-sm"></div>
                    <div><label class="block text-xs font-bold text-blue-600 mb-1">管理员电话</label><input v-model="form.manager_phone" class="w-full border border-blue-200 rounded p-2 text-sm"></div>
                </div>
            </div>
        </div>
        <div>
            <label class="block text-xs font-bold text-gray-500 mb-1">项目详情</label>
            <textarea id="detail-editor" class="w-full border rounded p-4 min-h-[200px]">{{ form.detail }}</textarea>
        </div>
        <div class="flex justify-end gap-4 pt-4 border-t">
            <button @click="closeWin" class="px-6 py-2 border rounded text-gray-600 hover:bg-gray-50">取消</button>
            <button @click="save" class="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 shadow-lg">保存</button>
        </div>
    </div>
</div>
<script>
const { createApp, ref, onMounted } = Vue;
createApp({
    setup() {
        const form = ref({ id:'', name:'', price:'', commission_rate:'', tax_rate:'', protect_days:30, detail:'', image:'', is_agent:1, status:1, manager_name:'', manager_phone:'' });
        const id = new URLSearchParams(window.location.search).get('id');

        let editor;
        
        const loadData = async () => {
            if(!id) return;
            const res = await fetch('api.php?action=get_project_detail&id=' + id);
            form.value = await res.json();
            // 加载数据后更新富文本编辑器内容
            if (editor) {
                editor.setData(form.value.detail || '');
            }
        };
        
        const handleUpload = async (e) => {
            const fd = new FormData(); fd.append('file', e.target.files[0]);
            const res = await fetch('upload.php', {method:'POST', body:fd});
            const d = await res.json();
            if(d.status==='success') form.value.image = d.url;
        };
        
        const save = async () => {
            // 保存前从富文本编辑器中获取内容
            if (editor) {
                form.value.detail = editor.getData();
            }
            const fd = new FormData(); for(let k in form.value) fd.append(k, form.value[k]);
            const res = await fetch('api.php?action=save_project', {method:'POST', body:fd});
            const d = await res.json();
            if(d.status === 'success') { alert('保存成功'); window.opener.location.reload(); window.close(); }
        };
        
        const closeWin = () => window.close();
        
        onMounted(() => {
            // 初始化CKEditor 5富文本编辑器
            ClassicEditor
                .create(document.querySelector('#detail-editor'), {
                    toolbar: [
                        'undo', 'redo',
                        '|', 'heading',
                        '|', 'bold', 'italic', 'underline',
                        '|', 'alignment',
                        '|', 'bulletedList', 'numberedList',
                        '|', 'insertTable',
                        '|', 'imageUpload', 'link',
                        '|', 'code'
                    ],
                    language: 'zh-cn',
                    image: {
                        upload: {
                            adapter: {
                                upload: async (loader) => {
                                    const fd = new FormData();
                                    fd.append('file', await loader.file);
                                    const res = await fetch('upload.php', {method: 'POST', body: fd});
                                    const data = await res.json();
                                    if (data.status === 'success') {
                                        return {
                                            default: data.url
                                        };
                                    } else {
                                        throw new Error('上传失败');
                                    }
                                }
                            }
                        }
                    }
                })
                .then(newEditor => {
                    editor = newEditor;
                    // 加载数据
                    loadData();
                })
                .catch(error => {
                    console.error('CKEditor初始化失败:', error);
                });
        });
        return { form, save, handleUpload, closeWin };
    }
}).mount('#app');
</script>
</body>
</html>