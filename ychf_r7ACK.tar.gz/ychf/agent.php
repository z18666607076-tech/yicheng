<?php
// agent.php - 经纪人端 (v26.0: 集成 DeepSeek AI 智能识别)
session_start();
header('Content-Type: text/html; charset=utf-8');

// === 0. 登录鉴权 ===
if (!isset($_SESSION['agent_id'])) { header('Location: login.php'); exit; }
$CURRENT_USER = [
    'id' => $_SESSION['agent_id'],
    'name' => $_SESSION['agent_name'],
    'phone' => $_SESSION['agent_phone'],
    'company' => $_SESSION['agent_company'],
    'role' => $_SESSION['agent_role'] ?? 'channel'
];

// 检查是否为渠道部门用户
$isChannelUser = false;
$channelDeptNames = ['渠道经理', '渠道人员'];
foreach ($channelDeptNames as $deptName) {
    if (strpos($CURRENT_USER['company'], $deptName) !== false) {
        $isChannelUser = true;
        break;
    }
}

// === 1. 数据库连接 ===
$host = '127.0.0.1'; $db = 'ychf'; $user = 'ychf'; $pass = 'rjX5DESSbGXbewfa'; $charset = 'utf8mb4';
try { $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass); } catch (PDOException $e) { die("DB Error: " . $e->getMessage()); }

$action = $_GET['action'] ?? 'view';

// [API] 提交报备
if ($action == 'submit') {
    header('Content-Type: application/json');
    $data = $_POST;
    $pids = $data['project_ids']; 
    if (is_string($pids)) $pids = explode(',', $pids);
    if (empty($pids)) { echo json_encode(['status'=>'error', 'msg'=>'请至少选择一个楼盘']); exit; }

    try {
        $pdo->beginTransaction(); 
        $successCount = 0;
        foreach ($pids as $pid) {
            if(empty($pid)) continue;
            $check = $pdo->prepare("SELECT id FROM filings WHERE project_id=? AND client_phone=? AND broker_phone=? AND created_at > CURDATE()");
            $check->execute([$pid, $data['client_phone'], $data['broker_phone']]);
            if ($check->fetch()) continue; 

            $log = date('Y-m-d H:i') . " [经纪人] 提交报备";
            $sql = "INSERT INTO filings (
                project_id, agent_id, company_name, follower, broker_name, broker_phone, broker_num,
                client_name, client_phone, client_num, visit_time, designated_sales, 
                remark, status, status_log, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $pid, $CURRENT_USER['id'], 
                $data['company_name'], $data['follower'] ?? '', $data['broker_name'], $data['broker_phone'], $data['broker_num'],
                $data['client_name'], $data['client_phone'], $data['client_num'], $data['visit_date'], $data['designated_sales'], $data['remark'], $log
            ]);
            $successCount++;
        }
        $pdo->commit();
        if ($successCount > 0) echo json_encode(['status' => 'success', 'msg' => "成功报备 {$successCount} 个项目"]);
        else echo json_encode(['status' => 'error', 'msg' => '今日已报备过这些项目']);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'msg' => '系统错误: ' . $e->getMessage()]);
    }
    exit;
}

// [API] 经纪人更新进度
if ($action == 'update_progress') {
    header('Content-Type: application/json');
    $id = $_POST['id']; $subStages = $_POST['sub_stages'] ?? ''; $voice = $_POST['voice'] ?? '';
    
    // 权限验证：检查用户是否有权限更新此报备
    $checkStmt = $pdo->prepare("SELECT f.id FROM filings f LEFT JOIN companies c ON f.company_name = c.name WHERE f.id = ? AND (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?)");
    $checkStmt->execute([$id, $CURRENT_USER['id'], $CURRENT_USER['phone'], $CURRENT_USER['name']]);
    if (!$checkStmt->fetch()) {
        echo json_encode(['status'=>'error', 'msg'=>'无权限操作此报备']);
        exit;
    }
    
    $stagesArr = [];
    if(strpos($subStages, 'deposit')!==false) $stagesArr[] = '已交定';
    if(strpos($subStages, 'lock')!==false) $stagesArr[] = '已锁房';
    if(strpos($subStages, 'sign')!==false) $stagesArr[] = '已签认购书';
    $stageStr = implode('/', $stagesArr);
    
    $log = "\n" . date('Y-m-d H:i') . " [经纪人] 更新进度: " . ($stageStr ?: '无');
    if($voice) $log .= " (备注: $voice)";

    $sql = "UPDATE filings SET sub_stages = ?, status_log = CONCAT(IFNULL(status_log,''), ?) WHERE id = ?";
    $pdo->prepare($sql)->execute([$subStages, $log, $id]);
    echo json_encode(['status'=>'success']); exit;
}

// [API] 获取列表
if ($action == 'get_list') {
    header('Content-Type: application/json');
    $phone = $CURRENT_USER['phone'];
    $name = $CURRENT_USER['name'];
    $sql = "SELECT f.*, p.name as project_name, 
            COALESCE(NULLIF(f.broker_name,''), a.username) as agent_name, 
            COALESCE(NULLIF(f.broker_phone,''), a.phone) as agent_phone,
            c.name as company_full_name, c.store_name
            FROM filings f 
            LEFT JOIN projects p ON f.project_id = p.id 
            LEFT JOIN agents a ON f.agent_id = a.id
            LEFT JOIN companies c ON f.company_name = c.name 
            WHERE (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?) 
            ORDER BY f.created_at DESC LIMIT 1000";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$CURRENT_USER['id'], $phone, $name]);
    $list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 为每个订单添加跟进记录
    foreach ($list as &$item) {
        $followupStmt = $pdo->prepare("SELECT * FROM filing_followups WHERE filing_id = ? ORDER BY followup_count ASC");
        $followupStmt->execute([$item['id']]);
        $item['followups'] = $followupStmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    echo json_encode($list);
    exit;
}

// [API] 修改报备信息
if ($action == 'update_filing') {
    header('Content-Type: application/json');
    $id = $_POST['id'] ?? 0;
    $client_name = $_POST['client_name'] ?? '';
    $client_phone = $_POST['client_phone'] ?? '';
    $company_name = $_POST['company_name'] ?? '';
    $follower = $_POST['follower'] ?? '';
    $broker_name = $_POST['broker_name'] ?? '';
    $broker_phone = $_POST['broker_phone'] ?? '';
    $visit_time = $_POST['visit_time'] ?? '';
    $designated_sales = $_POST['designated_sales'] ?? '';
    $remark = $_POST['remark'] ?? '';
    
    if(!$id) {
        echo json_encode(['status'=>'error', 'msg'=>'缺少报备ID']);
        exit;
    }
    
    // 权限验证
    $checkStmt = $pdo->prepare("SELECT 1 FROM filings f LEFT JOIN companies c ON f.company_name = c.name WHERE f.id = ? AND (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?)");
    $checkStmt->execute([$id, $CURRENT_USER['id'], $CURRENT_USER['phone'], $CURRENT_USER['name']]);
    if (!$checkStmt->fetch()) {
        echo json_encode(['status'=>'error', 'msg'=>'无权限操作此报备']);
        exit;
    }
    
    // 检查状态是否为待处理
    $statusStmt = $pdo->prepare("SELECT status FROM filings WHERE id = ?");
    $statusStmt->execute([$id]);
    $status = $statusStmt->fetchColumn();
    if ($status != 1) {
        echo json_encode(['status'=>'error', 'msg'=>'只有待处理状态的报备可以修改']);
        exit;
    }
    
    $log = "\n" . date('Y-m-d H:i') . " [经纪人] 修改报备信息";
    
    $sql = "UPDATE filings SET client_name = ?, client_phone = ?, company_name = ?, follower = ?, broker_name = ?, broker_phone = ?, visit_time = ?, designated_sales = ?, remark = ?, status_log = CONCAT(IFNULL(status_log,''), ?) WHERE id = ?";
    $pdo->prepare($sql)->execute([$client_name, $client_phone, $company_name, $follower, $broker_name, $broker_phone, $visit_time, $designated_sales, $remark, $log, $id]);
    echo json_encode(['status'=>'success']); exit;
}

// [API] 搜索历史记录
if ($action == 'search_history') {
    header('Content-Type: application/json');
    $phone = $CURRENT_USER['phone'];
    $name = $CURRENT_USER['name'];
    $keyword = $_GET['keyword'] ?? '';
    $today = date('Y-m-d');
    
    if (empty($keyword)) {
        echo json_encode([]);
        exit;
    }
    
    $sql = "SELECT f.*, p.name as project_name, 
            COALESCE(NULLIF(f.broker_name,''), a.username) as agent_name, 
            COALESCE(NULLIF(f.broker_phone,''), a.phone) as agent_phone,
            c.name as company_full_name, c.store_name
            FROM filings f 
            LEFT JOIN projects p ON f.project_id = p.id 
            LEFT JOIN agents a ON f.agent_id = a.id
            LEFT JOIN companies c ON f.company_name = c.name 
            WHERE (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?) 
            AND DATE(f.created_at) < ? 
            AND (
                f.client_name LIKE ? OR f.client_phone LIKE ? OR p.name LIKE ? OR 
                f.broker_name LIKE ? OR f.broker_phone LIKE ? OR 
                a.username LIKE ? OR a.phone LIKE ? OR 
                (f.company_name LIKE ? OR INSTR(?, f.company_name) > 0) OR 
                (c.name LIKE ? OR INSTR(?, c.name) > 0) OR 
                (c.store_name LIKE ? OR INSTR(?, c.store_name) > 0)
            )
            ORDER BY f.created_at DESC LIMIT 100";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$CURRENT_USER['id'], $phone, $name, $today, 
        "%$keyword%", "%$keyword%", "%$keyword%", 
        "%$keyword%", "%$keyword%", 
        "%$keyword%", "%$keyword%", 
        "%$keyword%", $keyword, 
        "%$keyword%", $keyword, 
        "%$keyword%", $keyword
    ]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// [API] 统计
if ($action == 'get_stats') {
    header('Content-Type: application/json');
    $agentId = $CURRENT_USER['id'];
    $phone = $CURRENT_USER['phone'];
    $name = $CURRENT_USER['name'];
    $baseSql = "FROM filings f LEFT JOIN companies c ON f.company_name = c.name WHERE f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?";
    
    // 基础统计
    $stmt = $pdo->prepare("SELECT count(*) $baseSql"); $stmt->execute([$agentId, $phone, $name]); $total = $stmt->fetchColumn();
    $stmt = $pdo->prepare("SELECT count(*) $baseSql AND f.status=4"); $stmt->execute([$agentId, $phone, $name]); $deal = $stmt->fetchColumn();
    $stmt = $pdo->prepare("SELECT count(*) $baseSql AND f.status>=2"); $stmt->execute([$agentId, $phone, $name]); $visit = $stmt->fetchColumn();
    $stmt = $pdo->prepare("SELECT SUM(f.commission_amount) $baseSql AND f.status=4"); $stmt->execute([$agentId, $phone, $name]); $comm = $stmt->fetchColumn() ?: 0;
    
    // 关联门店数量（假设通过company_name去重）
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT f.company_name) FROM filings f LEFT JOIN companies c ON f.company_name = c.name WHERE (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?) AND f.company_name != ''");
    $stmt->execute([$agentId, $phone, $name]); $storeCount = $stmt->fetchColumn() ?: 0;
    
    // 近7日详细数据
    $last7Days = [];
    $labels = [];
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i day"));
        $labels[] = date('m-d', strtotime($date));
        
        // 当日报备数
        $stmt = $pdo->prepare("SELECT count(*) FROM filings f LEFT JOIN companies c ON f.company_name = c.name WHERE (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?) AND DATE(f.created_at) = ?");
        $stmt->execute([$agentId, $phone, $name, $date]);
        $report = $stmt->fetchColumn();
        
        // 当日到访数
        $stmt = $pdo->prepare("SELECT count(*) FROM filings f LEFT JOIN companies c ON f.company_name = c.name WHERE (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?) AND DATE(f.created_at) = ? AND f.status>=2");
        $stmt->execute([$agentId, $phone, $name, $date]);
        $visitDay = $stmt->fetchColumn();
        
        // 当日成交数
        $stmt = $pdo->prepare("SELECT count(*) FROM filings f LEFT JOIN companies c ON f.company_name = c.name WHERE (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?) AND DATE(f.created_at) = ? AND f.status=4");
        $stmt->execute([$agentId, $phone, $name, $date]);
        $dealDay = $stmt->fetchColumn();
        
        $last7Days[] = [
            'date' => $date,
            'report' => $report,
            'visit' => $visitDay,
            'deal' => $dealDay
        ];
    }
    
    echo json_encode([
        'total' => $total,
        'deal' => $deal,
        'visit' => $visit,
        'comm' => $comm,
        'store_count' => $storeCount,
        'last7days' => $last7Days,
        'chart_labels' => $labels,
        'chart_data' => [
            'report' => array_column($last7Days, 'report'),
            'visit' => array_column($last7Days, 'visit'),
            'deal' => array_column($last7Days, 'deal')
        ]
    ]); exit;
}

// [API] 辅助
if ($action == 'search_company') {
    header('Content-Type: application/json'); $kw = $_GET['kw'] ?? '';
    if (mb_strlen($kw) < 1) { echo json_encode([]); exit; }
    $stmt = $pdo->prepare("SELECT name, follower FROM companies WHERE name LIKE ? LIMIT 10");
    $stmt->execute(["%$kw%"]); 
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($companies); exit;
}
if ($action == 'get_projects') {
    header('Content-Type: application/json');
    echo json_encode($pdo->query("SELECT id, name, status FROM projects ORDER BY sort_order ASC, id DESC")->fetchAll(PDO::FETCH_ASSOC)); exit;
}

if ($action == 'get_agents') {
    header('Content-Type: application/json');
    echo json_encode($pdo->query("SELECT username FROM agents GROUP BY username")->fetchAll(PDO::FETCH_ASSOC)); exit;
}
// [API] 获取跟进记录
if ($action == 'get_followups') {
    header('Content-Type: application/json');
    $filingId = $_GET['filing_id'] ?? 0;
    
    // 权限验证
    $checkStmt = $pdo->prepare("SELECT 1 FROM filings f LEFT JOIN companies c ON f.company_name = c.name WHERE f.id = ? AND (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?)");
    $checkStmt->execute([$filingId, $CURRENT_USER['id'], $CURRENT_USER['phone'], $CURRENT_USER['name']]);
    if (!$checkStmt->fetch()) {
        echo json_encode(['status'=>'error', 'msg'=>'无权限操作此报备']);
        exit;
    }
    
    $stmt = $pdo->prepare("SELECT * FROM filing_followups WHERE filing_id = ? ORDER BY followup_count ASC");
    $stmt->execute([$filingId]);
    $followups = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['status'=>'success', 'data'=>$followups]);
    exit;
}

// [API] 提交跟进记录
if ($action == 'submit_followup') {
    header('Content-Type: application/json');
    $filingId = $_POST['filing_id'] ?? 0;
    $followupCount = $_POST['followup_count'] ?? 0;
    $content = $_POST['content'] ?? '';
    $summary = $_POST['summary'] ?? '';
    
    if(!$filingId || !$followupCount || empty($content)) {
        echo json_encode(['status'=>'error', 'msg'=>'缺少必要参数']);
        exit;
    }
    
    if($followupCount < 1 || $followupCount > 3) {
        echo json_encode(['status'=>'error', 'msg'=>'跟进次数必须在1-3之间']);
        exit;
    }
    
    // 权限验证
    $checkStmt = $pdo->prepare("SELECT 1 FROM filings f LEFT JOIN companies c ON f.company_name = c.name WHERE f.id = ? AND (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?)");
    $checkStmt->execute([$filingId, $CURRENT_USER['id'], $CURRENT_USER['phone'], $CURRENT_USER['name']]);
    if (!$checkStmt->fetch()) {
        echo json_encode(['status'=>'error', 'msg'=>'无权限操作此报备']);
        exit;
    }
    
    // 检查是否已经存在该次数的跟进记录
    $existStmt = $pdo->prepare("SELECT 1 FROM filing_followups WHERE filing_id = ? AND followup_count = ?");
    $existStmt->execute([$filingId, $followupCount]);
    if ($existStmt->fetch()) {
        echo json_encode(['status'=>'error', 'msg'=>'该次数的跟进记录已存在']);
        exit;
    }
    
    // 检查是否按顺序提交
    if($followupCount > 1) {
        $prevStmt = $pdo->prepare("SELECT 1 FROM filing_followups WHERE filing_id = ? AND followup_count = ?");
        $prevStmt->execute([$filingId, $followupCount - 1]);
        if (!$prevStmt->fetch()) {
            echo json_encode(['status'=>'error', 'msg'=>'请先完成前一次跟进']);
            exit;
        }
    }
    
    try {
        $sql = "INSERT INTO filing_followups (filing_id, followup_count, content, summary, agent_id) VALUES (?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$filingId, $followupCount, $content, $summary, $CURRENT_USER['id']]);
        
        // 同时更新filings表的status_log
        $logContent = $content;
        if ($summary) {
            $logContent = "[$summary] " . $content;
        }
        $log = "\n" . date('Y-m-d H:i') . " [经纪人] 第" . $followupCount . "次跟进: " . $logContent;
        $updateStmt = $pdo->prepare("UPDATE filings SET status_log = CONCAT(IFNULL(status_log,''), ?) WHERE id = ?");
        $updateStmt->execute([$log, $filingId]);
        
        echo json_encode(['status'=>'success', 'msg'=>'跟进记录提交成功']);
    } catch (Exception $e) {
        echo json_encode(['status'=>'error', 'msg'=>'提交失败: ' . $e->getMessage()]);
    }
    exit;
}

// [API] 检查重复报备
if ($action == 'check_duplicate') {
    header('Content-Type: application/json');
    $data = $_POST;
    $clientPhone = $data['client_phone'] ?? '';
    $projectIds = $data['project_ids'] ?? [];
    if (is_string($projectIds)) $projectIds = explode(',', $projectIds);
    if (empty($clientPhone) || empty($projectIds)) {
        echo json_encode(['status' => 'success', 'data' => [], 'msg' => '']);
        exit;
    }
    
    $duplicates = [];
    foreach ($projectIds as $pid) {
        if (empty($pid)) continue;
        // 检查最近30天内相同项目和客户的报备
        $stmt = $pdo->prepare("SELECT f.*, p.name as project_name FROM filings f LEFT JOIN projects p ON f.project_id = p.id LEFT JOIN companies c ON f.company_name = c.name WHERE f.client_phone = ? AND f.project_id = ? AND f.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY) AND (f.agent_id = ? OR f.broker_phone = ? OR c.follower = ?)");

        $stmt->execute([$clientPhone, $pid, $CURRENT_USER['id'], $CURRENT_USER['phone'], $CURRENT_USER['name']]);
        $existing = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($existing)) {
            $duplicates = array_merge($duplicates, $existing);
        }
    }
    
    echo json_encode([
        'status' => 'success',
        'data' => $duplicates,
        'msg' => !empty($duplicates) ? '发现高度匹配的已有报备记录，请核验' : ''
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>经纪人端</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.4.0/dist/echarts.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; }
        .glass-nav { background: rgba(255,255,255,0.98); border-top: 1px solid #f1f5f9; padding-bottom: env(safe-area-inset-bottom); }
        .card-shadow { box-shadow: 0 4px 20px -2px rgba(0,0,0,0.05); }
        .input-group { width: 100%; background-color: #f9fafb; padding: 0.75rem; border-radius: 0.75rem; border: 1px solid #e5e7eb; font-size: 0.875rem; outline: none; transition: all 0.2s; }
        .input-group:focus { border-color: #3b82f6; ring: 2px solid #93c5fd; }
        .label-text { font-size: 0.75rem; font-weight: bold; color: #6b7280; margin-bottom: 0.25rem; display: block; margin-left: 0.25rem; }
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 50; display: flex; align-items: flex-end; justify-content: center; }
        .modal-content { background: white; width: 100%; max-width: 480px; border-radius: 20px 20px 0 0; padding: 20px; max-height: 80vh; overflow-y: auto; animation: slideUp 0.3s ease-out; position: relative; }
        .close-btn { position: absolute; top: 15px; right: 15px; color: #94a3b8; font-size: 20px; cursor: pointer; padding: 5px; }
        .filter-input { width: 100%; background-color: #f9fafb; border: 1px solid #e5e7eb; border-radius: 0.5rem; padding: 0.5rem; font-size: 0.75rem; outline: none; }
        .filter-label { font-size: 10px; font-weight: bold; color: #9ca3af; margin-bottom: 4px; display: block; }
        
        .checkbox-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; }
        .checkbox-label { display: flex; align-items: center; padding: 10px; background: #fff; border: 1px solid #e2e8f0; border-radius: 8px; cursor: pointer; transition: all 0.2s; }
        .checkbox-label.checked { background: #eff6ff; border-color: #3b82f6; color: #2563eb; }
.checkbox-label.disabled { background: #f9fafb; border-color: #e5e7eb; color: #9ca3af; cursor: not-allowed; }
.checkbox-label.disabled .check-circle { border-color: #d1d5db; }
        .check-circle { width: 16px; height: 16px; border: 2px solid #cbd5e1; border-radius: 50%; margin-right: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .checkbox-label.checked .check-circle { border-color: #3b82f6; background: #3b82f6; }
        .checkbox-label.checked .check-circle::after { content:'✓'; color:#fff; font-size:10px; }
        
        .dropdown-list { position: absolute; z-index: 50; width: 100%; background: white; border: 1px solid #e2e8f0; border-radius: 0.75rem; box-shadow: 0 10px 20px -3px rgba(0, 0, 0, 0.15); max-height: 200px; overflow-y: auto; margin-top: 4px; left: 0; right: 0; }
        .dropdown-item { padding: 12px 16px; font-size: 14px; color: #334155; cursor: pointer; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; }
        .dropdown-item:hover { background-color: #f1f5f9; }

        .timeline-item { position: relative; padding-left: 20px; padding-bottom: 25px; border-left: 2px solid #e2e8f0; }
        .timeline-item:last-child { border-left: 2px solid transparent; }
        .timeline-dot { position: absolute; left: -6px; top: 0; width: 10px; height: 10px; border-radius: 50%; background: #cbd5e1; border: 2px solid #fff; }
        .timeline-dot.active { background: #3b82f6; }
        
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
        .fade-in { animation: fadeIn 0.5s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        .prog-badge { display: flex; align-items: center; justify-content: center; gap: 4px; padding: 4px 10px; border-radius: 999px; font-size: 10px; font-weight: bold; border: 1px solid; transition: all 0.2s; }
        .prog-badge.active { background: #f3e8ff; color: #7e22ce; border-color: #d8b4fe; } 
        .prog-badge.inactive { background: #f8fafc; color: #94a3b8; border-color: #e2e8f0; }

        .sub-chip { padding: 4px 12px; border-radius: 9999px; font-size: 12px; font-weight: bold; margin-right: 8px; margin-bottom: 8px; cursor: pointer; border: 1px solid transparent; transition: all 0.2s; display: inline-block; }
        .sub-chip.active { background-color: #2563eb; color: white; border-color: #2563eb; box-shadow: 0 4px 6px -1px rgba(37, 99, 235, 0.3); }
        .sub-chip.inactive { background-color: white; color: #64748b; border-color: #e2e8f0; }
    </style>
</head>
<body>
<div id="app" class="max-w-md mx-auto min-h-screen pb-24 relative bg-gray-50">
    
    <div v-if="tab==='dash'" class="bg-blue-600 p-5 pt-8 pb-16 rounded-b-[2rem] shadow-sm relative z-0">
            <div class="flex justify-between items-center mb-6 text-white">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center font-bold border-2 border-white/30 backdrop-blur-sm"><i class="fas fa-user-circle text-2xl"></i></div>
                        <div><div class="text-xs text-blue-100 opacity-80">当前用户</div><h1 class="font-bold text-lg">{{ form.broker_name }}</h1></div>
                    </div>
                    <div class="flex gap-2">
                        <?php if (!$isChannelUser): ?>
                        <a href="staff.php" class="text-xs bg-white/20 hover:bg-white/30 backdrop-blur-sm px-3 py-1.5 rounded-full font-bold transition flex items-center gap-1"><i class="fas fa-user-shield"></i> 切换到案场</a>
                        <?php endif; ?>
                        <a href="logout.php" class="text-xs bg-white/20 hover:bg-white/30 backdrop-blur-sm px-3 py-1.5 rounded-full font-bold transition flex items-center gap-1"><i class="fas fa-sign-out-alt"></i> 退出</a>
                    </div>
                </div>
            <div class="bg-white/10 backdrop-blur-md rounded-2xl p-6 text-white border border-white/10 relative overflow-hidden mb-4">
                <div class="text-blue-100 text-xs mb-1">累计预估佣金 (元)</div>
                <div class="text-3xl font-bold mb-4 tracking-tight">¥{{ (stats.comm || 0).toLocaleString() }}</div>
                <div class="flex gap-6 border-t border-white/10 pt-4">
                    <div><div class="text-blue-100 text-xs opacity-70 mb-1">总报备</div><div class="text-lg font-bold">{{ stats.total }}</div></div>
                    <div><div class="text-blue-100 text-xs opacity-70 mb-1">总成交</div><div class="text-lg font-bold">{{ stats.deal }}</div></div>
                    <div><div class="text-blue-100 text-xs opacity-70 mb-1">总到访</div><div class="text-lg font-bold">{{ stats.visit }}</div></div>
                    <div><div class="text-blue-100 text-xs opacity-70 mb-1">关联门店</div><div class="text-lg font-bold">{{ stats.store_count || 0 }}</div></div>
                </div>
            </div>
        </div>

    <div v-else class="bg-blue-600 p-6 pt-10 pb-20 rounded-b-[2.5rem] shadow-xl relative overflow-hidden">
        <div class="flex justify-between items-start text-white relative z-10">
            <div><h1 class="text-2xl font-bold">报备工作台</h1><p class="text-blue-100 text-xs mt-1">快速录入 · 智能识别</p></div>
            <div class="flex gap-2">
                <?php if (!$isChannelUser): ?>
                <a href="staff.php" class="text-xs bg-white/20 hover:bg-white/30 backdrop-blur-sm px-3 py-1.5 rounded-full font-bold transition flex items-center gap-1"><i class="fas fa-user-shield"></i> 切换到案场</a>
                <?php endif; ?>
                <a href="logout.php" class="text-xs bg-white/20 hover:bg-white/30 backdrop-blur-sm px-3 py-1.5 rounded-full font-bold transition flex items-center gap-1"><i class="fas fa-sign-out-alt"></i> 退出</a>
            </div>
        </div>
    </div>

    <div :class="{'px-4 -mt-10 relative z-10': tab==='dash', 'px-4 -mt-16 relative z-10': tab!=='dash'}" class="space-y-5">
        
        <div v-if="tab==='dash'" class="fade-in space-y-4">
            <div class="bg-white rounded-2xl p-5 card-shadow">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="font-bold text-sm text-slate-700">近7日业务趋势</h3>
                    <div class="flex gap-2 text-xs">
                        <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-blue-500"></span> 报备</div>
                        <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-green-500"></span> 到访</div>
                        <div class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-orange-500"></span> 成交</div>
                    </div>
                </div>
                <div id="chart" class="w-full h-60"></div>
            </div>
        </div>

        <div v-if="tab==='form'" class="fade-in space-y-5">
            <div class="bg-white rounded-3xl p-5 card-shadow border border-blue-50">
                <div class="flex justify-between items-center mb-2"><h3 class="font-bold text-slate-800 text-xs"><i class="fas fa-magic text-blue-500 mr-1"></i> AI 智能识别 (支持微信文本)</h3></div>
                <div class="relative">
                    <textarea v-model="smartText" placeholder="粘贴如：报备楼盘：壹城中心... " class="w-full bg-gray-50 rounded-xl p-3 text-xs h-24 outline-none border border-gray-200 focus:ring-2 focus:ring-blue-100 resize-none"></textarea>
                    <button @click="smartParse" class="absolute right-2 bottom-2 bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg shadow-lg active:scale-95 transition flex items-center gap-1">
                        <i v-if="isParsing" class="fas fa-spinner fa-spin"></i> {{ isParsing ? '识别中...' : '一键AI填充' }}
                    </button>
                </div>
            </div>
            <div class="bg-white rounded-3xl p-6 card-shadow space-y-4">
                <div>
                    <label class="label-text">报备楼盘 (可多选) <span class="text-red-500">*</span></label>
                    <div class="checkbox-grid">
                        <label v-for="(p, index) in projects" :key="p.id" class="checkbox-label" :class="{checked: form.project_ids.includes(p.id), disabled: p.status != 1}" v-show="index < 8 || showAllProjects || form.project_ids.includes(p.id)">
                            <input type="checkbox" :value="p.id" v-model="form.project_ids" class="hidden" :disabled="p.status != 1"><span class="check-circle"></span><span class="text-xs font-bold truncate">{{ p.name }}</span>
                        </label>
                    </div>
                    <div v-if="projects.length > 8" class="text-center mt-2">
                        <button @click="showAllProjects = !showAllProjects" class="text-xs text-blue-500 bg-blue-50 px-3 py-1 rounded-full">{{ showAllProjects ? '收起列表' : '显示更多楼盘' }} <i class="fas" :class="showAllProjects?'fa-chevron-up':'fa-chevron-down'"></i></button>
                    </div>
                </div>
                
                <div class="relative">
                    <label class="label-text">报备公司 (支持关键词模糊搜索)</label>
                    <input type="text" v-model="form.company_name" @input="searchCompany" @focus="onCompanyFocus" placeholder="输入关键字..." class="input-group">
                    <div v-if="showDropdown && companyResults.length > 0" class="dropdown-list">
                        <div v-for="company in companyResults" @click="selectCompany(company)" class="dropdown-item">
                            <span>{{ company.name }}</span>
                            <i class="fas fa-building text-gray-300 text-xs"></i>
                            <span v-if="company.follower" class="text-xs text-gray-500 ml-2">跟进人: {{ company.follower }}</span>
                        </div>
                    </div>
                </div>
                
                <div v-if="form.company_name">
                    <label class="label-text">跟进人</label>
                    <select v-model="form.follower" class="input-group">
                        <option value="">请选择跟进人</option>
                        <option v-for="agent in agents" :key="agent.username" :value="agent.username">{{ agent.username }}</option>
                    </select>
                </div>

                <div class="p-3 bg-gray-50 rounded-xl border border-gray-200 space-y-3">
                    <div class="text-xs font-bold text-slate-500">业务员信息</div>
                    <div class="grid grid-cols-2 gap-3">
                        <div><label class="label-text">姓名</label><input v-model="form.broker_name" class="input-group font-bold text-slate-700"></div>
                        <div><label class="label-text">电话</label><input v-model="form.broker_phone" type="tel" class="input-group font-bold text-slate-700"></div>
                        <div class="col-span-2 flex justify-between items-center bg-white p-2 rounded-lg border border-gray-200">
                            <span class="text-xs font-bold text-gray-500 ml-1">业务员人数</span>
                            <div class="flex items-center gap-3">
                                <button @click="form.broker_num > 1 && form.broker_num--" class="w-6 h-6 bg-gray-100 rounded flex items-center justify-center text-gray-500">-</button>
                                <span class="font-bold text-sm w-4 text-center">{{ form.broker_num }}</span>
                                <button @click="form.broker_num++" class="w-6 h-6 bg-blue-50 text-blue-600 rounded flex items-center justify-center font-bold">+</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="p-3 bg-blue-50/30 rounded-xl border border-blue-100 space-y-3">
                    <div class="text-xs font-bold text-blue-800">客户信息</div>
                    <div class="grid grid-cols-2 gap-3">
                        <div class="col-span-2"><input v-model="form.client_phone" @input="formatPhone" placeholder="客户手机 (如: 153****4640)" class="input-group font-bold text-slate-700"></div>
                        <div><input v-model="form.client_name" placeholder="客户姓名" class="input-group"></div>
                        <div class="flex items-center justify-end bg-white border rounded-xl px-2">
                            <span class="text-xs text-gray-400 mr-2">人数</span>
                            <button @click="form.client_num>1 && form.client_num--" class="px-2 py-1 text-gray-400">-</button>
                            <input type="number" v-model="form.client_num" class="w-6 text-center text-xs outline-none">
                            <button @click="form.client_num++" class="px-2 py-1 text-gray-400">+</button>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3"><div><label class="label-text">带看日期</label><input type="date" v-model="form.visit_date" class="input-group"></div><div><label class="label-text">指定销售</label><input v-model="form.designated_sales" placeholder="选填" class="input-group"></div></div>
                <div><label class="label-text">备注</label><input v-model="form.remark" placeholder="其他说明" class="input-group"></div>
                <button @click="submit" class="w-full bg-blue-600 text-white py-4 rounded-xl font-bold shadow-lg shadow-blue-500/30 active:scale-95 transition mt-2">立即报备</button>
            </div>
        </div>

        <div v-if="tab==='list'" class="fade-in space-y-4 pb-10">
            <div class="flex bg-white p-1 rounded-xl mb-2 text-xs font-bold text-gray-500 shadow-sm border border-gray-100 overflow-x-auto no-scrollbar">
                <button v-for="t in tabs" :key="t.id" @click="changeMainTab(t.id)" class="flex-1 min-w-[70px] py-2.5 rounded-lg transition-all whitespace-nowrap flex items-center justify-center gap-1" :class="subTab===t.id ? 'bg-blue-50 text-blue-600 shadow-sm' : 'hover:bg-gray-50'">
                    {{ t.name }} <span class="px-1.5 py-0.5 rounded-full text-[10px]" :class="subTab===t.id ? 'bg-blue-200 text-blue-700' : 'bg-gray-100 text-gray-400'">{{ counts[t.id] || 0 }}</span>
                </button>
            </div>

            <div v-if="subTab===1 || subTab===2" class="mb-4 animate-[fadeIn_0.3s_ease-out]">
                <div v-if="subTab===1">
                    <span @click="childFilter='todo'" class="sub-chip" :class="childFilter==='todo'?'active':'inactive'">待处理</span>
                    <span @click="childFilter='valid_report'" class="sub-chip" :class="childFilter==='valid_report'?'active':'inactive'">有效报备</span>
                    <span @click="childFilter='valid'" class="sub-chip" :class="childFilter==='valid'?'active':'inactive'">有效到访</span>
                    <span @click="childFilter='invalid'" class="sub-chip" :class="childFilter==='invalid'?'active':'inactive'">无效</span>
                    <span @click="childFilter='repeat'" class="sub-chip" :class="childFilter==='repeat'?'active':'inactive'">重复</span>
                </div>
                <div v-if="subTab===2">
                    <span @click="childFilter='all'" class="sub-chip" :class="childFilter==='all'?'active':'inactive'">全部</span>
                    <span @click="childFilter='deposit'" class="sub-chip" :class="childFilter==='deposit'?'active':'inactive'">已交定</span>
                    <span @click="childFilter='lock'" class="sub-chip" :class="childFilter==='lock'?'active':'inactive'">已锁房</span>
                    <span @click="childFilter='sign'" class="sub-chip" :class="childFilter==='sign'?'active':'inactive'">已签认购</span>
                </div>
            </div>

            <div class="flex gap-2">
                <div class="flex-1 bg-white p-3 rounded-2xl shadow-sm flex items-center gap-2">
                    <i class="fas fa-search text-gray-400 ml-2"></i>
                    <input v-model="search.keyword" class="flex-1 text-sm outline-none" placeholder="搜客户姓名/电话/项目/经纪人/公司/门店...">
                </div>
                <button @click="searchHistory" class="bg-white w-12 rounded-2xl shadow-sm flex items-center justify-center text-gray-500" :class="{'text-blue-600 bg-blue-50': isSearchingHistory}"><i class="fas fa-history"></i></button>
                <button @click="showFilters=!showFilters" class="bg-white w-12 rounded-2xl shadow-sm flex items-center justify-center text-gray-500" :class="{'text-blue-600 bg-blue-50': showFilters}"><i class="fas fa-filter"></i></button>
            </div>

            <div v-if="showFilters" class="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 animate-[slideUp_0.2s_ease-out]">
                    <div class="grid grid-cols-2 gap-3 mb-3"><div><label class="filter-label">开始日期</label><input v-model="search.dateStart" type="date" class="filter-input"></div><div><label class="filter-label">结束日期</label><input v-model="search.dateEnd" type="date" class="filter-input"></div></div>
                    <div class="mb-3"><label class="filter-label">所属楼盘</label><select v-model="search.projectId" class="filter-input"><option value="">全部楼盘</option><option v-for="p in projects" :key="p.id" :value="p.id">{{ p.name }}</option></select></div>
                    <div class="grid grid-cols-2 gap-3">
                        <button @click="resetFilter" class="bg-gray-100 text-gray-500 py-2 rounded-lg text-xs font-bold">重置条件</button>
                        <button @click="applyFilter" class="bg-blue-600 text-white py-2 rounded-lg text-xs font-bold">确定筛选</button>
                    </div>
                </div>

            <div v-if="groupedList.length===0" class="text-center text-gray-400 text-xs py-10">暂无相关记录</div>
            
            <div v-for="(group, idx) in groupedList" :key="idx" class="bg-white rounded-2xl p-5 card-shadow mb-3 relative overflow-hidden">
                <div class="flex justify-between items-center mb-3 pb-3 border-b border-gray-50">
                    <div>
                        <div class="font-bold text-base text-slate-800">{{ group.client_name }} <span class="text-xs font-normal text-gray-400 font-mono ml-1">{{ maskPhone(group.client_phone) }}</span></div>
                        <div class="text-[10px] text-gray-400"><i class="far fa-clock mr-1"></i> 最近报备: {{ group.items[0].created_at.substring(5,16) }}</div>
                        <div v-if="group.items[0].company_name" class="text-[10px] text-gray-400 mt-1"><i class="fas fa-building mr-1"></i> 公司: {{ group.items[0].company_name }}</div>
                        <div v-if="group.items[0].broker_name" class="text-[10px] text-gray-400"><i class="fas fa-user-tie mr-1"></i> 经纪人: {{ group.items[0].broker_name }} {{ group.items[0].broker_phone ? '(' + maskPhone(group.items[0].broker_phone) + ')' : '' }}</div>
                    </div>
                    <div class="flex items-center gap-2">
                        <button @click="copyFilingData(group.items[0])" class="text-green-600 text-xs bg-white border border-green-200 px-3 py-1.5 rounded shadow-sm hover:bg-green-50 flex items-center gap-1"><i class="fas fa-copy"></i> 复制</button>
                        <span class="bg-gray-100 text-gray-500 px-2 py-1 rounded text-xs">{{ group.items.length }} 项目</span>
                    </div>
                </div>

                <div class="space-y-3">
                    <div v-for="item in group.items" :key="item.id" class="bg-slate-50 p-3 rounded-xl border border-slate-100 relative">
                        <div class="flex justify-between items-start mb-2">
                            <div class="font-bold text-sm text-slate-700">{{ item.project_name }}</div>
                            <div class="flex flex-col items-end">
                                <span v-if="item.status == 1 && (!item.visit_type || item.visit_type != 0)" class="text-[10px] bg-gray-100 text-gray-500 px-2 py-0.5 rounded border border-gray-200 font-bold flex items-center gap-1"><i class="far fa-clock"></i> 待处理</span>
                                <span v-if="item.status == 1 && item.visit_type == 0" class="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded border border-blue-200 font-bold flex items-center gap-1"><i class="fas fa-file-alt"></i> 有效报备</span>
                                <span v-if="item.status >= 2 && item.status < 5 && item.visit_type==1" class="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded border border-green-200 font-bold flex items-center gap-1"><i class="fas fa-check-circle"></i> 有效到访</span>
                                <span v-if="item.status == 5 && item.visit_type==2" class="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded border border-red-200 font-bold flex items-center gap-1"><i class="fas fa-times-circle"></i> 无效</span>
                                <span v-if="item.status == 6" class="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded border border-red-200 font-bold flex items-center gap-1"><i class="fas fa-times-circle"></i> 报备无效</span>
                                <span v-if="item.status == 5 && item.visit_type==3" class="text-[10px] bg-orange-100 text-orange-700 px-2 py-0.5 rounded border border-orange-200 font-bold flex items-center gap-1"><i class="fas fa-clone"></i> 重复</span>
                                <span v-if="item.status > 1 && item.status < 5 && !item.visit_type" class="px-2 py-0.5 rounded text-[10px] font-bold border" :class="statusClass(item.status)">{{ statusText(item.status) }}</span>
                            </div>
                        </div>
                        
                        <div class="text-[10px] text-gray-400 flex gap-2 items-center mb-2">
                            <span><i class="fas fa-hashtag"></i> {{ item.id }}</span>
                            <span v-if="item.status==4" class="text-green-600 font-bold">佣金: ¥{{ parseFloat(item.commission_amount).toLocaleString() }}</span>
                        </div>

                        <div v-if="item.status==2" class="flex gap-2 mb-2 border-t border-slate-200 pt-2">
                            <div class="prog-badge" :class="item.sub_stages && item.sub_stages.includes('deposit') ? 'active' : 'inactive'"><i class="fas" :class="item.sub_stages && item.sub_stages.includes('deposit') ? 'fa-check-circle' : 'fa-circle'"></i> 交定金</div>
                            <div class="prog-badge" :class="item.sub_stages && item.sub_stages.includes('lock') ? 'active' : 'inactive'"><i class="fas" :class="item.sub_stages && item.sub_stages.includes('lock') ? 'fa-check-circle' : 'fa-circle'"></i> 锁房号</div>
                            <div class="prog-badge" :class="item.sub_stages && item.sub_stages.includes('sign') ? 'active' : 'inactive'"><i class="fas" :class="item.sub_stages && item.sub_stages.includes('sign') ? 'fa-check-circle' : 'fa-circle'"></i> 签认购</div>
                        </div>
                        
                        <div class="text-right flex justify-end gap-2">
                            <button v-if="item.status == 1" @click="openEditFilingModal(item)" class="text-orange-600 text-[10px] bg-white border border-orange-200 px-2 py-1 rounded shadow-sm hover:bg-orange-50 flex items-center gap-1"><i class="fas fa-edit"></i> 修改报备</button>
                            <!-- <button v-if="item.status >= 2 && item.status < 4" @click="openEditModal(item)" class="text-purple-600 text-[10px] bg-white border border-purple-200 px-2 py-1 rounded shadow-sm hover:bg-purple-50 flex items-center gap-1"><i class="fas fa-edit"></i> 更新进度</button> -->
                            <button @click="showFilingInfo(item)" class="text-blue-500 text-[10px] bg-white border border-blue-200 px-2 py-1 rounded shadow-sm hover:bg-blue-50 flex items-center gap-1"><i class="fas fa-file-alt"></i> 报备信息</button>
                            <button @click="showTimeline(item)" class="text-green-500 text-[10px] bg-white border border-green-200 px-2 py-1 rounded shadow-sm hover:bg-green-50 flex items-center gap-1"><i class="fas fa-tasks"></i> 进度信息</button>
                        </div>
                        
                        <!-- 跟进功能 - 在待处理和有效状态显示 -->
                        <div v-if="item.status == 1 || item.status == 2" class="mt-3 pt-3 border-t border-slate-200">
                            <div class="text-xs text-gray-500 mb-2">
                                <span v-if="!item.followups || item.followups.length === 0">
                                    记录变成有效的时间: {{ item.created_at }}
                                    <span class="text-blue-600 font-bold ml-2">{{ calculateFollowupTime(item, 1) }} 分钟了</span>
                                </span>
                                <span v-else-if="item.followups.length === 1">
                                    第一次跟进时间: {{ item.followups[0].created_at }}
                                    <span class="text-blue-600 font-bold ml-2">{{ calculateFollowupTime(item, 2) }} 分钟了</span>
                                </span>
                                <span v-else-if="item.followups.length === 2">
                                    第二次跟进时间: {{ item.followups[1].created_at }}
                                    <span class="text-blue-600 font-bold ml-2">{{ calculateFollowupTime(item, 3) }} 分钟了</span>
                                </span>
                            </div>
                            <div class="flex gap-2">
                                <button 
                                    v-if="getNextFollowupCount(item) === 1"
                                    @click="openFollowupModal(item, 1)"
                                    class="text-blue-600 text-[10px] bg-white border border-blue-200 px-2 py-1 rounded shadow-sm hover:bg-blue-50 flex items-center gap-1"
                                >
                                    <i class="fas fa-phone"></i> 第一次跟进
                                </button>
                                <button 
                                    v-else-if="getNextFollowupCount(item) === 2"
                                    @click="openFollowupModal(item, 2)"
                                    class="text-blue-600 text-[10px] bg-white border border-blue-200 px-2 py-1 rounded shadow-sm hover:bg-blue-50 flex items-center gap-1"
                                >
                                    <i class="fas fa-phone"></i> 第二次跟进
                                </button>
                                <button 
                                    v-else-if="getNextFollowupCount(item) === 3"
                                    @click="openFollowupModal(item, 3)"
                                    class="text-blue-600 text-[10px] bg-white border border-blue-200 px-2 py-1 rounded shadow-sm hover:bg-blue-50 flex items-center gap-1"
                                >
                                    <i class="fas fa-phone"></i> 第三次跟进
                                </button>
                                <button 
                                    v-else-if="item.followups && item.followups.length >= 3"
                                    disabled
                                    class="text-gray-400 text-[10px] bg-gray-100 border border-gray-200 px-2 py-1 rounded shadow-sm flex items-center gap-1"
                                >
                                    <i class="fas fa-check-circle"></i> 已完成三次跟进
                                </button>
                            </div>
                            
                            <!-- 已有的跟进记录 -->
                            <div v-if="item.followups && item.followups.length > 0" class="mt-2">
                                <div v-for="(followup, index) in item.followups" :key="index" class="text-xs bg-gray-50 p-2 rounded mb-1">
                                    <div class="font-bold text-gray-700">第{{ followup.followup_count }}次跟进 ({{ followup.created_at }})</div>
                                    <div class="text-gray-600" v-if="followup.summary">
                                        <span class="bg-blue-100 text-blue-600 px-1 rounded mr-1">{{ followup.summary }}</span>
                                        {{ followup.content }}
                                    </div>
                                    <div class="text-gray-600" v-else>{{ followup.content }}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="fixed bottom-0 w-full max-w-md bg-white border-t border-slate-100 flex justify-around py-3 text-[10px] text-gray-400 z-50 glass-nav shadow-[0_-5px_15px_rgba(0,0,0,0.02)]">
        <div @click="tab='dash'" :class="tab=='dash'?'text-blue-600 font-bold':''" class="flex flex-col items-center gap-1 cursor-pointer"><i class="fas fa-chart-pie text-lg"></i><span>数据</span></div>
        <div @click="tab='form'" :class="tab=='form'?'text-blue-600 font-bold':''" class="flex flex-col items-center gap-1 cursor-pointer"><i class="fas fa-pen-to-square text-lg"></i><span>报备</span></div>
        <div v-if="userInfo.role == 'admin' || userInfo.role == 'staff'" @click="goToWorkbench" class="flex flex-col items-center gap-1 cursor-pointer"><i class="fas fa-check-double text-lg"></i><span>工作台</span></div>
        <div @click="tab='list'" :class="tab=='list'?'text-blue-600 font-bold':''" class="flex flex-col items-center gap-1 cursor-pointer"><i class="fas fa-clock-rotate-left text-lg"></i><span>记录</span></div>
    </div>

    <div v-if="showModal" class="modal-overlay" @click.self="showModal=false">
        <div class="modal-content flex flex-col">
            <div class="close-btn" @click="showModal=false">&times;</div>
            <h3 class="font-bold text-lg mb-4 text-slate-800">进度信息</h3>
            <div class="flex-1 overflow-y-auto pr-2">
                <div class="pl-2">
                    <div v-for="(log, idx) in parseLog(currentItem.status_log)" :key="idx" class="timeline-item">
                        <div class="timeline-dot" :class="idx===0?'active':''"></div>
                        <div class="text-xs text-gray-400 mb-1">{{ log.time }}</div>
                        <div class="text-sm font-bold text-slate-700">{{ log.title }}</div>
                        <div v-if="log.desc" class="text-xs text-gray-500 bg-gray-50 p-2 rounded mt-1">{{ log.desc }}</div>
                    </div>
                </div>
            </div>
            <button @click="showModal=false" class="w-full bg-slate-100 text-slate-500 py-3 rounded-xl font-bold mt-4 text-sm">关闭进度</button>
        </div>
    </div>

    <div v-if="showFilingModal" class="modal-overlay" @click.self="showFilingModal=false">
        <div class="modal-content flex flex-col">
            <div class="close-btn" @click="showFilingModal=false">&times;</div>
            <h3 class="font-bold text-lg mb-4 text-slate-800">报备信息</h3>
            <div class="flex-1 overflow-y-auto pr-2 space-y-3">
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">报备楼盘</div>
                    <div class="text-sm font-bold text-slate-700">{{ currentItem.project_name }}</div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">门店名称</div>
                    <div class="text-sm font-bold text-slate-700">{{ currentItem.company_name }}</div>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div class="bg-gray-50 rounded-xl p-3">
                        <div class="text-xs text-gray-500 font-bold mb-1">经纪人姓名</div>
                        <div class="text-sm font-bold text-slate-700">{{ currentItem.broker_name }}</div>
                    </div>
                    <div class="bg-gray-50 rounded-xl p-3">
                        <div class="text-xs text-gray-500 font-bold mb-1">经纪人电话</div>
                        <div class="text-sm font-bold text-slate-700">{{ currentItem.broker_phone }}</div>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div class="bg-gray-50 rounded-xl p-3">
                        <div class="text-xs text-gray-500 font-bold mb-1">客户姓名</div>
                        <div class="text-sm font-bold text-slate-700">{{ currentItem.client_name }}</div>
                    </div>
                    <div class="bg-gray-50 rounded-xl p-3">
                        <div class="text-xs text-gray-500 font-bold mb-1">客户电话</div>
                        <div class="text-sm font-bold text-slate-700">{{ currentItem.client_phone }}</div>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div class="bg-gray-50 rounded-xl p-3">
                        <div class="text-xs text-gray-500 font-bold mb-1">经纪人人数</div>
                        <div class="text-sm font-bold text-slate-700">{{ currentItem.broker_num }} 人</div>
                    </div>
                    <div class="bg-gray-50 rounded-xl p-3">
                        <div class="text-xs text-gray-500 font-bold mb-1">客户人数</div>
                        <div class="text-sm font-bold text-slate-700">{{ currentItem.client_num }} 人</div>
                    </div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">带看日期</div>
                    <div class="text-sm font-bold text-slate-700">{{ currentItem.visit_time || '-' }}</div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">指定销售</div>
                    <div class="text-sm font-bold text-slate-700">{{ currentItem.designated_sales || '无' }}</div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">客户意向度</div>
                    <div class="text-sm font-bold text-slate-700">
                        {{ currentItem.client_intention == 5 ? '非常强烈' : 
                           currentItem.client_intention == 4 ? '强烈' : 
                           currentItem.client_intention == 3 ? '一般' : 
                           currentItem.client_intention == 2 ? '还行' : 
                           currentItem.client_intention == 1 ? '无意向' : '未设置' }}
                    </div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">备注</div>
                    <div class="text-sm text-slate-700">{{ currentItem.remark || '无' }}</div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">提交时间</div>
                    <div class="text-sm text-slate-700">{{ currentItem.created_at }}</div>
                </div>
            </div>
            <button @click="showFilingModal=false" class="w-full bg-slate-100 text-slate-500 py-3 rounded-xl font-bold mt-4 text-sm">关闭</button>
        </div>
    </div>

    <div v-if="showEditFilingModal" class="modal-overlay" @click.self="showEditFilingModal=false">
        <div class="modal-content flex flex-col">
            <div class="close-btn" @click="showEditFilingModal=false">&times;</div>
            <h3 class="font-bold text-lg mb-4 text-slate-800">修改报备信息</h3>
            <div class="flex-1 overflow-y-auto pr-2 space-y-3">
                <div class="grid grid-cols-1 gap-3">
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">客户姓名</label>
                        <input v-model="editFilingForm.client_name" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入客户姓名">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">客户电话</label>
                        <input v-model="editFilingForm.client_phone" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入客户电话">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">公司名称</label>
                        <input v-model="editFilingForm.company_name" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入公司名称">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">经纪人姓名</label>
                        <input v-model="editFilingForm.broker_name" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入经纪人姓名">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">经纪人电话</label>
                        <input v-model="editFilingForm.broker_phone" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入经纪人电话">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">待看日期</label>
                        <input type="date" v-model="editFilingForm.visit_date" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">备注</label>
                        <textarea v-model="editFilingForm.remark" rows="3" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入备注信息"></textarea>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-2 gap-2 mt-4">
                <button @click="showEditFilingModal=false" class="bg-slate-100 text-slate-500 py-3 rounded-xl font-bold text-sm">取消</button>
                <button @click="submitEditFiling" class="bg-blue-600 text-white py-3 rounded-xl font-bold text-sm">保存修改</button>
            </div>
        </div>
    </div>

    <div v-if="showModal" class="modal-overlay" @click.self="showModal=false">
        <div class="modal-content flex flex-col">
            <div class="close-btn" @click="showModal=false">&times;</div>
            <h3 class="font-bold text-lg mb-4 text-slate-800">进度信息</h3>
            <div class="flex-1 overflow-y-auto pr-2">
                <div class="pl-2">
                    <div v-for="(log, idx) in parseLog(currentItem.status_log)" :key="idx" class="timeline-item">
                        <div class="timeline-dot" :class="idx===0?'active':''"></div>
                        <div class="text-xs text-gray-400 mb-1">{{ log.time }}</div>
                        <div class="text-sm font-bold text-slate-700">{{ log.title }}</div>
                        <div v-if="log.desc" class="text-xs text-gray-500 bg-gray-50 p-2 rounded mt-1">{{ log.desc }}</div>
                    </div>
                </div>
            </div>
            <button @click="showModal=false" class="w-full bg-slate-100 text-slate-500 py-3 rounded-xl font-bold mt-4 text-sm">关闭进度</button>
        </div>
    </div>

    <div v-if="showFilingModal" class="modal-overlay" @click.self="showFilingModal=false">
        <div class="modal-content flex flex-col">
            <div class="close-btn" @click="showFilingModal=false">&times;</div>
            <h3 class="font-bold text-lg mb-4 text-slate-800">报备信息</h3>
            <div class="flex-1 overflow-y-auto pr-2 space-y-3">
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="grid grid-cols-2 gap-2 text-xs">
                        <div class="text-gray-400">项目名称</div><div class="font-bold">{{ currentItem.project_name }}</div>
                        <div class="text-gray-400">客户姓名</div><div class="font-bold">{{ currentItem.client_name }}</div>
                        <div class="text-gray-400">客户电话</div><div class="font-mono">{{ currentItem.client_phone }}</div>
                        <div class="text-gray-400">公司名称</div><div class="font-bold">{{ currentItem.company_name || '-' }}</div>
                        <div class="text-gray-400">经纪人</div><div class="font-bold">{{ currentItem.broker_name || '-' }}</div>
                        <div class="text-gray-400">经纪人电话</div><div class="font-mono">{{ currentItem.broker_phone || '-' }}</div>
                        <div class="text-gray-400">报备时间</div><div>{{ currentItem.created_at }}</div>
                        <div class="text-gray-400">状态</div><div :class="statusClass(currentItem.status)">{{ statusText(currentItem.status) }}</div>
                    </div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">带看人数</div>
                    <div class="text-sm font-bold text-slate-700">{{ currentItem.client_num || 1 }} 人</div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">带看日期</div>
                    <div class="text-sm font-bold text-slate-700">{{ currentItem.visit_time || '-' }}</div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">指定销售</div>
                    <div class="text-sm font-bold text-slate-700">{{ currentItem.designated_sales || '无' }}</div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">客户意向度</div>
                    <div class="text-sm font-bold text-slate-700">
                        {{ currentItem.client_intention == 5 ? '非常强烈' : 
                           currentItem.client_intention == 4 ? '强烈' : 
                           currentItem.client_intention == 3 ? '一般' : 
                           currentItem.client_intention == 2 ? '还行' : 
                           currentItem.client_intention == 1 ? '无意向' : '未设置' }}
                    </div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">备注</div>
                    <div class="text-sm text-slate-700">{{ currentItem.remark || '无' }}</div>
                </div>
                <div class="bg-gray-50 rounded-xl p-3">
                    <div class="text-xs text-gray-500 font-bold mb-1">提交时间</div>
                    <div class="text-sm text-slate-700">{{ currentItem.created_at }}</div>
                </div>
            </div>
            <button @click="showFilingModal=false" class="w-full bg-slate-100 text-slate-500 py-3 rounded-xl font-bold mt-4 text-sm">关闭</button>
        </div>
    </div>

    <div v-if="showEditFilingModal" class="modal-overlay" @click.self="showEditFilingModal=false">
        <div class="modal-content flex flex-col">
            <div class="close-btn" @click="showEditFilingModal=false">&times;</div>
            <h3 class="font-bold text-lg mb-4 text-slate-800">修改报备信息</h3>
            <div class="flex-1 overflow-y-auto pr-2 space-y-3">
                <div class="grid grid-cols-1 gap-3">
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">客户姓名</label>
                        <input v-model="editFilingForm.client_name" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入客户姓名">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">客户电话</label>
                        <input v-model="editFilingForm.client_phone" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入客户电话">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">公司名称</label>
                        <input v-model="editFilingForm.company_name" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入公司名称">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">经纪人姓名</label>
                        <input v-model="editFilingForm.broker_name" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入经纪人姓名">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">经纪人电话</label>
                        <input v-model="editFilingForm.broker_phone" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入经纪人电话">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">带看日期</label>
                        <input type="date" v-model="editFilingForm.visit_time" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">指定销售</label>
                        <input v-model="editFilingForm.designated_sales" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="选填">
                    </div>
                    <div>
                        <label class="text-xs text-gray-500 mb-1 block">备注</label>
                        <textarea v-model="editFilingForm.remark" rows="3" class="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="请输入备注信息"></textarea>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-2 gap-2 mt-4">
                <button @click="showEditFilingModal=false" class="bg-slate-100 text-slate-500 py-3 rounded-xl font-bold text-sm">取消</button>
                <button @click="submitEditFiling" class="bg-blue-600 text-white py-3 rounded-xl font-bold text-sm">保存修改</button>
            </div>
        </div>
    </div>

    <div v-if="showEdit" class="modal-overlay" @click.self="showEdit=false">
        <div class="modal-content flex flex-col">
            <div class="close-btn" @click="showEdit=false">&times;</div>
            <h3 class="font-bold text-lg mb-4 text-slate-800">跟进进度录入</h3>
            <div class="space-y-4">
                <label class="text-xs font-bold text-slate-500 block">下定进度 (可多选)</label>
                <div class="grid grid-cols-3 gap-3 mb-2">
                    <div @click="toggleStage('deposit')" class="stage-box" :class="{checked: editSubStages.includes('deposit')}"><div class="stage-icon"><i class="fas fa-check" v-if="editSubStages.includes('deposit')"></i></div><span class="text-xs font-bold">交定金</span></div>
                    <div @click="toggleStage('lock')" class="stage-box" :class="{checked: editSubStages.includes('lock')}"><div class="stage-icon"><i class="fas fa-check" v-if="editSubStages.includes('lock')"></i></div><span class="text-xs font-bold">锁房号</span></div>
                    <div @click="toggleStage('sign')" class="stage-box" :class="{checked: editSubStages.includes('sign')}"><div class="stage-icon"><i class="fas fa-check" v-if="editSubStages.includes('sign')"></i></div><span class="text-xs font-bold">签认购书</span></div>
                </div>
                <div class="bg-gray-50 rounded-2xl p-4 border border-gray-100">
                    <div class="text-xs text-gray-500 font-bold mb-2">备注说明</div>
                    <textarea v-model="editVoice" placeholder="填写跟进情况..." class="w-full bg-white rounded-xl p-2 h-16 border border-gray-200 text-xs resize-none outline-none"></textarea>
                </div>
            </div>
            <button @click="submitUpdate" class="w-full bg-blue-600 text-white py-3 rounded-xl font-bold shadow-lg mt-6 text-sm active:scale-95 transition">保存进度</button>
        </div>
    </div>

    <div v-if="showFollowupModal" class="modal-overlay" @click.self="showFollowupModal=false">
        <div class="modal-content flex flex-col">
            <div class="close-btn" @click="showFollowupModal=false">&times;</div>
            <h3 class="font-bold text-lg mb-4 text-slate-800">第{{ currentFollowupCount }}次跟进</h3>
            <div class="space-y-4">
                <div class="bg-gray-50 rounded-2xl p-4 border border-gray-100">
                    <div class="text-xs text-gray-500 font-bold mb-2">跟进概述</div>
                    <select v-model="followupSummary" class="w-full bg-white rounded-xl p-2 border border-gray-200 text-xs outline-none">
                        <option value="">请选择跟进概述</option>
                        <option v-for="summary in followupSummaries[currentFollowupCount]" :key="summary" :value="summary">{{ summary }}</option>
                    </select>
                </div>
                <div class="bg-gray-50 rounded-2xl p-4 border border-gray-100">
                    <div class="text-xs text-gray-500 font-bold mb-2">跟进内容</div>
                    <textarea v-model="followupContent" placeholder="请详细描述跟进情况..." class="w-full bg-white rounded-xl p-2 h-32 border border-gray-200 text-xs resize-none outline-none"></textarea>
                </div>
                <div class="text-xs text-gray-400">
                    <span v-if="currentFollowupCount === 1">
                        距离记录变成有效时间已过去 {{ calculateFollowupTime(currentFollowupItem, 1) }} 分钟
                    </span>
                    <span v-else-if="currentFollowupCount === 2">
                        距离第一次跟进已过去 {{ calculateFollowupTime(currentFollowupItem, 2) }} 分钟
                    </span>
                    <span v-else-if="currentFollowupCount === 3">
                        距离第二次跟进已过去 {{ calculateFollowupTime(currentFollowupItem, 3) }} 分钟
                    </span>
                </div>
            </div>
            <div class="grid grid-cols-2 gap-2 mt-6">
                <button @click="showFollowupModal=false" class="bg-slate-100 text-slate-500 py-3 rounded-xl font-bold text-sm">取消</button>
                <button @click="submitFollowup" class="bg-blue-600 text-white py-3 rounded-xl font-bold text-sm">提交跟进</button>
            </div>
        </div>
    </div>

</div>

<script>
const { createApp, ref, onMounted, computed, nextTick, watch } = Vue;
createApp({
    setup() {
        const tab = ref('dash');
        const list = ref([]);
        const stats = ref({ comm:0, total:0, deal:0, visit:0, chart:[] });
        const projects = ref([]);
        const smartText = ref('');
        const subTab = ref(0); 
        const childFilter = ref('todo'); 
        const search = ref({ keyword: '', projectId: '', dateStart: '', dateEnd: '' });
        const isParsing = ref(false); // AI加载状态
        
        const userInfo = <?php echo json_encode($CURRENT_USER); ?>;
        
        const form = ref({
            project_ids: [],
            company_name: '', follower: '', broker_name: userInfo.name, broker_phone: userInfo.phone, 
            broker_num: 2, client_name: '', client_phone: '', client_num: 2, 
            visit_date: new Date().toISOString().slice(0, 10), designated_sales: '', remark: ''
        });
        const showAllProjects = ref(false);

        const companyResults = ref([]);
        const showDropdown = ref(false);
        const showModal = ref(false);
        const showFilingModal = ref(false);
        const showEditFilingModal = ref(false);
        const showEdit = ref(false);
        const showFilters = ref(false);
        const isSearchingHistory = ref(false);
        const currentItem = ref({});
        const editFilingForm = ref({});
        const editSubStages = ref([]);
        const editVoice = ref('');
        let searchTimer = null;
        
        // 跟进相关状态
        const showFollowupModal = ref(false);
        const currentFollowupItem = ref({});
        const followupContent = ref('');
        const currentFollowupCount = ref(1);
        const followups = ref([]);
        const followupLoading = ref(false);

        const tabs = [{id: 0, name: '全部'}, {id: 1, name: '待接待'}, {id: 2, name: '待下定'}, {id: 3, name: '待签约'}, {id: 4, name: '已完成'}];

        const counts = computed(() => {
            const c = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0};
            list.value.forEach(i => { c[0]++; if (c[i.status] !== undefined) c[i.status]++; });
            return c;
        });

        const filteredList = computed(() => {
            return list.value.filter(item => {
                // 如果选择了日期范围，忽略状态筛选，显示所有状态但在日期范围内的记录
                const hasDateFilter = search.value.dateStart || search.value.dateEnd;
                
                if (!hasDateFilter && subTab.value !== 0) {
                    if (subTab.value === 1) {
                        if (childFilter.value === 'todo') { if (item.status != 1) return false; }
                        else if (childFilter.value === 'valid_report') { if (item.status != 1 || item.visit_type != 0) return false; }
                        else if (childFilter.value === 'valid') { if (item.status != 2 || item.visit_type != 1) return false; }
                        else if (childFilter.value === 'invalid') { if (!((item.status == 5 && item.visit_type == 2) || item.status == 6)) return false; }
                        else if (childFilter.value === 'repeat') { if (!(item.status == 5 && item.visit_type == 3)) return false; }
                    }
                    else if (subTab.value === 2) {
                        if (item.status != 2) return false;
                        if (childFilter.value !== 'all') {
                            if (!item.sub_stages || !item.sub_stages.includes(childFilter.value)) return false;
                        }
                    }
                    else { if (item.status != subTab.value) return false; }
                }
                const k = search.value.keyword.trim();
                if (k) {
                    const statusStr = statusText(item.status);
                    const stageText = (item.sub_stages || '').replace('deposit','交定金').replace('lock','锁房号').replace('sign','签认购书');
                    const match = item.client_name.includes(k) || item.client_phone.includes(k) || item.project_name.includes(k) || 
                                statusStr.includes(k) || stageText.includes(k) ||
                                (item.broker_name && item.broker_name.includes(k)) ||
                                (item.broker_phone && item.broker_phone.includes(k)) ||
                                (item.agent_name && item.agent_name.includes(k)) ||
                                (item.agent_phone && item.agent_phone.includes(k)) ||
                                (item.company_name && (item.company_name.includes(k) || k.includes(item.company_name))) ||
                                (item.company_full_name && (item.company_full_name.includes(k) || k.includes(item.company_full_name))) ||
                                (item.store_name && (item.store_name.includes(k) || k.includes(item.store_name)));
                    if (!match) return false;
                }
                const f = search.value;
                if (f.projectId && item.project_id != f.projectId) return false;
                if (f.dateStart && item.created_at < f.dateStart) return false;
                if (f.dateEnd && item.created_at > f.dateEnd + ' 23:59:59') return false;
                return true;
            });
        });

        const groupedList = computed(() => {
            const groups = {};
            filteredList.value.forEach(item => {
                const key = item.client_phone;
                if (!groups[key]) groups[key] = { client_name: item.client_name, client_phone: item.client_phone, items: [] };
                groups[key].items.push(item);
            });
            // 对每个分组内的项目按时间倒序排列
            Object.values(groups).forEach(group => {
                group.items.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
            });
            // 对分组本身按最新项目时间倒序排列
            return Object.values(groups).sort((a, b) => new Date(b.items[0].created_at) - new Date(a.items[0].created_at));
        });

        const loadProjects = () => {
            fetch('?action=get_projects').then(r=>r.json()).then(d=>projects.value=d);
        };

        const loadAllData = () => {
            if(!form.value.broker_phone) return;
            fetch('?action=get_list&phone=' + form.value.broker_phone).then(r=>r.json()).then(d=>list.value=d);
            fetch('?action=get_stats&phone=' + form.value.broker_phone).then(r=>r.json()).then(d=> { stats.value = d; if(tab.value==='dash') drawChart(); });
        };
        
        const searchHistory = async () => {
            const keyword = search.value.keyword.trim();
            if(!keyword) {
                // 当搜索条件为空时，加载全部内容
                loadAllData();
                return;
            }
            
            isSearchingHistory.value = true;
            try {
                const res = await fetch('?action=search_history&keyword=' + encodeURIComponent(keyword));
                const data = await res.json();
                list.value = Array.isArray(data) ? data : [];
                
                if(list.value.length === 0) {
                    alert('未找到匹配的历史记录');
                } else {
                    alert(`找到 ${list.value.length} 条历史记录`);
                }
            } catch (e) {
                alert('搜索失败');
            } finally {
                isSearchingHistory.value = false;
            }
        };

        const searchCompany = () => {
            if (searchTimer) clearTimeout(searchTimer);
            searchTimer = setTimeout(async () => {
                const kw = form.value.company_name;
                if (!kw) {
                    companyResults.value = [];
                    return;
                }
                const res = await fetch('?action=search_company&kw=' + encodeURIComponent(kw));
                const data = await res.json();
                companyResults.value = Array.isArray(data) ? data : [];
                if(companyResults.value.length > 0) showDropdown.value = true;
            }, 300);
        };

        // 选择公司
        const selectCompany = (company) => {
            form.value.company_name = company.name;
            form.value.follower = company.follower || '';
            showDropdown.value = false;
        };
        
        // 格式化手机号为前三后四中间星号
        const formatPhone = () => {
            let phone = form.value.client_phone;
            // 移除所有非数字字符
            phone = phone.replace(/\D/g, '');
            // 如果手机号长度大于等于7，格式化为前三后四中间星号
            if (phone.length >= 7) {
                form.value.client_phone = phone.substring(0, 3) + '****' + phone.substring(phone.length - 4);
            }
        };
        
        // 加载所有可能的跟进人（从agents表）
        const agents = ref([]);
        const loadAgents = async () => {
            try {
                const res = await fetch('?action=get_agents');
                const data = await res.json();
                agents.value = Array.isArray(data) ? data : [];
            } catch (e) {
                console.error('加载跟进人失败:', e);
            }
        };

        const onCompanyFocus = () => {
            // 当公司名称输入框获得焦点时的处理
            if (form.value.company_name && companyResults.value.length > 0) {
                showDropdown.value = true;
            }
        };

        const submit = async () => {
            if(form.value.project_ids.length === 0) return alert('请至少选择一个楼盘');
            if(!form.value.client_phone) return alert('请填写客户手机号');
            
            // 检查是否存在重复报备
            try {
                const checkFd = new FormData();
                checkFd.append('client_phone', form.value.client_phone);
                checkFd.append('project_ids', form.value.project_ids.join(','));
                const checkRes = await fetch('?action=check_duplicate', {method:'POST', body:checkFd});
                const checkData = await checkRes.json();
                if(checkData.status === 'success' && checkData.data && checkData.data.length > 0) {
                    if(!confirm('发现近期相同客户的报备记录，确定继续提交吗？')) return;
                }
            } catch (e) {
                console.error('检查重复失败:', e);
            }
            
            const fd = new FormData();
            fd.append('project_ids', form.value.project_ids.join(','));
            fd.append('company_name', form.value.company_name);
            fd.append('follower', form.value.follower);
            fd.append('broker_name', form.value.broker_name);
            fd.append('broker_phone', form.value.broker_phone);
            fd.append('broker_num', form.value.broker_num);
            fd.append('client_name', form.value.client_name);
            fd.append('client_phone', form.value.client_phone);
            fd.append('client_num', form.value.client_num);
            fd.append('visit_date', form.value.visit_date);
            fd.append('designated_sales', form.value.designated_sales);
            fd.append('remark', form.value.remark);
            
            const res = await fetch('?action=submit', {method:'POST', body:fd});
            const d = await res.json();
            if(d.status === 'success') { alert(d.msg); loadAllData(); tab.value = 'list'; form.value.project_ids = []; form.value.company_name = ''; form.value.follower = ''; form.value.client_name = ''; form.value.client_phone = ''; form.value.designated_sales = ''; form.value.remark = ''; } else { alert(d.msg); }
        };

        const changeMainTab = (id) => {
            subTab.value = id;
            if(id === 1) childFilter.value = 'todo';
            if(id === 2) childFilter.value = 'all';
        };

        const resetFilter = () => {
            search.value = { keyword: '', projectId: '', dateStart: '', dateEnd: '' };
        };

        const applyFilter = () => {
            // 筛选逻辑已经在computed属性中实现，这里只需要关闭筛选面板
            showFilters.value = false;
        };

        const maskPhone = (phone) => {
            if(!phone) return '';
            return phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
        };

        const toggleStage = (stage) => { if (editSubStages.value.includes(stage)) editSubStages.value = editSubStages.value.filter(s => s !== stage); else editSubStages.value.push(stage); };
        const submitUpdate = async () => { const fd = new FormData(); fd.append('id', currentItem.value.id); fd.append('sub_stages', editSubStages.value.join(',')); fd.append('voice', editVoice.value); const res = await fetch('?action=update_progress', {method:'POST', body:fd}); const d = await res.json(); if(d.status==='success') { alert('进度更新成功'); showEdit.value = false; loadAllData(); } else { alert('更新失败'); } };
        // 打开修改报备模态框
        const openEditFilingModal = (item) => {
            currentItem.value = item;
            editFilingForm.value = {
                id: item.id,
                client_name: item.client_name || '',
                client_phone: item.client_phone || '',
                company_name: item.company_name || '',
                follower: item.follower || '',
                broker_name: item.broker_name || userInfo.name,
                broker_phone: item.broker_phone || userInfo.phone,
                visit_time: item.visit_time || new Date().toISOString().slice(0, 10),
                designated_sales: item.designated_sales || '',
                remark: item.remark || ''
            };
            showEditFilingModal.value = true;
        };
        // 提交修改报备
        const submitEditFiling = async () => {
            if(!editFilingForm.value.client_name) return alert('请填写客户姓名');
            if(!editFilingForm.value.client_phone) return alert('请填写客户电话');
            
            const fd = new FormData();
            fd.append('id', editFilingForm.value.id);
            fd.append('client_name', editFilingForm.value.client_name);
            fd.append('client_phone', editFilingForm.value.client_phone);
            fd.append('company_name', editFilingForm.value.company_name);
            fd.append('follower', editFilingForm.value.follower);
            fd.append('broker_name', editFilingForm.value.broker_name);
            fd.append('broker_phone', editFilingForm.value.broker_phone);
            fd.append('visit_time', editFilingForm.value.visit_time);
            fd.append('designated_sales', editFilingForm.value.designated_sales);
            fd.append('remark', editFilingForm.value.remark);
            
            try {
                const res = await fetch('?action=update_filing', {method:'POST', body:fd});
                const d = await res.json();
                if(d.status==='success') {
                    alert('修改成功');
                    showEditFilingModal.value = false;
                    loadAllData();
                } else {
                    alert('修改失败: ' + (d.msg || '未知错误'));
                }
            } catch (e) {
                alert('修改失败: 网络错误');
            }
        };
        
        const goToWorkbench = () => {
            window.location.href = 'staff.php';
        };
        // 复制报备资料到表单
        const copyFilingData = (item) => {
            // 复制除项目名称外的所有字段
            form.value.company_name = item.company_name || '';
            form.value.follower = item.follower || '';
            form.value.broker_name = item.broker_name || userInfo.name;
            form.value.broker_phone = item.broker_phone || userInfo.phone;
            form.value.broker_num = item.broker_num || 2;
            form.value.client_name = item.client_name || '';
            form.value.client_phone = item.client_phone || '';
            form.value.client_num = item.client_num || 2;
            form.value.visit_date = new Date().toISOString().slice(0, 10);
            form.value.designated_sales = item.designated_sales || '';
            form.value.remark = item.remark || '';
            
            // 切换到报备表单页面
            tab.value = 'form';
            
            // 显示提示
            alert('报备资料已复制到表单，可修改后提交');
        };

        // 核心：AI 智能识别对接
        const smartParse = async () => {
            let txt = smartText.value; if(!txt) return alert('请输入文本');
            isParsing.value = true;
            try {
                const res = await fetch('api_smart_parse.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: txt }) });
                const d = await res.json();
                if (d.status === 'success') {
                    const data = d.data;
                    if (data.company_name) form.value.company_name = data.company_name;
                    if (data.broker_name) form.value.broker_name = data.broker_name;
                    if (data.broker_phone) form.value.broker_phone = data.broker_phone;
                    if (data.broker_num) form.value.broker_num = parseInt(data.broker_num) || 1;
                    if (data.client_name) form.value.client_name = data.client_name;
                    if (data.client_phone) form.value.client_phone = data.client_phone;
                    if (data.client_num) form.value.client_num = parseInt(data.client_num) || 1;
                    if (data.visit_date) form.value.visit_date = data.visit_date;
                    if (data.designated_sales) form.value.designated_sales = data.designated_sales;
                    if (data.remark) form.value.remark = data.remark;
                    if (data.project_keywords && data.project_keywords.length > 0) {
                        const matchedIds = [];
                        data.project_keywords.forEach(kw => {
                            // 找出所有匹配的项目
                            const allMatches = projects.value.filter(p => p.name.includes(kw) || kw.includes(p.name));
                            if (allMatches.length > 0) {
                                // 按优先级排序：不带"商铺"的排在前面
                                allMatches.sort((a, b) => {
                                    const aHasShop = a.name.includes('商铺');
                                    const bHasShop = b.name.includes('商铺');
                                    if (aHasShop && !bHasShop) return 1;
                                    if (!aHasShop && bHasShop) return -1;
                                    return 0;
                                });
                                // 选择排序后的第一个项目（优先选择不带商铺的）
                                const bestMatch = allMatches[0];
                                if (bestMatch && !matchedIds.includes(bestMatch.id)) {
                                    matchedIds.push(bestMatch.id);
                                }
                            }
                        });
                        if (matchedIds.length > 0) form.value.project_ids = matchedIds;
                    }
                    alert('识别成功！请核对信息');
                } else { alert(d.msg || '识别失败'); }
            } catch (e) { alert('AI 接口连接失败'); } finally { isParsing.value = false; }
        };

        const statusText = (s) => ['待审','有效','到访','下定','成交','无效'][s]||'';
        const statusClass = (s) => ['bg-gray-100 text-gray-500 border-gray-200','bg-blue-50 text-blue-600 border-blue-200','bg-yellow-50 text-yellow-600 border-yellow-200','bg-orange-50 text-orange-600 border-orange-200','bg-green-50 text-green-600 border-green-200','bg-red-50 text-red-500 border-red-200'][s];
        const commText = (s) => ['待确认','待发放','已发放'][s] || '未知';
        const commColor = (s) => ['bg-gray-100 text-gray-500 border-gray-200','bg-yellow-50 text-yellow-600 border-yellow-200','bg-green-50 text-green-600 border-green-200'][s];

        const drawChart = () => {
            if(!stats.value.chart_data) return;
            const chartDom = document.getElementById('chart');
            if(!chartDom) return;
            const myChart = echarts.init(chartDom);
            const option = {
                tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
                legend: { data: ['报备', '到访', '成交'], textStyle: { fontSize: 10 }, bottom: 0 },
                grid: { left: '3%', right: '4%', bottom: '15%', top: '15%', containLabel: true },
                xAxis: { type: 'category', data: stats.value.chart_labels, axisLabel: { fontSize: 10 } },
                yAxis: { type: 'value', axisLabel: { fontSize: 10 } },
                series: [
                    { name: '报备', type: 'line', stack: 'Total', smooth: true, lineStyle: { width: 3 }, itemStyle: { color: '#3b82f6' }, areaStyle: { color: 'rgba(59, 130, 246, 0.2)' }, data: stats.value.chart_data.report },
                    { name: '到访', type: 'line', stack: 'Total', smooth: true, lineStyle: { width: 3 }, itemStyle: { color: '#22c55e' }, areaStyle: { color: 'rgba(34, 197, 94, 0.2)' }, data: stats.value.chart_data.visit },
                    { name: '成交', type: 'line', stack: 'Total', smooth: true, lineStyle: { width: 3 }, itemStyle: { color: '#f97316' }, areaStyle: { color: 'rgba(249, 115, 22, 0.2)' }, data: stats.value.chart_data.deal }
                ]
            };
            option && myChart.setOption(option);
            window.addEventListener('resize', () => myChart.resize());
        };

        const parseLog = (logStr) => { if(!logStr) return []; return logStr.split('\n').filter(l => l.trim()).map(l => { const parts = l.split('] '); return { time: parts[0] ? parts[0].replace('[', '').trim() : '', title: parts[1]?.split(' (')[0] || parts[1], desc: parts[1]?.includes('(') ? parts[1].split('(')[1].replace(')', '') : '' }; }).reverse(); };
        const showTimeline = (item) => { currentItem.value = item; showModal.value = true; };
        const showFilingInfo = (item) => { currentItem.value = item; showFilingModal.value = true; };
        const openEditModal = (item) => { currentItem.value = item; editSubStages.value = item.sub_stages ? item.sub_stages.split(',') : []; editVoice.value = ''; showEdit.value = true; };
        
        // 计算跟进时间
        const calculateFollowupTime = (item, followupCount) => {
            const itemFollowups = item.followups || [];
            if (followupCount === 1) {
                // 第一次跟进，计算从有效时间到现在的分钟数
                const validTime = new Date(item.created_at);
                const now = new Date();
                const minutes = Math.floor((now - validTime) / (1000 * 60));
                return minutes;
            } else {
                // 后续跟进，计算从上一次跟进到现在的分钟数
                const lastFollowup = itemFollowups.find(f => f.followup_count === followupCount - 1);
                if (lastFollowup) {
                    const lastTime = new Date(lastFollowup.created_at);
                    const now = new Date();
                    const minutes = Math.floor((now - lastTime) / (1000 * 60));
                    return minutes;
                }
                return 0;
            }
        };
        
        // 加载跟进记录
        const loadFollowups = async (filingId) => {
            followupLoading.value = true;
            try {
                const res = await fetch('?action=get_followups&filing_id=' + filingId);
                const data = await res.json();
                if (data.status === 'success') {
                    followups.value = data.data;
                }
            } catch (e) {
                console.error('加载跟进记录失败:', e);
            } finally {
                followupLoading.value = false;
            }
        };
        
        // 跟进概述选项
        const followupSummaries = {
            1: ['飞机客', '在路上', '看二手房', '失联', '已到项目'],
            2: ['看完二手走了', '已到项目', '失联'],
            3: ['持续跟进', '要价低', '不买了']
        };
        
        // 跟进概述
        const followupSummary = ref('');
        
        // 打开跟进模态框
        const openFollowupModal = (item, followupCount) => {
            currentFollowupItem.value = item;
            currentFollowupCount.value = followupCount;
            followupContent.value = '';
            followupSummary.value = '';
            showFollowupModal.value = true;
        };
        
        // 提交跟进记录
        const submitFollowup = async () => {
            if (!followupContent.value.trim()) {
                return alert('请填写跟进内容');
            }
            
            const fd = new FormData();
            fd.append('filing_id', currentFollowupItem.value.id);
            fd.append('followup_count', currentFollowupCount.value);
            fd.append('content', followupContent.value);
            fd.append('summary', followupSummary.value);
            
            try {
                const res = await fetch('?action=submit_followup', {method: 'POST', body: fd});
                const data = await res.json();
                if (data.status === 'success') {
                    alert('跟进记录提交成功');
                    showFollowupModal.value = false;
                    // 重新加载数据，确保跟进记录更新
                    setTimeout(() => {
                        loadAllData();
                    }, 500);
                } else {
                    alert('提交失败: ' + (data.msg || '未知错误'));
                }
            } catch (e) {
                alert('提交失败: 网络错误');
            }
        };
        
        // 获取下一次跟进次数
        const getNextFollowupCount = (item) => {
            const itemFollowups = item.followups || [];
            const existingCounts = itemFollowups.map(f => parseInt(f.followup_count));
            for (let i = 1; i <= 3; i++) {
                if (!existingCounts.includes(i)) {
                    return i;
                }
            }
            return null;
        };

        watch(tab, (v) => {
            if(v==='dash') { 
                if(stats.value.total) drawChart(); 
                else loadAllData(); 
            } else if(v==='list' && !isSearchingHistory.value) {
                loadAllData();
            }
        });
        onMounted(() => {
            childFilter.value = 'todo';
            loadProjects();
            loadAllData();
            loadAgents();
            
            // 检查是否有复制的报备数据
            const copyData = localStorage.getItem('copyFilingData');
            if (copyData) {
                try {
                    const item = JSON.parse(copyData);
                    // 复制数据到表单
                    form.value.company_name = item.company_name || '';
                    form.value.follower = item.follower || '';
                    form.value.broker_name = item.broker_name || userInfo.name;
                    form.value.broker_phone = item.broker_phone || userInfo.phone;
                    form.value.broker_num = item.broker_num || 2;
                    form.value.client_name = item.client_name || '';
                    form.value.client_phone = item.client_phone || '';
                    form.value.client_num = item.client_num || 2;
                    form.value.visit_date = new Date().toISOString().slice(0, 10);
                    form.value.designated_sales = item.designated_sales || '';
                    form.value.remark = item.remark || '';
                    
                    // 切换到报备表单页面
                    tab.value = 'form';
                    
                    // 显示提示
                    alert('报备资料已复制到表单，可修改后提交');
                } catch (e) {
                    console.error('解析复制数据失败:', e);
                } finally {
                    // 清除localStorage中的数据
                    localStorage.removeItem('copyFilingData');
                }
            }
        });

        return {
            tab, list, projects, form, smartText, companyResults, showDropdown, showModal, showFilingModal, showEditFilingModal, currentItem, editFilingForm, search, filteredList, stats,
            subTab, tabs, counts, showFilters, resetFilter, applyFilter, groupedList, childFilter, showEdit, editSubStages, editVoice, isParsing, isSearchingHistory, agents,
            searchCompany, selectCompany, submit, smartParse, showTimeline, showFilingInfo, parseLog, loadAllData, onCompanyFocus, loadAgents, formatPhone,
            statusText, statusClass, commText, commColor, showAllProjects, maskPhone, changeMainTab, openEditModal, toggleStage, submitUpdate,
            copyFilingData, searchHistory, openEditFilingModal, submitEditFiling, goToWorkbench, userInfo,
            // 跟进相关
            showFollowupModal, currentFollowupItem, followupContent, followupSummary, followupSummaries, currentFollowupCount, followups, followupLoading,
            calculateFollowupTime, openFollowupModal, submitFollowup, getNextFollowupCount, loadFollowups
        }
    }
}).mount('#app');
</script>
</body>
</html>