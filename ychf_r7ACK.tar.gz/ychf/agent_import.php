<?php
// agent_import.php - 经纪人数据导入与管理页面
session_start();
header('Content-Type: text/html; charset=utf-8');

// === 0. 登录鉴权 (已取消) ===
// if (!isset($_SESSION['agent_id'])) { header('Location: login.php'); exit; }
$CURRENT_USER = [
    'id' => 1,
    'name' => '管理员',
    'phone' => '13800138000',
    'company' => '系统管理',
    'role' => 'admin'
];

// === 1. 数据库连接 ===
$host = '127.0.0.1'; $db = 'ychf'; $user = 'ychf'; $pass = 'rjX5DESSbGXbewfa'; $charset = 'utf8mb4';
try { $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass); } catch (PDOException $e) { die("DB Error: " . $e->getMessage()); }

$action = $_GET['action'] ?? 'view';

// 创建经纪人数据表（如果不存在）
$createTableSql = "CREATE TABLE IF NOT EXISTS agents_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    agent_name VARCHAR(100) NOT NULL,
    agent_phone VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_agent (agent_name, agent_phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
$pdo->exec($createTableSql);

// [API] 获取经纪人数据列表
if ($action == 'get_agents_list') {
    // 确保返回JSON格式
    header('Content-Type: application/json');
    
    try {
        $keyword = $_GET['keyword'] ?? '';
        $sortBy = $_GET['sort_by'] ?? 'id';
        $sortOrder = $_GET['sort_order'] ?? 'desc';
        $page = intval($_GET['page'] ?? 1);
        $pageSize = intval($_GET['pageSize'] ?? 10);
        $offset = ($page - 1) * $pageSize;
        
        // 验证排序字段和顺序
        $validSortFields = ['id', 'company_name', 'agent_name', 'agent_phone', 'monthly_filings', 'total_filings'];
        $sortBy = in_array($sortBy, $validSortFields) ? $sortBy : 'id';
        $sortOrder = ($sortOrder == 'asc') ? 'asc' : 'desc';
        
        // 构建查询
        $whereClause = "WHERE 1=1";
        $params = [];
        
        if (!empty($keyword)) {
            $whereClause .= " AND (company_name LIKE ? OR agent_name LIKE ? OR agent_phone LIKE ?)";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
            $params[] = "%$keyword%";
        }
        
        // 获取总记录数
        $countSql = "SELECT COUNT(*) FROM agents_data $whereClause";
        $countStmt = $pdo->prepare($countSql);
        $countStmt->execute($params);
        $total = $countStmt->fetchColumn();
        
        // 获取分页数据
        $dataSql = "SELECT * FROM agents_data $whereClause ORDER BY $sortBy $sortOrder LIMIT ? OFFSET ?";
        $dataStmt = $pdo->prepare($dataSql);
        
        // 绑定参数
        foreach ($params as $i => $param) {
            $dataStmt->bindValue($i + 1, $param, PDO::PARAM_STR);
        }
        $dataStmt->bindValue(count($params) + 1, $pageSize, PDO::PARAM_INT);
        $dataStmt->bindValue(count($params) + 2, $offset, PDO::PARAM_INT);
        
        $dataStmt->execute();
        $data = $dataStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 为每个经纪人添加报备数量
        foreach ($data as &$agent) {
            // 改进匹配逻辑，考虑姓名或电话任一匹配
            // 当月报备数量
            $monthlySql = "SELECT COUNT(*) FROM filings WHERE (broker_name = ? OR broker_phone = ?) AND created_at >= DATE_FORMAT(NOW(), '%Y-%m-01')";
            $monthlyStmt = $pdo->prepare($monthlySql);
            $monthlyStmt->execute([$agent['agent_name'], $agent['agent_phone']]);
            $agent['monthly_filings'] = $monthlyStmt->fetchColumn();
            
            // 历史总报备数量
            $totalSql = "SELECT COUNT(*) FROM filings WHERE (broker_name = ? OR broker_phone = ?)";
            $totalStmt = $pdo->prepare($totalSql);
            $totalStmt->execute([$agent['agent_name'], $agent['agent_phone']]);
            $agent['total_filings'] = $totalStmt->fetchColumn();
        }
        
        // 返回带分页的数据
        echo json_encode([
            'data' => $data,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize
        ]);
    } catch (Exception $e) {
        // 如果出现错误，返回空数组
        echo json_encode(['data' => [], 'total' => 0, 'page' => 1, 'pageSize' => 10]);
    } catch (Error $e) {
        // 如果出现错误，返回空数组
        echo json_encode(['data' => [], 'total' => 0, 'page' => 1, 'pageSize' => 10]);
    }
    exit;
}

// [API] 删除经纪人数据
if ($action == 'delete_agent') {
    header('Content-Type: application/json');
    $id = $_POST['id'] ?? 0;
    
    if (empty($id)) {
        echo json_encode(['status' => 'error', 'msg' => '数据ID不能为空']);
        exit;
    }
    
    try {
        $sql = "DELETE FROM agents_data WHERE id = ?";
        $pdo->prepare($sql)->execute([$id]);
        echo json_encode(['status' => 'success', 'msg' => '数据删除成功']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'msg' => '删除失败']);
    }
    exit;
}

// [API] 导入Excel数据
if ($action == 'import_excel') {
    header('Content-Type: application/json');
    
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['status' => 'error', 'msg' => '文件上传失败']);
        exit;
    }
    
    $file = $_FILES['file']['tmp_name'];
    $fileExtension = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
    
    if ($fileExtension !== 'csv') {
        echo json_encode(['status' => 'error', 'msg' => '只支持CSV格式的文件，请将Excel文件另存为CSV格式后导入']);
        exit;
    }
    
    try {
        // 处理CSV格式的文件
        $handle = fopen($file, 'r');
        if (!$handle) {
            echo json_encode(['status' => 'error', 'msg' => '文件打开失败']);
            exit;
        }
        
        $importCount = 0;
        $skipCount = 0;
        
        // 跳过表头
        fgetcsv($handle);
        
        while (($data = fgetcsv($handle)) !== FALSE) {
            if (count($data) >= 3) {
                $companyName = trim($data[0]);
                $agentName = trim($data[1]);
                $agentPhone = trim($data[2]);
                
                if (!empty($companyName) && !empty($agentName) && !empty($agentPhone)) {
                    try {
                        $sql = "INSERT IGNORE INTO agents_data (company_name, agent_name, agent_phone) VALUES (?, ?, ?)";
                        $pdo->prepare($sql)->execute([$companyName, $agentName, $agentPhone]);
                        $importCount++;
                    } catch (Exception $e) {
                        $skipCount++;
                    }
                } else {
                    $skipCount++;
                }
            } else {
                $skipCount++;
            }
        }
        
        fclose($handle);
        
        echo json_encode(['status' => 'success', 'msg' => "导入成功：$importCount 条数据，跳过：$skipCount 条数据"]);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'msg' => '导入失败：' . $e->getMessage()]);
    } catch (Error $e) {
        echo json_encode(['status' => 'error', 'msg' => '导入失败：' . $e->getMessage()]);
    }
    exit;
}

// [API] 导出经纪人数据
if ($action == 'export_agents') {
    $keyword = $_GET['keyword'] ?? '';
    
    $sql = "SELECT company_name, agent_name, agent_phone FROM agents_data WHERE 1=1";
    $params = [];
    
    if (!empty($keyword)) {
        $sql .= " AND (company_name LIKE ? OR agent_name LIKE ? OR agent_phone LIKE ?)";
        $params[] = "%$keyword%";
        $params[] = "%$keyword%";
        $params[] = "%$keyword%";
    }
    
    $sql .= " ORDER BY id DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 生成CSV
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=agents_data_' . date('Ymd') . '.csv');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['经纪公司', '经纪人', '经纪人号码']);
    
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>经纪人数据管理</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; }
        .glass-nav { background: rgba(255,255,255,0.98); border-top: 1px solid #f1f5f9; padding-bottom: env(safe-area-inset-bottom); }
        .card-shadow { box-shadow: 0 4px 20px -2px rgba(0,0,0,0.05); }
        .input-group { width: 100%; background-color: #f9fafb; padding: 0.75rem; border-radius: 0.75rem; border: 1px solid #e5e7eb; font-size: 0.875rem; outline: none; transition: all 0.2s; }
        .input-group:focus { border-color: #3b82f6; ring: 2px solid #93c5fd; }
        .label-text { font-size: 0.75rem; font-weight: bold; color: #6b7280; margin-bottom: 0.25rem; display: block; margin-left: 0.25rem; }
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 50; display: flex; align-items: flex-end; justify-content: center; }
        .modal-content { background: white; width: 100%; max-width: 480px; border-radius: 20px 20px 0 0; padding: 20px; max-height: 80vh; overflow-y: auto; animation: slideUp 0.3s ease-out; position: relative; }
        .close-btn { position: absolute; top: 15px; right: 15px; color: #94a3b8; font-size: 20px; cursor: pointer; padding: 5px; }
        .filter-input { width: 100%; background-color: #f9fafb; border: 1px solid #e5e7eb; border-radius: 0.5rem; padding: 0.5rem; font-size: 0.75rem; outline: none; }
        .filter-label { font-size: 10px; font-weight: bold; color: #9ca3af; margin-bottom: 4px; display: block; }
        
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
        .fade-in { animation: fadeIn 0.5s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        .btn-purple { background: linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%); }
        .btn-green { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
        .btn-blue { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); }
        .btn-red { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); }
        .btn-gray { background: linear-gradient(135deg, #9ca3af 0%, #6b7280 100%); }
        .btn-hover:hover { transform: translateY(-1px); box-shadow: 0 6px 24px -4px rgba(0,0,0,0.15); }
        .table-hover tr:hover { background-color: #f5f3ff !important; }
        .checkbox-custom { accent-color: #8b5cf6; }
        .input-focus:focus { border-color: #8b5cf6; box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.1); }
    </style>
</head>
<body>
<div id="app" class="flex h-screen overflow-hidden">
    
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 flex flex-col overflow-hidden bg-slate-50">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 shadow-sm z-10 flex-shrink-0">
            <div class="flex items-center gap-4">
                <button @click="sidebarOpen = !sidebarOpen" class="md:hidden text-gray-500"><i class="fas fa-bars"></i></button>
                <h2 class="text-lg font-bold text-slate-800">经纪人数据管理</h2>
            </div>
            <div class="flex items-center gap-2"><div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold">A</div><span class="text-sm font-bold">{{ userInfo.name }}</span></div>
        </header>

        <div class="flex-1 overflow-auto p-8">
        <!-- 操作区域 -->
        <div class="bg-white rounded-2xl card-shadow p-6 mb-6 fade-in">
            <h3 class="font-bold text-lg text-slate-800 mb-6">操作区域</h3>
            <div class="space-y-5">
                <!-- 搜索框 -->
                <div class="flex gap-3">
                    <input v-model="searchKeyword" @input="loadData" type="text" placeholder="搜索经纪公司、经纪人或电话号码" class="flex-1 input-group input-focus">
                    <button @click="exportData" class="btn-green text-white py-3 px-6 rounded-xl font-bold shadow-lg text-sm btn-hover flex items-center gap-2">
                        <i class="fas fa-download"></i> 导出
                    </button>
                </div>
                
                <!-- 导入按钮 -->
                <div class="flex gap-3">
                    <input type="file" ref="fileInput" accept=".csv" @change="handleFileUpload" class="hidden">
                    <button @click="$refs.fileInput.click()" class="btn-purple text-white py-3 px-6 rounded-xl font-bold shadow-lg text-sm btn-hover flex items-center gap-2">
                        <i class="fas fa-upload"></i> 导入Excel
                    </button>
                    <div v-if="importStatus" :class="importStatus.status === 'success' ? 'text-green-600' : 'text-red-600'" class="flex-1 flex items-center">
                        {{ importStatus.msg }}
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 数据列表 -->
        <div class="bg-white rounded-2xl card-shadow overflow-hidden mb-6 fade-in">
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left text-gray-600">
                    <thead class="bg-gray-50 text-xs uppercase text-gray-700">
                        <tr>
                            <th class="px-4 py-3">序号</th>
                            <th class="px-4 py-3">
                                <div class="flex items-center gap-1">
                                    <span>经纪公司</span>
                                    <button @click="sortBy('company_name')" class="text-gray-400 hover:text-gray-600">
                                        <i class="fas fa-sort"></i>
                                    </button>
                                </div>
                            </th>
                            <th class="px-4 py-3">
                                <div class="flex items-center gap-1">
                                    <span>经纪人</span>
                                    <button @click="sortBy('agent_name')" class="text-gray-400 hover:text-gray-600">
                                        <i class="fas fa-sort"></i>
                                    </button>
                                </div>
                            </th>
                            <th class="px-4 py-3">经纪人号码</th>
                            <th class="px-4 py-3">
                                <div class="flex items-center gap-1">
                                    <span>当月报备</span>
                                    <button @click="sortBy('monthly_filings')" class="text-gray-400 hover:text-gray-600">
                                        <i class="fas fa-sort"></i>
                                    </button>
                                </div>
                            </th>
                            <th class="px-4 py-3">
                                <div class="flex items-center gap-1">
                                    <span>历史报备</span>
                                    <button @click="sortBy('total_filings')" class="text-gray-400 hover:text-gray-600">
                                        <i class="fas fa-sort"></i>
                                    </button>
                                </div>
                            </th>
                            <th class="px-4 py-3 text-right">操作</th>
                        </tr>
                    </thead>
                    <tbody class="table-hover">
                        <tr v-if="agentsData.length === 0" class="text-center">
                            <td colspan="7" class="py-12 text-gray-400">
                                <div class="flex flex-col items-center justify-center">
                                    <i class="fas fa-user-friends text-4xl text-gray-300 mb-4"></i>
                                    <p class="text-base">暂无数据</p>
                                    <p class="text-sm text-gray-400 mt-2">请先导入经纪人数据</p>
                                </div>
                            </td>
                        </tr>
                        <tr v-for="(item, index) in agentsData" :key="item.id" class="hover:bg-slate-50 border-b border-gray-100">
                            <td class="px-4 py-2 font-medium">{{ (currentPage - 1) * pageSize + index + 1 }}</td>
                            <td class="px-4 py-2 font-bold text-slate-800">{{ item.company_name }}</td>
                            <td class="px-4 py-2 font-medium">{{ item.agent_name }}</td>
                            <td class="px-4 py-2 font-bold text-blue-600">{{ item.agent_phone }}</td>
                            <td class="px-4 py-2 font-bold text-orange-600">{{ item.monthly_filings || 0 }}</td>
                            <td class="px-4 py-2 font-bold text-green-600">{{ item.total_filings || 0 }}</td>
                            <td class="px-4 py-2 text-right">
                                <div class="flex flex-col gap-1 items-end">
                                    <a :href="'tel:' + item.agent_phone" class="bg-green-50 text-green-600 py-1.5 px-3 rounded-lg font-bold shadow-sm text-xs hover:bg-green-100 transition flex items-center gap-1">
                                        <i class="fas fa-phone-alt"></i> 拨打电话
                                    </a>
                                    <button @click="deleteAgent(item.id)" class="bg-red-50 text-red-600 py-1.5 px-3 rounded-lg font-bold shadow-sm text-xs hover:bg-red-100 transition flex items-center gap-1">
                                        <i class="fas fa-trash"></i> 删除
                                    </button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <!-- 分页控件 -->
            <div v-if="total > 0" class="px-4 py-4 bg-gray-50 border-t border-gray-100 flex flex-col sm:flex-row justify-between items-center gap-4">
                <div class="flex items-center gap-4">
                    <span class="text-xs text-gray-500">共 {{ total }} 条记录</span>
                    <div class="flex items-center gap-2">
                        <span class="text-xs text-gray-500">每页显示：</span>
                        <select v-model="pageSize" @change="changePageSize(pageSize)" class="text-xs border border-gray-200 rounded px-2 py-1 bg-white">
                            <option value="10">10条</option>
                            <option value="20">20条</option>
                            <option value="50">50条</option>
                            <option value="100">100条</option>
                        </select>
                    </div>
                </div>
                
                <div class="flex items-center gap-2">
                    <button @click="changePage(currentPage - 1)" :disabled="currentPage === 1" class="text-xs px-3 py-1 border border-gray-200 rounded hover:bg-gray-100 bg-white" :class="{ 'opacity-50 cursor-not-allowed': currentPage === 1 }">
                        上一页
                    </button>
                    
                    <span class="text-xs text-gray-500">第 {{ currentPage }} / {{ totalPages }} 页</span>
                    
                    <button @click="changePage(currentPage + 1)" :disabled="currentPage === totalPages" class="text-xs px-3 py-1 border border-gray-200 rounded hover:bg-gray-100 bg-white" :class="{ 'opacity-50 cursor-not-allowed': currentPage === totalPages }">
                        下一页
                    </button>
                </div>
            </div>
        </div>
        
        <!-- 导入提示弹窗 -->
        <div v-if="showImportModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white rounded-2xl p-6 w-full max-w-md mx-4 card-shadow">
                <div class="w-12 h-2 bg-gray-200 rounded-full mx-auto mb-6"></div>
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-slate-800">导入提示</h3>
                    <button @click="showImportModal = false" class="text-gray-400 hover:text-gray-600 transition">
                        <i class="fas fa-times text-lg"></i>
                    </button>
                </div>
                <div class="space-y-5">
                    <div class="bg-blue-50 p-4 rounded-xl">
                        <h4 class="font-bold text-sm text-blue-700 mb-2">导入说明</h4>
                        <ul class="text-sm text-blue-600 space-y-2">
                            <li>1. 请确保Excel文件包含以下三列：</li>
                            <li>   - 第一列：经纪公司</li>
                            <li>   - 第二列：经纪人</li>
                            <li>   - 第三列：经纪人号码</li>
                            <li>2. 请将Excel文件另存为CSV格式后导入</li>
                            <li>3. 系统会自动跳过重复的数据</li>
                        </ul>
                    </div>
                    <div class="flex gap-4">
                        <button @click="showImportModal = false" class="flex-1 bg-gray-100 text-gray-800 py-3 rounded-xl font-bold shadow-sm text-sm hover:bg-gray-200 transition">
                            取消
                        </button>
                        <button @click="$refs.fileInput.click(); showImportModal = false" class="flex-1 btn-blue text-white py-3 rounded-xl font-bold shadow-lg text-sm btn-hover">
                            选择文件
                        </button>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </main>
</div>

<script>
const { createApp, ref, onMounted } = Vue;
createApp({
    setup() {
        const searchKeyword = ref('');
        const agentsData = ref([]);
        const importStatus = ref(null);
        const showImportModal = ref(false);
        const userInfo = ref({ name: 'Admin' }); // 添加用户信息
        const sidebarOpen = ref(true);
        const view = ref('agent_import');
        const pageTitle = ref('经纪人数据管理');
        const sortByField = ref('id');
        const sortOrder = ref('desc');
        const currentPage = ref(1);
        const pageSize = ref(10);
        const total = ref(0);
        const totalPages = ref(0);
        
        // 加载数据
        const loadData = async () => {
            try {
                const url = new URL(window.location.href);
                url.searchParams.set('action', 'get_agents_list');
                url.searchParams.set('keyword', searchKeyword.value);
                url.searchParams.set('sort_by', sortByField.value);
                url.searchParams.set('sort_order', sortOrder.value);
                url.searchParams.set('page', currentPage.value);
                url.searchParams.set('pageSize', pageSize.value);
                
                const res = await fetch(url.toString());
                
                if (!res.ok) {
                    throw new Error(`HTTP error! status: ${res.status}`);
                }
                
                const response = await res.json();
                agentsData.value = response.data || [];
                total.value = response.total || 0;
                totalPages.value = Math.ceil(total.value / pageSize.value);
            } catch (error) {
                console.error('加载数据失败:', error);
                agentsData.value = [];
                total.value = 0;
                totalPages.value = 0;
            }
        };
        
        // 排序方法
        const sortBy = (field) => {
            if (sortByField.value === field) {
                // 如果点击的是当前排序字段，则切换排序顺序
                sortOrder.value = sortOrder.value === 'asc' ? 'desc' : 'asc';
            } else {
                // 否则，设置新的排序字段和默认排序顺序
                sortByField.value = field;
                sortOrder.value = 'desc';
            }
            // 重新加载数据
            loadData();
        };
        
        // 处理文件上传
        const handleFileUpload = async (event) => {
            const file = event.target.files[0];
            if (!file) return;
            
            const formData = new FormData();
            formData.append('file', file);
            
            importStatus.value = { status: 'loading', msg: '导入中，请稍候...' };
            
            try {
                const res = await fetch('?action=import_excel', {
                    method: 'POST',
                    body: formData
                });
                
                if (!res.ok) {
                    throw new Error(`HTTP error! status: ${res.status}`);
                }
                
                const data = await res.json();
                importStatus.value = data;
                loadData();
                
                // 清空文件输入
                event.target.value = '';
            } catch (error) {
                importStatus.value = { status: 'error', msg: '导入失败：' + error.message };
            }
        };
        
        // 删除数据
        const deleteAgent = async (id) => {
            if (!confirm('确定要删除这条数据吗？')) {
                return;
            }
            
            try {
                const res = await fetch('?action=delete_agent', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: `id=${id}`
                });
                
                if (!res.ok) {
                    throw new Error(`HTTP error! status: ${res.status}`);
                }
                
                const data = await res.json();
                alert(data.msg);
                loadData();
            } catch (error) {
                alert('删除失败');
            }
        };
        
        // 导出数据
        const exportData = () => {
            const url = new URL(window.location.href);
            url.searchParams.set('action', 'export_agents');
            url.searchParams.set('keyword', searchKeyword.value);
            
            window.location.href = url.toString();
        };
        
        // 分页相关函数
        const changePage = (page) => {
            if (page < 1 || page > totalPages.value) return;
            currentPage.value = page;
            loadData();
        };
        
        const changePageSize = (size) => {
            pageSize.value = size;
            currentPage.value = 1;
            loadData();
        };
        
        // 初始化
        onMounted(() => {
            loadData();
        });
        
        return {
            searchKeyword,
            agentsData,
            importStatus,
            showImportModal,
            loadData,
            handleFileUpload,
            deleteAgent,
            exportData,
            userInfo,
            sidebarOpen,
            view,
            pageTitle,
            sortBy,
            currentPage,
            pageSize,
            total,
            totalPages,
            changePage,
            changePageSize
        };
    }
}).mount('#app');
</script>
</body>
</html>