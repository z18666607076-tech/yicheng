<?php
// agent_login_api.php - 登录验证与角色分流
session_start();
header('Content-Type: application/json');

// 1. 数据库连接
$host = '127.0.0.1'; $db = 'ychf'; $user = 'ychf'; $pass = 'rjX5DESSbGXbewfa'; $charset = 'utf8mb4';
try { 
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass); 
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { 
    die(json_encode(['status'=>'error','msg'=>'数据库连接失败'])); 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = $_POST['phone'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!$phone || !$password) {
        echo json_encode(['status'=>'error', 'msg'=>'请输入手机号和密码']);
        exit;
    }

    // 2. 查询用户 (检查手机号和未删除状态)
    $stmt = $pdo->prepare("SELECT * FROM agents WHERE phone = ? AND is_deleted = 0");
    $stmt->execute([$phone]);
    $agent = $stmt->fetch(PDO::FETCH_ASSOC);

    // 3. 验证密码 (此处演示为明文对比，建议生产环境使用 password_verify)
    if ($agent && $agent['password'] === $password) {
        
        // --- 登录成功，写入 Session ---
        $_SESSION['agent_id'] = $agent['id'];
        $_SESSION['agent_name'] = $agent['username'];
        $_SESSION['agent_phone'] = $agent['phone'];
        $_SESSION['agent_role'] = $agent['role']; // 重要：存入角色
        
        // 获取部门/公司名称 (用于前端显示)
        $deptName = '未知部门';
        if ($agent['department_id']) {
            $d = $pdo->query("SELECT name FROM departments WHERE id=".$agent['department_id'])->fetchColumn();
            if($d) $deptName = $d;
        }
        $_SESSION['agent_company'] = $deptName;

        // --- 4. 核心：根据角色决定跳转地址 ---
        $redirectUrl = 'agent.php'; // 默认去经纪人端
        
        switch ($agent['role']) {
            case 'staff':   // 案场人员
                $redirectUrl = 'staff.php';
                break;
            case 'channel': // 渠道经纪人
                $redirectUrl = 'agent.php';
                break;
            case 'admin':   // 管理员 (如果有)
            case 'finance': // 财务 (如果有)
                $redirectUrl = 'admin.php'; // 假设后台入口是 admin.php
                break;
        }

        // 返回成功状态和跳转地址
        echo json_encode(['status'=>'success', 'redirect' => $redirectUrl]);
        
    } else {
        echo json_encode(['status'=>'error', 'msg'=>'账号或密码错误']);
    }
}
?>