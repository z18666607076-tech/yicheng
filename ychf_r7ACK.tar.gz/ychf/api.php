<?php
// api.php - 统一后端接口 (v3.0: 全功能完整版)
header('Content-Type: application/json; charset=utf-8');
session_start();

// === 1. 数据库配置 ===
$host = '127.0.0.1'; $db = 'ychf'; $user = 'ychf'; $pass = 'rjX5DESSbGXbewfa'; $charset = 'utf8mb4';
try { 
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass); 
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) { die(json_encode(['status'=>'error','msg'=>'DB Error: '.$e->getMessage()])); }

$action = $_GET['action'] ?? '';

// ======================= 1. 仪表盘 (Dashboard) =======================
if ($action == 'get_dashboard_stats') {
    $total_filing = $pdo->query("SELECT count(*) FROM filings")->fetchColumn();
    $total_deal   = $pdo->query("SELECT count(*) FROM filings WHERE status = 4")->fetchColumn();
    $total_gmv    = $pdo->query("SELECT SUM(deal_price) FROM filings WHERE status = 4")->fetchColumn() ?: 0;
    $total_comm   = $pdo->query("SELECT SUM(commission_amount) FROM filings WHERE status = 4")->fetchColumn() ?: 0;
    
    // 模拟趋势数据
    $months = ['8月', '9月', '10月', '11月', '12月', '1月'];
    $comm_trend = ['pending' => [12, 13, 10, 13, 9, 23], 'paid' => [8, 9, 11, 12, 14, 8]]; 
    $funnel = [
        ['name'=>'报备', 'value'=>$total_filing ?: 100], ['name'=>'有效', 'value'=>$pdo->query("SELECT count(*) FROM filings WHERE status >= 1")->fetchColumn() ?: 80],
        ['name'=>'到访', 'value'=>$pdo->query("SELECT count(*) FROM filings WHERE status >= 2")->fetchColumn() ?: 40], ['name'=>'认筹', 'value'=>$pdo->query("SELECT count(*) FROM filings WHERE status >= 3")->fetchColumn() ?: 20],
        ['name'=>'成交', 'value'=>$total_deal ?: 10]
    ];
    $recent = $pdo->query("SELECT f.client_name, p.name as project, f.deal_price, f.created_at FROM filings f LEFT JOIN projects p ON f.project_id=p.id WHERE f.status=4 ORDER BY f.id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['cards'=>['filing'=>$total_filing, 'deal'=>$total_deal, 'gmv'=>$total_gmv, 'comm'=>$total_comm], 'chart_comm'=>['months'=>$months, 'data'=>$comm_trend], 'funnel'=>$funnel, 'recent'=>$recent]); exit;
}

// ======================= 2. 商户管理 (Companies) =======================

// [查询] 支持分页与多条件筛选
if ($action == 'get_companies') {
    $kw = $_GET['kw'] ?? '';           
    $plate = $_GET['plate'] ?? '';     
    $area = $_GET['area'] ?? '';       
    $follower = $_GET['follower'] ?? ''; 
    
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
    $offset = ($page - 1) * $limit;

    $where = "WHERE 1=1";
    $params = [];

    if ($kw) {
        $where .= " AND (name LIKE ? OR store_name LIKE ? OR contact_name LIKE ? OR contact_phone LIKE ?)";
        $params[] = "%$kw%"; $params[] = "%$kw%"; $params[] = "%$kw%"; $params[] = "%$kw%";
    }
    if ($plate) { $where .= " AND region_main LIKE ?"; $params[] = "%$plate%"; }
    if ($area) { $where .= " AND region_sub LIKE ?"; $params[] = "%$area%"; }
    if ($follower) { $where .= " AND follower LIKE ?"; $params[] = "%$follower%"; }

    $countStmt = $pdo->prepare("SELECT count(*) FROM companies $where");
    $countStmt->execute($params);
    $total = $countStmt->fetchColumn();

    $stmt = $pdo->prepare("SELECT * FROM companies $where ORDER BY id DESC LIMIT $limit OFFSET $offset");
    $stmt->execute($params);
    
    echo json_encode(['code' => 0, 'count' => $total, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]); exit;
}

// [详情] 获取单个商户
if ($action == 'get_company_detail') {
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    echo json_encode($stmt->fetch(PDO::FETCH_ASSOC)); exit;
}

// [保存] 新增或编辑 (补全)
if ($action == 'save_company') {
    $d = $_POST;
    if(!empty($d['id'])) {
        $sql = "UPDATE companies SET name=?, region_main=?, region_sub=?, store_name=?, store_type=?, business_status=?, related_store=?, franchise_brand=?, address=?, contact_name=?, contact_phone=?, follower=? WHERE id=?";
        $pdo->prepare($sql)->execute([$d['name'], $d['region_main'], $d['region_sub'], $d['store_name'], $d['store_type'], $d['business_status'], $d['related_store'], $d['franchise_brand'], $d['address'], $d['contact_name'], $d['contact_phone'], $d['follower'], $d['id']]);
    } else {
        $sql = "INSERT INTO companies (name, region_main, region_sub, store_name, store_type, business_status, related_store, franchise_brand, address, contact_name, contact_phone, follower) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        $pdo->prepare($sql)->execute([$d['name'], $d['region_main'], $d['region_sub'], $d['store_name'], $d['store_type'], $d['business_status'], $d['related_store'], $d['franchise_brand'], $d['address'], $d['contact_name'], $d['contact_phone'], $d['follower']]);
    }
    echo json_encode(['status'=>'success']); exit;
}

// [删除] (补全)
if ($action == 'delete_company') {
    $pdo->prepare("DELETE FROM companies WHERE id=?")->execute([$_POST['id']]);
    echo json_encode(['status'=>'success']); exit;
}

// [批量修改跟进人]
if ($action == 'batch_update_company_follower') {
    $ids = $_POST['ids'] ?? '';
    $follower = $_POST['follower'] ?? '';
    
    if (empty($ids) || empty($follower)) {
        echo json_encode(['status'=>'error', 'msg'=>'参数不足']); exit;
    }
    
    $idArray = explode(',', $ids);
    $idArray = array_filter($idArray, function($id) { return is_numeric($id) && $id > 0; });
    
    if (empty($idArray)) {
        echo json_encode(['status'=>'error', 'msg'=>'无效的商户ID']); exit;
    }
    
    try {
        $placeholders = str_repeat('?,', count($idArray) - 1) . '?';
        $sql = "UPDATE companies SET follower=? WHERE id IN ($placeholders)";
        $params = array_merge([$follower], $idArray);
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            echo json_encode(['status'=>'success', 'msg'=>'批量修改成功']);
        } else {
            echo json_encode(['status'=>'error', 'msg'=>'修改失败']);
        }
    } catch (Exception $e) {
        echo json_encode(['status'=>'error', 'msg'=>$e->getMessage()]);
    }
    exit;
}

// ======================= 3. 项目管理 (Projects) =======================
if ($action == 'get_projects') { echo json_encode($pdo->query("SELECT * FROM projects WHERE is_deleted=0 AND status=1 ORDER BY is_agent DESC, id DESC")->fetchAll(PDO::FETCH_ASSOC)); exit; }
if ($action == 'get_project_detail') { $stmt=$pdo->prepare("SELECT * FROM projects WHERE id=?"); $stmt->execute([$_GET['id']]); echo json_encode($stmt->fetch(PDO::FETCH_ASSOC)); exit; }
if ($action == 'save_project') {
    $d = $_POST;
    
    // 验证项目名称
    if(empty($d['name']) || strlen(trim($d['name'])) < 2) {
        echo json_encode(['status'=>'error', 'msg'=>'项目名称至少需要2个字符']); exit;
    }
    
    // 过滤项目名称，移除异常字符
    $d['name'] = trim($d['name']);
    
    if(!empty($d['id'])) {
        $sql = "UPDATE projects SET name=?, price=?, commission_rate=?, tax_rate=?, protect_days=?, detail=?, image=?, manager_name=?, manager_phone=?, is_agent=?, status=? WHERE id=?";
        $pdo->prepare($sql)->execute([$d['name'], $d['price'], $d['commission_rate'], $d['tax_rate'], $d['protect_days'], $d['detail'], $d['image'], $d['manager_name'], $d['manager_phone'], $d['is_agent'], $d['status'], $d['id']]);
    } else {
        $sql = "INSERT INTO projects (name, price, commission_rate, tax_rate, protect_days, detail, image, manager_name, manager_phone, is_agent, status) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        $pdo->prepare($sql)->execute([$d['name'], $d['price'], $d['commission_rate'], $d['tax_rate'], $d['protect_days'], $d['detail'], $d['image'], $d['manager_name'], $d['manager_phone'], $d['is_agent'], $d['status']]);
    }
    echo json_encode(['status'=>'success']); exit;
}
if ($action == 'delete_project') { $pdo->prepare("UPDATE projects SET is_deleted=1 WHERE id=?")->execute([$_POST['id']]); echo json_encode(['status'=>'success']); exit; }

// ======================= 4. 报备管理 (Filings) =======================

// [查询] 支持分页与筛选 (补全)
if ($action == 'get_filings') {
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
    $kw = $_GET['kw'] ?? '';
    $status = $_GET['status'] ?? '';
    $offset = ($page - 1) * $limit;

    $where = "WHERE 1=1";
    $params = [];

    if ($kw) {
        $where .= " AND (f.client_name LIKE ? OR f.client_phone LIKE ? OR f.broker_name LIKE ?)";
        $params[] = "%$kw%"; $params[] = "%$kw%"; $params[] = "%$kw%";
    }
    if ($status !== '') {
        $where .= " AND f.status = ?";
        $params[] = $status;
    }

    $countStmt = $pdo->prepare("SELECT count(*) FROM filings f $where");
    $countStmt->execute($params);
    $total = $countStmt->fetchColumn();

    $sql = "SELECT f.*, p.name as project_name, 
            COALESCE(NULLIF(f.broker_name,''), a.username) as display_broker_name,
            COALESCE(NULLIF(f.broker_phone,''), a.phone) as display_broker_phone
            FROM filings f 
            LEFT JOIN projects p ON f.project_id = p.id 
            LEFT JOIN agents a ON f.agent_id = a.id
            $where 
            ORDER BY f.id DESC LIMIT $limit OFFSET $offset";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    echo json_encode(['code'=>0, 'count'=>$total, 'data'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]); exit;
}

// [审核] 更改状态 (补全)
if ($action == 'audit_status') {
    $id = $_POST['id'];
    $status = $_POST['status'];
    $reason = $_POST['reason'] ?? '';
    $log = "\n" . date('Y-m-d H:i') . " [管理员] " . ($status == 1 ? '审核通过' : '审核驳回') . ($reason ? " ($reason)" : "");
    $pdo->prepare("UPDATE filings SET status=?, status_log=CONCAT(IFNULL(status_log,''), ?) WHERE id=?")->execute([$status, $log, $id]);
    echo json_encode(['status'=>'success']); exit;
}

// ======================= 5. 财务佣金 (Finance) =======================
if ($action == 'get_finance_data') {
    $stats = ['gmv'=>$pdo->query("SELECT SUM(deal_price) FROM filings WHERE status=4")->fetchColumn()?:0, 'pending'=>$pdo->query("SELECT SUM(commission_amount) FROM filings WHERE status=4 AND commission_status=0")->fetchColumn()?:0, 'confirmed'=>$pdo->query("SELECT SUM(commission_amount) FROM filings WHERE status=4 AND commission_status=1")->fetchColumn()?:0, 'paid'=>$pdo->query("SELECT SUM(commission_amount) FROM filings WHERE status=4 AND commission_status=2")->fetchColumn()?:0];
    $deals = $pdo->query("SELECT f.*, p.name as project_name FROM filings f LEFT JOIN projects p ON f.project_id = p.id WHERE f.status = 4 ORDER BY f.commission_status ASC, f.id DESC")->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['stats'=>$stats, 'deals'=>$deals]); exit;
}
if ($action == 'update_commission') { 
    $pdo->prepare("UPDATE filings SET commission_status=?, commission_amount=?, commission_proof=? WHERE id=?")->execute([$_POST['status'], $_POST['amount'], $_POST['proof'], $_POST['id']]); echo json_encode(['status'=>'success']); exit; 
}

// ======================= 6. 人员与架构 (Agents) =======================

// 辅助函数：构建树
function buildTree(array $elements, $parentId = 0) {
    $branch = array();
    foreach ($elements as $element) {
        if ($element['parent_id'] == $parentId) {
            $children = buildTree($elements, $element['id']);
            if ($children) $element['children'] = $children;
            $branch[] = $element;
        }
    }
    return $branch;
}

// [API] 获取完整架构树 (性能优化版)
if ($action == 'get_structure') {
    try {
        // 1. 获取部门
        $depts = $pdo->query("SELECT * FROM departments ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
        $deptTree = buildTree($depts);
        
        // 2. 获取人员
        $sql = "SELECT a.*, d.name as dept_name, m.username as manager_name FROM agents a LEFT JOIN departments d ON a.department_id = d.id LEFT JOIN agents m ON a.manager_id = m.id WHERE a.is_deleted=0 ORDER BY a.id DESC";
        $agents = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

        // 3. 批量查关联项目
        $p_sql = "SELECT ap.agent_id, p.name FROM agent_projects ap JOIN projects p ON ap.project_id = p.id";
        $all_projects = $pdo->query($p_sql)->fetchAll(PDO::FETCH_GROUP | PDO::FETCH_ASSOC); 

        // 4. 批量查关联商户数（从companies表的follower字段反推）
        $c_sql = "SELECT follower, count(*) as cnt FROM companies WHERE follower IS NOT NULL AND follower != '' GROUP BY follower";
        $all_counts = $pdo->query($c_sql)->fetchAll(PDO::FETCH_KEY_PAIR);

        // 5. 组装
        foreach ($agents as &$agent) {
            $aid = $agent['id'];
            $agent['projects'] = isset($all_projects[$aid]) ? $all_projects[$aid] : [];
            // 根据人员姓名匹配跟进商户数量
            $agent['company_count'] = isset($all_counts[$agent['username']]) ? $all_counts[$agent['username']] : 0;
        }

        echo json_encode(['departments' => $deptTree, 'agents' => $agents]); exit;
    } catch (Exception $e) {
        echo json_encode(['departments' => [], 'agents' => []]); exit;
    }
}

// [API] 获取单人详情 (编辑专用)
if ($action == 'get_agent_detail') {
    try {
        $id = $_GET['id'];
        $agent = $pdo->query("SELECT * FROM agents WHERE id = $id")->fetch(PDO::FETCH_ASSOC);
        if (!$agent) {
            echo json_encode([]); exit;
        }
        // 关联项目ID
        $agent['project_ids'] = $pdo->query("SELECT project_id FROM agent_projects WHERE agent_id = $id")->fetchAll(PDO::FETCH_COLUMN);
        // 关联商户详情
        $agent['selected_companies'] = $pdo->query("SELECT c.id, c.name FROM agent_companies ac LEFT JOIN companies c ON ac.company_id = c.id WHERE ac.agent_id = $id")->fetchAll(PDO::FETCH_ASSOC);
        // 确保 selected_companies 是数组
        if (!is_array($agent['selected_companies'])) {
            $agent['selected_companies'] = [];
        }
        echo json_encode($agent); exit;
    } catch (Exception $e) {
        echo json_encode([]); exit;
    }
}

// [API] 保存人员 (含关联项目+商户)
if ($action == 'save_agent_full') {
    $d = $_POST;
    try {
        $pdo->beginTransaction();
        if (!empty($d['id'])) {
            $sql = "UPDATE agents SET username=?, phone=?, department_id=?, role=?, password=?, manager_id=? WHERE id=?";
            $pdo->prepare($sql)->execute([$d['username'], $d['phone'], $d['department_id'], $d['role'], $d['password'], $d['manager_id'] ?? 0, $d['id']]);
            $agent_id = $d['id'];
        } else {
            $sql = "INSERT INTO agents (username, phone, department_id, role, password, manager_id) VALUES (?,?,?,?,?,?)";
            $pdo->prepare($sql)->execute([$d['username'], $d['phone'], $d['department_id'], $d['role'], $d['password'], $d['manager_id'] ?? 0]);
            $agent_id = $pdo->lastInsertId();
        }

        // 保存负责项目
        $pdo->prepare("DELETE FROM agent_projects WHERE agent_id = ?")->execute([$agent_id]);
        if (!empty($d['project_ids'])) {
            $pids = explode(',', $d['project_ids']);
            $ins = $pdo->prepare("INSERT INTO agent_projects (agent_id, project_id) VALUES (?, ?)");
            foreach ($pids as $pid) { if($pid) $ins->execute([$agent_id, $pid]); }
        }

        // 保存负责商户
        $pdo->prepare("DELETE FROM agent_companies WHERE agent_id = ?")->execute([$agent_id]);
        if (!empty($d['company_ids'])) {
            $cids = explode(',', $d['company_ids']);
            $ins = $pdo->prepare("INSERT INTO agent_companies (agent_id, company_id) VALUES (?, ?)");
            foreach ($cids as $cid) { if($cid) $ins->execute([$agent_id, $cid]); }
        }

        $pdo->commit();
        echo json_encode(['status'=>'success']);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['status'=>'error', 'msg'=>$e->getMessage()]);
    }
    exit;
}

// [API] 部门与简单人员操作
if ($action == 'save_department') {
    $d = $_POST;
    if(!empty($d['id'])) $pdo->prepare("UPDATE departments SET name=?, parent_id=? WHERE id=?")->execute([$d['name'], $d['parent_id'], $d['id']]);
    else $pdo->prepare("INSERT INTO departments (name, parent_id) VALUES (?, ?)")->execute([$d['name'], $d['parent_id']]);
    echo json_encode(['status'=>'success']); exit;
}
if ($action == 'delete_department') {
    $id = $_POST['id'];
    $hasChild = $pdo->query("SELECT count(*) FROM departments WHERE parent_id=$id")->fetchColumn();
    $hasAgent = $pdo->query("SELECT count(*) FROM agents WHERE department_id=$id AND is_deleted=0")->fetchColumn();
    if ($hasChild > 0 || $hasAgent > 0) echo json_encode(['status'=>'error', 'msg'=>'该部门下有子部门或人员，无法删除']);
    else { $pdo->prepare("DELETE FROM departments WHERE id=?")->execute([$id]); echo json_encode(['status'=>'success']); }
    exit;
}
if ($action == 'delete_agent') { 
    $pdo->prepare("UPDATE agents SET is_deleted=1 WHERE id=?")->execute([$_POST['id']]); echo json_encode(['status'=>'success']); exit; 
}
?>