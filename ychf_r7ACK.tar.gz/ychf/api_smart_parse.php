<?php
// api_smart_parse.php - 调用 DeepSeek 进行智能识别
header('Content-Type: application/json; charset=utf-8');

// === 配置区 ===
$apiKey = 'sk-6e18559e352b48eca4e1c5b340938c15'; // ★★★ 请在这里填入您的 sk-xxxx ★★★
$apiUrl = 'https://api.deepseek.com/chat/completions'; // DeepSeek 官方接口地址

// 1. 获取前端输入
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, true);
$text = $input['text'] ?? '';

if (empty($text)) {
    echo json_encode(['status' => 'error', 'msg' => '请粘贴文本内容']);
    exit;
}

// 2. 构建 Prompt (提示词)
// 告诉 AI 今天几号，以便它识别 "明天"、"后天"
$today = date('Y-m-d');
$prompt = <<<EOT
你是一个房地产报备信息提取助手。今天是 {$today}。
请从以下文本中提取关键信息，并严格按照 JSON 格式返回。
如果某个字段在文本中没有提及，请返回 null 或 空字符串，不要杜撰。

需要提取的字段及说明：
- company_name: 报备公司/门店名称
- broker_name: 业务员/经纪人姓名
- broker_phone: 业务员电话
- broker_num: 业务员人数 (整数，默认1)
- client_name: 客户姓名
- client_phone: 客户电话 (必须提取手机号)
- client_num: 客户人数 (整数，默认1)
- project_keywords: 报备的楼盘/项目名称 (数组，因为可能报备多个)
- visit_date: 带看日期 (格式 YYYY-MM-DD，如果说是"明天"请基于今天计算)
- designated_sales: 指定销售/对接人
- remark: 其他备注信息

待提取文本：
{$text}

返回格式要求：
仅返回纯 JSON 字符串，不要包含 Markdown 格式（如 ```json），不要包含其他解释。
EOT;

// 3. 调用 API
$data = [
    'model' => 'deepseek-chat', // 使用 V3 模型，性价比极高
    'messages' => [
        ['role' => 'system', 'content' => 'You are a helpful JSON extractor.'],
        ['role' => 'user', 'content' => $prompt]
    ],
    'temperature' => 0.1, // 低温度，保证输出稳定
    'response_format' => ['type' => 'json_object'] // 强制 JSON 模式
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey
]);
// 如果您的服务器在国内且无法直连，可能需要禁用 SSL 验证或配置代理
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

// 4. 处理结果
if ($error || $httpCode !== 200) {
    // 记录日志以便调试
    file_put_contents('deepseek_error.log', date('Y-m-d H:i:s')." Error: $error | Code: $httpCode | Resp: $response\n", FILE_APPEND);
    echo json_encode(['status' => 'error', 'msg' => '智能识别服务暂时不可用']);
    exit;
}

$resultArr = json_decode($response, true);
$content = $resultArr['choices'][0]['message']['content'] ?? '';

// 清洗 Markdown 代码块标记 (以防万一 AI 还是输出了 ```json)
$content = preg_replace('/^```json\s*/i', '', $content);
$content = preg_replace('/\s*```$/', '', $content);

$parsedData = json_decode($content, true);

if (!$parsedData) {
    echo json_encode(['status' => 'error', 'msg' => '无法解析识别结果']);
    exit;
}

echo json_encode(['status' => 'success', 'data' => $parsedData]);
?>