<?php
// followup_records.php - 跟进记录管理页面
session_start();
header('Content-Type: text/html; charset=utf-8');

// === 0. 登录鉴权 ===
// 取消登录验证
// if (!isset($_SESSION['agent_id'])) { header('Location: login.php'); exit; }
$CURRENT_USER = [
    'id' => $_SESSION['agent_id'] ?? 0,
    'name' => $_SESSION['agent_name'] ?? '管理员',
    'phone' => $_SESSION['agent_phone'] ?? '',
    'company' => $_SESSION['agent_company'] ?? '',
    'role' => $_SESSION['agent_role'] ?? 'channel'
];

// 检查是否为渠道部门用户
$isChannelUser = false;
$channelDeptNames = ['渠道经理', '渠道人员'];
foreach ($channelDeptNames as $deptName) {
    if (strpos($CURRENT_USER['company'], $deptName) !== false) {
        $isChannelUser = true;
        break;
    }
}

// === 1. 数据库连接 ===
$host = '127.0.0.1'; $db = 'ychf'; $user = 'ychf'; $pass = 'rjX5DESSbGXbewfa'; $charset = 'utf8mb4';
try { $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass); } catch (PDOException $e) { die("DB Error: " . $e->getMessage()); }

$action = $_GET['action'] ?? 'view';

// [API] 导出Excel
if ($action == 'export_excel') {
    // 使用简单的CSV导出替代Excel导出，避免依赖PhpSpreadsheet库
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment;filename="跟进记录_' . date('YmdHis') . '.csv"');
    header('Cache-Control: max-age=0');
    
    // 打开输出流
    $output = fopen('php://output', 'w');
    
    // 写入BOM，解决中文乱码问题
    fwrite($output, chr(0xEF) . chr(0xBB) . chr(0xBF));
    
    // 写入表头
    fputcsv($output, ['客户姓名', '客户电话', '项目名称', '公司名称', '经纪人', '经纪人电话', '第一次跟进', '第二次跟进', '第三次跟进']);
    
    // 查询所有有跟进记录的报备
    $sql = "SELECT f.*, p.name as project_name, 
            COALESCE(NULLIF(f.broker_name,''), a.username) as agent_name, 
            COALESCE(NULLIF(f.broker_phone,''), a.phone) as agent_phone,
            c.name as company_full_name, c.store_name
            FROM filings f 
            LEFT JOIN projects p ON f.project_id = p.id 
            LEFT JOIN agents a ON f.agent_id = a.id
            LEFT JOIN companies c ON f.company_name = c.name 
            WHERE EXISTS (SELECT 1 FROM filing_followups WHERE filing_id = f.id)
            ORDER BY f.created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $filings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 填充数据
    foreach ($filings as $filing) {
        // 获取跟进记录
        $followupStmt = $pdo->prepare("SELECT * FROM filing_followups WHERE filing_id = ? ORDER BY followup_count ASC");
        $followupStmt->execute([$filing['id']]);
        $followups = $followupStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 整理跟进记录
        $followup1 = '';
        $followup2 = '';
        $followup3 = '';
        
        foreach ($followups as $followup) {
            $followup_text = "({$followup['created_at']}) ";
            if (!empty($followup['summary'])) {
                $followup_text .= "[{$followup['summary']}] ";
            }
            $followup_text .= $followup['content'];
            switch ($followup['followup_count']) {
                case 1:
                    $followup1 = $followup_text;
                    break;
                case 2:
                    $followup2 = $followup_text;
                    break;
                case 3:
                    $followup3 = $followup_text;
                    break;
            }
        }
        
        // 填充数据
        fputcsv($output, [
            $filing['client_name'],
            $filing['client_phone'],
            $filing['project_name'],
            $filing['company_name'] ?? $filing['company_full_name'] ?? '',
            $filing['broker_name'] ?? $filing['agent_name'] ?? '',
            $filing['broker_phone'] ?? $filing['agent_phone'] ?? '',
            $followup1,
            $followup2,
            $followup3
        ]);
    }
    
    // 关闭输出流
    fclose($output);
    exit;
}

// [API] 获取跟进记录列表
if ($action == 'get_followup_list') {
    header('Content-Type: application/json');
    
    // 查询所有有跟进记录的报备
    $sql = "SELECT f.*, p.name as project_name, 
            COALESCE(NULLIF(f.broker_name,''), a.username) as agent_name, 
            COALESCE(NULLIF(f.broker_phone,''), a.phone) as agent_phone,
            c.name as company_full_name, c.store_name
            FROM filings f 
            LEFT JOIN projects p ON f.project_id = p.id 
            LEFT JOIN agents a ON f.agent_id = a.id
            LEFT JOIN companies c ON f.company_name = c.name 
            WHERE EXISTS (SELECT 1 FROM filing_followups WHERE filing_id = f.id)
            ORDER BY f.created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $filings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 为每个报备添加跟进记录
    foreach ($filings as &$filing) {
        $followupStmt = $pdo->prepare("SELECT * FROM filing_followups WHERE filing_id = ? ORDER BY followup_count ASC");
        $followupStmt->execute([$filing['id']]);
        $filing['followups'] = $followupStmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    echo json_encode($filings);
    exit;
}

$view = $_GET['v'] ?? 'followup_records';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>跟进记录管理</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Vue 3 -->
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;500;700&display=swap');
        body { font-family: 'Noto Sans SC', sans-serif; }
        .card-shadow { box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        .nav-item:hover { background-color: rgba(59, 130, 246, 0.1); }
        .nav-item.active { background-color: #2563eb; color: white; }
        .nav-item.active i { color: white; }
        .bg-gray-50 { background-color: #f9fafb; }
        .border-gray-200 { border-color: #e5e7eb; }
        .text-gray-600 { color: #4b5563; }
        .text-gray-500 { color: #6b7280; }
        .text-gray-400 { color: #9ca3af; }
        .text-blue-600 { color: #2563eb; }
        .bg-blue-50 { background-color: #eff6ff; }
        .border-blue-200 { border-color: #bfdbfe; }
        .bg-green-50 { background-color: #ecfdf5; }
        .text-green-600 { color: #10b981; }
        .bg-orange-50 { background-color: #fff7ed; }
        .text-orange-600 { color: #f97316; }
        .bg-red-50 { background-color: #fef2f2; }
        .text-red-500 { color: #ef4444; }
        .bg-gray-100 { background-color: #f3f4f6; }
        .modal-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; }
        .modal-content { background: white; border-radius: 16px; width: 90%; max-width: 500px; max-height: 80vh; overflow-y: auto; position: relative; padding: 24px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04); }
        .close-btn { position: absolute; top: 16px; right: 20px; font-size: 24px; cursor: pointer; color: #9ca3af; }
        .close-btn:hover { color: #4b5563; }
    </style>
</head>
<body>
<div id="app" class="flex h-screen overflow-hidden">
    
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 flex flex-col overflow-hidden bg-slate-50">
        <header class="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 shadow-sm z-10 flex-shrink-0">
            <div class="flex items-center gap-4">
                <button @click="sidebarOpen = !sidebarOpen" class="md:hidden text-gray-500"><i class="fas fa-bars"></i></button>
                <h2 class="text-lg font-bold text-slate-800">{{ pageTitle }}</h2>
            </div>
            <div class="flex items-center gap-4">
                <button @click="exportExcel" class="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2">
                    <i class="fas fa-file-excel"></i> 导出Excel
                </button>
                <div class="flex items-center gap-2"><div class="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold">A</div><span class="text-sm font-bold">{{ userInfo.name }}</span></div>
            </div>
        </header>

        <div class="flex-1 overflow-auto p-8">
                <!-- 搜索和筛选 -->
                <div class="bg-white rounded-2xl p-4 shadow-sm mb-4">
                    <div class="flex flex-wrap gap-4">
                        <div class="flex-1 min-w-[200px]">
                            <input v-model="search.keyword" type="text" placeholder="搜索客户姓名、电话、项目..." class="w-full px-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                        <div class="flex gap-2">
                            <button @click="resetSearch" class="bg-gray-100 text-gray-500 px-4 py-2 rounded-lg text-sm font-bold">重置</button>
                            <button @click="searchRecords" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold">搜索</button>
                        </div>
                    </div>
                </div>

                <!-- 数据列表 -->
                <div v-if="records.length === 0" class="text-center text-gray-400 text-sm py-10">暂无跟进记录</div>
                <div v-else class="space-y-4">
                    <div v-for="(record, index) in filteredRecords" :key="record.id" class="bg-white rounded-2xl p-4 shadow-sm">
                        <div class="flex justify-between items-start mb-4 pb-3 border-b border-gray-100">
                            <div>
                                <h3 class="font-bold text-lg text-gray-800">{{ record.client_name }} <span class="text-sm font-normal text-gray-500">{{ record.client_phone }}</span></h3>
                                <div class="text-sm text-gray-600 mt-1">
                                    <span class="mr-4"><i class="fas fa-building mr-1"></i> {{ record.company_name || record.company_full_name || '-' }}</span>
                                    <span><i class="fas fa-user-tie mr-1"></i> {{ record.broker_name || record.agent_name || '-' }} {{ record.broker_phone || record.agent_phone ? '(' + record.broker_phone || record.agent_phone + ')' : '' }}</span>
                                </div>
                                <div class="text-sm text-gray-600 mt-1">
                                    <span><i class="fas fa-home mr-1"></i> {{ record.project_name }}</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- 跟进记录 -->
                        <div class="grid grid-cols-3 gap-3 mt-2">
                            <!-- 第1次跟进 -->
            <div class="rounded-lg p-3 border bg-blue-50 border-blue-200">
                <div class="font-bold text-sm text-blue-600">第1次跟进</div>
                <div class="text-sm text-gray-700 mt-1">
                    <template v-if="record.followups && record.followups.find(f => f.followup_count == 1)">
                        <span v-if="record.followups.find(f => f.followup_count == 1).summary" class="bg-blue-100 text-blue-600 px-1 rounded mr-1">
                            {{ record.followups.find(f => f.followup_count == 1).summary }}
                        </span>
                        {{ record.followups.find(f => f.followup_count == 1).content }}
                    </template>
                    <template v-else>无</template>
                </div>
                <div v-if="record.followups && record.followups.find(f => f.followup_count == 1)" class="text-xs text-gray-500 mt-1">
                    {{ record.followups.find(f => f.followup_count == 1).created_at }}
                </div>
            </div>
            
            <!-- 第2次跟进 -->
            <div class="rounded-lg p-3 border bg-green-50 border-green-200">
                <div class="font-bold text-sm text-green-600">第2次跟进</div>
                <div class="text-sm text-gray-700 mt-1">
                    <template v-if="record.followups && record.followups.find(f => f.followup_count == 2)">
                        <span v-if="record.followups.find(f => f.followup_count == 2).summary" class="bg-green-100 text-green-600 px-1 rounded mr-1">
                            {{ record.followups.find(f => f.followup_count == 2).summary }}
                        </span>
                        {{ record.followups.find(f => f.followup_count == 2).content }}
                    </template>
                    <template v-else>无</template>
                </div>
                <div v-if="record.followups && record.followups.find(f => f.followup_count == 2)" class="text-xs text-gray-500 mt-1">
                    {{ record.followups.find(f => f.followup_count == 2).created_at }}
                </div>
            </div>
            
            <!-- 第3次跟进 -->
            <div class="rounded-lg p-3 border bg-orange-50 border-orange-200">
                <div class="font-bold text-sm text-orange-600">第3次跟进</div>
                <div class="text-sm text-gray-700 mt-1">
                    <template v-if="record.followups && record.followups.find(f => f.followup_count == 3)">
                        <span v-if="record.followups.find(f => f.followup_count == 3).summary" class="bg-orange-100 text-orange-600 px-1 rounded mr-1">
                            {{ record.followups.find(f => f.followup_count == 3).summary }}
                        </span>
                        {{ record.followups.find(f => f.followup_count == 3).content }}
                    </template>
                    <template v-else>无</template>
                </div>
                <div v-if="record.followups && record.followups.find(f => f.followup_count == 3)" class="text-xs text-gray-500 mt-1">
                    {{ record.followups.find(f => f.followup_count == 3).created_at }}
                </div>
            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    const { createApp, ref, onMounted, computed } = Vue;
    createApp({
        setup() {
            const userInfo = <?php echo json_encode($CURRENT_USER); ?>;
            const records = ref([]);
            const search = ref({ keyword: '' });
            const sidebarOpen = ref(false);
            
            // 页面标题
            const pageTitle = computed(() => '跟进记录管理');
            
            // 加载跟进记录
            const loadRecords = async () => {
                try {
                    const res = await fetch('followup_records.php?action=get_followup_list');
                    const data = await res.json();
                    records.value = Array.isArray(data) ? data : [];
                } catch (e) {
                    console.error('加载记录失败:', e);
                }
            };
            
            // 搜索记录
            const searchRecords = () => {
                // 搜索逻辑已经在computed属性中实现
            };
            
            // 重置搜索
            const resetSearch = () => {
                search.value = { keyword: '' };
            };
            
            // 导出Excel
            const exportExcel = () => {
                window.location.href = 'followup_records.php?action=export_excel';
            };
            
            // 切换侧边栏
            const toggleSidebar = () => {
                sidebarOpen.value = !sidebarOpen.value;
            };
            
            // 跳转到后台管理
            const goToAdmin = () => {
                window.location.href = 'admin.php';
            };
            
            // 过滤记录
            const filteredRecords = computed(() => {
                const keyword = search.value.keyword.trim();
                if (!keyword) return records.value;
                
                return records.value.filter(record => {
                    return record.client_name.includes(keyword) ||
                           record.client_phone.includes(keyword) ||
                           record.project_name.includes(keyword) ||
                           (record.company_name && record.company_name.includes(keyword)) ||
                           (record.company_full_name && record.company_full_name.includes(keyword)) ||
                           (record.broker_name && record.broker_name.includes(keyword)) ||
                           (record.agent_name && record.agent_name.includes(keyword)) ||
                           (record.broker_phone && record.broker_phone.includes(keyword)) ||
                           (record.agent_phone && record.agent_phone.includes(keyword)) ||
                           (record.followups && record.followups.some(f => f.content.includes(keyword)));
                });
            });
            
            onMounted(() => {
                loadRecords();
            });
            
            return {
                userInfo,
                records,
                search,
                sidebarOpen,
                pageTitle,
                filteredRecords,
                loadRecords,
                searchRecords,
                resetSearch,
                exportExcel
            };
        }
    }).mount('#app');
    </script>
</body>
</html>