<aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'" class="fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-slate-400 flex flex-col shadow-xl transition-transform duration-300 md:static md:translate-x-0 flex-shrink-0">
    <div class="h-16 flex items-center px-6 font-bold text-white text-xl border-b border-slate-800 tracking-wider">
        <i class="fas fa-building text-blue-500 mr-2"></i> 易城好房Pro
    </div>
    
    <nav class="flex-1 p-4 space-y-2 overflow-y-auto">
        
        <div class="text-[10px] font-bold text-slate-500 uppercase px-4 mt-2 mb-1">决策中心</div>
        
        <a href="admin.php?v=dashboard" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition" 
           :class="{'bg-blue-600 text-white shadow-lg': view === 'dashboard'}">
            <i class="fas fa-chart-pie w-5 mr-3"></i> 驾驶舱
        </a>
        <a href="admin_statistics.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition" 
           :class="{'bg-blue-600 text-white shadow-lg': view === 'statistics'}">
            <i class="fas fa-chart-pie w-5 mr-3"></i> 数据 demo 版
        </a>
<a href="analytics.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition" 
           :class="{'bg-blue-600 text-white shadow-lg': view === 'statistics'}">
            <i class="fas fa-chart-pie w-5 mr-3"></i> 启动维度分析
        </a>



        <div class="text-[10px] font-bold text-slate-500 uppercase px-4 mt-6 mb-1">业务管理</div>
        
<a href="admin_filings.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition"
   :class="{'bg-blue-600 text-white shadow-lg': view === 'filings'}">
    <i class="fas fa-list-check w-5 mr-3"></i> 报备审核
</a>
        
        <a href="followup_records.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition"
           :class="{'bg-blue-600 text-white shadow-lg': view === 'followup_records'}">
            <i class="fas fa-file-alt w-5 mr-3"></i> 跟进记录
        </a>
        
        <a href="admin_finance.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition"
           :class="{'bg-blue-600 text-white shadow-lg': view === 'finance'}">
            <i class="fas fa-file-invoice-dollar w-5 mr-3"></i> 佣金结算
        </a>
        
        <a href="compete_admin.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition"
           :class="{'bg-blue-600 text-white shadow-lg': view === 'compete_admin'}">
            <i class="fas fa-chart-pie w-5 mr-3"></i> 数据竞对管理
        </a>
        
        <a href="compete_list.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition"
           :class="{'bg-blue-600 text-white shadow-lg': view === 'compete_list'}">
            <i class="fas fa-list w-5 mr-3"></i> 数据竞对列表
        </a>
        
        <div class="text-[10px] font-bold text-slate-500 uppercase px-4 mt-6 mb-1">资源中心</div>
        
<a href="admin_projects.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition"
   :class="{'bg-blue-600 text-white shadow-lg': view === 'projects'}">
    <i class="fas fa-city w-5 mr-3"></i> 项目库
</a>
        
        <a href="admin_companies.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition"
           :class="{'bg-blue-600 text-white shadow-lg': view === 'companies'}">
            <i class="fas fa-store w-5 mr-3"></i> 商户/中介
        </a>
        
        <div class="text-[10px] font-bold text-slate-500 uppercase px-4 mt-6 mb-1">系统配置</div>
        
<a href="admin_agents.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition"
   :class="{'bg-blue-600 text-white shadow-lg': view === 'agents'}">
    <i class="fas fa-users w-5 mr-3"></i> 内部架构
</a>
        
        <a href="import.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition text-slate-500">
            <i class="fas fa-file-import w-5 mr-3"></i> 数据导入
        </a>

        <a href="batch_import.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition text-slate-500">
            <i class="fas fa-file-import w-5 mr-3"></i> 批量报备导入
        </a>
        
        <a href="agent_import.php" class="nav-item flex items-center px-4 py-3 rounded-lg cursor-pointer hover:text-white transition" 
           :class="{'bg-blue-600 text-white shadow-lg': view === 'agent_import'}">
            <i class="fas fa-user-tie w-5 mr-3"></i> 经纪人数据
        </a>

    </nav>
</aside>