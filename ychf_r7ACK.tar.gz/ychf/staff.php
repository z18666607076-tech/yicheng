<?php
// staff.php - 案场端 (v15.0: 历史记录全能搜索)
session_start();
header('Content-Type: text/html; charset=utf-8');

// === 0. 登录鉴权 ===
if (!isset($_SESSION['agent_id'])) { header('Location: login.php'); exit; }
$CURRENT_USER = $_SESSION['agent_name'] ?? '案场经理';

// === 配置 ===
$COMMISSION_RATE = 0.03; 

// === 数据库 ===
$host = '127.0.0.1'; $db = 'ychf'; $user = 'ychf'; $pass = 'rjX5DESSbGXbewfa'; $charset = 'utf8mb4';
try { $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass); } catch (PDOException $e) { die("DB Error"); }

$action = $_GET['action'] ?? 'view';

// [API] 获取列表
if ($action == 'get_list') {
    header('Content-Type: application/json');
    $sql = "SELECT f.*, p.name as project_name, 
            COALESCE(NULLIF(f.broker_name,''), a.username) as agent_name, 
            COALESCE(NULLIF(f.broker_phone,''), a.phone) as agent_phone,
            c.name as company_full_name, c.store_name
            FROM filings f 
            LEFT JOIN projects p ON f.project_id = p.id 
            LEFT JOIN agents a ON f.agent_id = a.id
            LEFT JOIN companies c ON f.company_name = c.name
            ORDER BY f.created_at DESC LIMIT 1000";
    $stmt = $pdo->query($sql);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC)); 
    exit;
}

// [API] 搜索历史记录
if ($action == 'search_history') {
    header('Content-Type: application/json');
    $keyword = $_GET['keyword'] ?? '';
    $today = date('Y-m-d');
    
    if (empty($keyword)) {
        echo json_encode([]);
        exit;
    }
    
    $sql = "SELECT f.*, p.name as project_name, 
            COALESCE(NULLIF(f.broker_name,''), a.username) as agent_name, 
            COALESCE(NULLIF(f.broker_phone,''), a.phone) as agent_phone,
            c.name as company_full_name, c.store_name
            FROM filings f 
            LEFT JOIN projects p ON f.project_id = p.id 
            LEFT JOIN agents a ON f.agent_id = a.id
            LEFT JOIN companies c ON f.company_name = c.name
            WHERE DATE(f.created_at) < ? 
            AND (f.client_name LIKE ? OR f.client_phone LIKE ? OR p.name LIKE ? OR f.broker_name LIKE ? OR f.broker_phone LIKE ? OR a.username LIKE ? OR a.phone LIKE ? OR f.company_name LIKE ? OR c.name LIKE ? OR c.store_name LIKE ?)
            ORDER BY f.created_at DESC LIMIT 100";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$today, "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%"]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC)); 
    exit;
}

// [API] 获取项目
if ($action == 'get_projects') {
    header('Content-Type: application/json');
    echo json_encode($pdo->query("SELECT id, name FROM projects WHERE status=1")->fetchAll(PDO::FETCH_ASSOC)); exit;
}

// [API] 状态更新
if ($action == 'update') {
    header('Content-Type: application/json');
    global $COMMISSION_RATE;

    $id = $_POST['id']; 
    $currStatus = intval($_POST['curr_status']); 
    $saveType = $_POST['save_type'] ?? 'submit'; 
    
    $visitType = $_POST['visit_type'] ?? 0;
    $visitType = $visitType === 'null' ? null : intval($visitType);
    $clientIntention = intval($_POST['client_intention'] ?? 0);
    $subStages = $_POST['sub_stages'] ?? ''; 
    $voice = $_POST['voice'] ?? ''; 
    $attach = $_POST['attachment'] ?? ''; 
    $room = $_POST['room_number'] ?? ''; 
    $price = $_POST['deal_price'] ?? 0;
    $clientPhone = $_POST['client_phone'] ?? '';
    
    $subscriberName = $_POST['subscriber_name'] ?? '';
    $subscribedRoomNumber = $_POST['subscribed_room_number'] ?? '';
    $transactionArea = $_POST['transaction_area'] ?? 0;
    $salesperson = $_POST['salesperson'] ?? '';
    $subscriptionPhoneFull = $_POST['subscription_phone_full'] ?? '';
    $subscriptionDate = $_POST['subscription_date'] ?? '';
    $transactionRecorder = $_POST['transaction_recorder'] ?? '';
    
    $logPrefix = "\n" . date('Y-m-d H:i') . " [案场] ";
    $sql = ""; $params = []; $setClauses = [];

    if ($currStatus == 1) {
            if($visitType === null) {
                // 取消到访类型选择，变回待处理
                $log = $logPrefix . "取消到访类型，变回待处理"; 
                $targetStatus = 1;
                $setClauses = ["status = ?", "visit_type = NULL", "status_log = CONCAT(IFNULL(status_log,''), ?)"];
                $params = [$targetStatus, $log];
            } else {
                // 只有当不是报备无效时，才检查客户意向
                if($visitType != 4 && empty($clientIntention)) { echo json_encode(['status'=>'error', 'msg'=>'请选择客户意向']); exit; }
                if ($visitType == 0) { $log = $logPrefix . "确认有效报备"; $targetStatus = 1; } 
                elseif ($visitType == 1) { $log = $logPrefix . "确认有效到访"; $targetStatus = 2; } 
                elseif ($visitType == 4) { 
                    $log = $logPrefix . "标记为报备无效"; 
                    $targetStatus = 6; 
                }
                else { 
                    $desc = ($visitType == 2) ? '无效到访' : '重复到访'; 
                    $log = $logPrefix . "标记为" . $desc; 
                    $targetStatus = 5; 
                }
                // 只有当不是报备无效时，才设置client_intention
                if($visitType == 4) {
                    $setClauses = ["status = ?", "visit_type = ?", "status_log = CONCAT(IFNULL(status_log,''), ?)"];
                    $params = [$targetStatus, $visitType, $log];
                } else {
                    $setClauses = ["status = ?", "visit_type = ?", "client_intention = ?", "status_log = CONCAT(IFNULL(status_log,''), ?)"];
                    $params = [$targetStatus, $visitType, $clientIntention, $log];
                }
                if ($attach) { $setClauses[] = "attachments = ?"; $params[] = $attach; }
            }
    }
    elseif ($currStatus == 4) {
        // 从成交状态修改为退房状态
        $log = $logPrefix . "标记为退房";
        $targetStatus = 7;
        $setClauses = ["status = ?", "status_log = CONCAT(IFNULL(status_log,''), ?)"];
        $params = [$targetStatus, $log];
        if ($attach) { $setClauses[] = "attachments = ?"; $params[] = $attach; }
    }
    elseif ($currStatus == 5 || $currStatus == 6) {
        // 从无效/重复/报备无效状态修改为待处理状态
        $log = $logPrefix . "重新标记为待处理";
        $targetStatus = 1;
        $setClauses = ["status = ?", "visit_type = 0", "status_log = CONCAT(IFNULL(status_log,''), ?)"];
        $params = [$targetStatus, $log];
        if ($attach) { $setClauses[] = "attachments = ?"; $params[] = $attach; }
    }
    elseif ($currStatus == 2) {
        // 处理无效到访情况
        if ($visitType == 2) {
            $log = $logPrefix . "标记为无效到访";
            $targetStatus = 5;
            $setClauses = ["status = ?", "visit_type = ?", "status_log = CONCAT(IFNULL(status_log,''), ?)"];
            $params = [$targetStatus, $visitType, $log];
            if ($attach) { $setClauses[] = "attachments = ?"; $params[] = $attach; }
        } else {
            $stagesArr = [];
            if(strpos($subStages, 'deposit')!==false) $stagesArr[] = '已交定';
            if(strpos($subStages, 'lock')!==false) $stagesArr[] = '已认筹';
            if(strpos($subStages, 'sign')!==false) $stagesArr[] = '已认购';
            $stageStr = implode('/', $stagesArr);

            if ($saveType === 'save') {
                $targetStatus = 2;
                $log = $logPrefix . "更新下定进度: " . ($stageStr ?: '无变化');
            } else {
                $targetStatus = 3;
                $log = $logPrefix . "完成下定流程 ($stageStr)，进入待签约";
            }
            if($room) $log .= " [房号:$room]";
            $setClauses = ["status = ?", "room_number = ?", "attachments = ?", "status_log = CONCAT(IFNULL(status_log,''), ?)"];
            $params = [$targetStatus, $room, $attach, $log];
            // 即使subStages为空字符串，也应该保存到数据库中
            $setClauses[] = "sub_stages = ?";
            $params[] = $subStages;
            if ($clientPhone) {
                $setClauses[] = "client_phone = ?";
                $params[] = $clientPhone;
            }
            $setClauses[] = "client_intention = ?";
            $params[] = $clientIntention;
        }
    }
    elseif ($currStatus == 3) {
        if ($saveType === 'refund') {
            $log = $logPrefix . "标记为退房";
            $targetStatus = 7;
            $setClauses = ["status = ?", "status_log = CONCAT(IFNULL(status_log,''), ?)"];
            $params = [$targetStatus, $log];
            if ($attach) { $setClauses[] = "attachments = ?"; $params[] = $attach; }
        } else {
            if (empty($price) || $price <= 0) { echo json_encode(['status'=>'error', 'msg'=>'请填写成交总价']); exit; } 
            $comm_amt = $price * $COMMISSION_RATE;
            $log = $logPrefix . "正式签约 [总价:¥{$price}, 佣:¥{$comm_amt}]";
            $setClauses = ["status = 4", "deal_price = ?", "commission_amount = ?", "commission_status = 0", "status_log = CONCAT(IFNULL(status_log,''), ?)"];
            $params = [$price, $comm_amt, $log];
            if ($attach) { $setClauses[] = "attachments = ?"; $params[] = $attach; }
            if ($clientPhone) {
                $setClauses[] = "client_phone = ?";
                $params[] = $clientPhone;
            }
            if ($subscriberName !== '') {
                $setClauses[] = "subscriber_name = ?";
                $params[] = $subscriberName;
            }
            if ($subscribedRoomNumber !== '') {
                $setClauses[] = "subscribed_room_number = ?";
                $params[] = $subscribedRoomNumber;
            }
            if ($transactionArea !== '') {
                $setClauses[] = "transaction_area = ?";
                $params[] = $transactionArea;
            }
            if ($salesperson !== '') {
                $setClauses[] = "salesperson = ?";
                $params[] = $salesperson;
            }
            if ($subscriptionPhoneFull !== '') {
                $setClauses[] = "subscription_phone_full = ?";
                $params[] = $subscriptionPhoneFull;
            }
            if ($subscriptionDate !== '') {
                $setClauses[] = "subscription_date = ?";
                $params[] = $subscriptionDate;
            }
            if ($transactionRecorder !== '') {
                $setClauses[] = "transaction_recorder = ?";
                $params[] = $transactionRecorder;
            }
        }
    }

    if($voice) $params[count($params)-1] .= " (备注: $voice)";
    
    if (!empty($setClauses)) {
        $sql = "UPDATE filings SET " . implode(', ', $setClauses) . " WHERE id = ?";
        $params[] = $_POST['id'];
        try { $pdo->prepare($sql)->execute($params); echo json_encode(['status'=>'success']); } catch (Exception $e) { echo json_encode(['status'=>'error', 'msg'=>$e->getMessage()]); }
    } else { echo json_encode(['status'=>'success']); }
    exit;
}

// [API] 统计
if ($action == 'get_stats') {
    header('Content-Type: application/json');
    $baseSql = "FROM filings"; 
    $today_visit = $pdo->query("SELECT count(*) $baseSql WHERE status >= 2 AND date(created_at) = CURDATE()")->fetchColumn();
    $today_deal = $pdo->query("SELECT count(*) $baseSql WHERE status = 4 AND date(created_at) = CURDATE()")->fetchColumn();
    $month_deal = $pdo->query("SELECT count(*) $baseSql WHERE status = 4")->fetchColumn();
    $month_visit = $pdo->query("SELECT count(*) $baseSql WHERE status >= 2")->fetchColumn();
    $s1 = $pdo->query("SELECT count(*) $baseSql WHERE status >= 1")->fetchColumn();
    $s2 = $pdo->query("SELECT count(*) $baseSql WHERE status >= 2")->fetchColumn();
    $s3 = $pdo->query("SELECT count(*) $baseSql WHERE status >= 3")->fetchColumn();
    $s4 = $pdo->query("SELECT count(*) $baseSql WHERE status = 4")->fetchColumn();
    echo json_encode([ 'today_visit' => $today_visit, 'today_deal' => $today_deal, 'month_visit' => $month_visit, 'month_deal' => $month_deal, 'funnel' => [['value'=>$s1,'name'=>'报备'],['value'=>$s2,'name'=>'到访'],['value'=>$s3,'name'=>'下定'],['value'=>$s4,'name'=>'成交']] ]); exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>案场工作台</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/echarts@5.4.0/dist/echarts.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; }
        .glass-nav { background: rgba(255,255,255,0.95); backdrop-filter: blur(12px); border-top: 1px solid #f1f5f9; padding-bottom: env(safe-area-inset-bottom); }
        .mic-active { animation: pulse 1.5s infinite; }
        @keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); } 70% { box-shadow: 0 0 0 10px rgba(239, 68, 68, 0); } 100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); } }
        .card-shadow { box-shadow: 0 4px 20px -2px rgba(0,0,0,0.05); }
        .purple-gradient { background: linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%); }
        .timeline-item { position: relative; padding-left: 24px; padding-bottom: 24px; border-left: 2px solid #e2e8f0; }
        .timeline-item:last-child { border-left: 2px solid transparent; }
        .timeline-dot { position: absolute; left: -6px; top: 0; width: 10px; height: 10px; border-radius: 50%; background: #cbd5e1; border: 2px solid #fff; box-shadow: 0 0 0 2px #fff; }
        .timeline-dot.active { background: #8b5cf6; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .filter-input { width: 100%; background-color: #f9fafb; border: 1px solid #e5e7eb; border-radius: 0.5rem; padding: 0.5rem; font-size: 0.75rem; outline: none; transition: all 0.2s; }
        .filter-input:focus { border-color: #e9d5ff; ring: 1px solid #e9d5ff; }
        .filter-label { font-size: 10px; font-weight: bold; color: #9ca3af; margin-bottom: 4px; display: block; }
        
        .stage-box { border: 1px solid #e2e8f0; border-radius: 0.75rem; padding: 0.75rem; display: flex; align-items: center; cursor: pointer; background: white; transition: all 0.2s; }
        .stage-box.checked { border-color: #8b5cf6; background-color: #f5f3ff; color: #6d28d9; }
        .stage-icon { width: 1.25rem; height: 1.25rem; border-radius: 9999px; border: 2px solid #cbd5e1; margin-right: 0.5rem; display: flex; align-items: center; justify-content: center; font-size: 0.6rem; color: white; transition: all 0.2s; }
        .stage-box.checked .stage-icon { background-color: #8b5cf6; border-color: #8b5cf6; }
        
        .sub-chip { padding: 4px 12px; border-radius: 9999px; font-size: 12px; font-weight: bold; margin-right: 8px; margin-bottom: 8px; cursor: pointer; border: 1px solid transparent; transition: all 0.2s; display: inline-block; }
        .sub-chip.active { background-color: #9333ea; color: white; border-color: #9333ea; box-shadow: 0 4px 6px -1px rgba(147, 51, 234, 0.3); }
        .sub-chip.inactive { background-color: white; color: #64748b; border-color: #e2e8f0; }
    </style>
</head>
<body>
<div id="app" class="max-w-md mx-auto min-h-screen pb-24 relative bg-gray-50">
    
    <div v-if="tab==='dash'" class="bg-white p-5 pt-8 pb-16 rounded-b-[2rem] shadow-sm relative z-0">
        <div class="flex justify-between items-center mb-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-bold border-2 border-white shadow-sm"><i class="fas fa-user-shield"></i></div>
                <div><div class="text-xs text-gray-400">{{ currentDate }}</div><h1 class="font-bold text-lg text-slate-800">你好，<?= $CURRENT_USER ?></h1></div>
            </div>
            <a href="logout.php" class="text-xs bg-gray-100 text-gray-500 px-3 py-1.5 rounded-full font-bold flex items-center gap-1"><i class="fas fa-sign-out-alt"></i> 退出</a>
        </div>
    </div>
    
    <div v-else class="sticky top-0 z-40 bg-white/95 backdrop-blur p-4 shadow-sm flex justify-between items-center">
        <h2 class="font-bold text-lg text-slate-800">{{ tab==='work'?'工作台':'历史记录' }}</h2>
    </div>

    <div :class="{'px-4 -mt-10 relative z-10': tab==='dash', 'p-4': tab!=='dash'}" class="space-y-5">
        
        <div v-if="tab==='dash'" class="space-y-5 fade-in">
            <div class="purple-gradient rounded-3xl p-6 text-white shadow-lg shadow-purple-500/20 relative overflow-hidden">
                <div class="relative z-10">
                    <div class="text-purple-100 text-xs font-medium mb-1">本月成交 (套)</div>
                    <div class="text-4xl font-bold mb-6">{{ stats.month_deal }}</div>
                    <div class="flex gap-8 border-t border-white/20 pt-4">
                        <div><div class="text-purple-100 text-xs mb-1">本月到访</div><div class="text-xl font-bold">{{ stats.month_visit }}</div></div>
                        <div><div class="text-purple-100 text-xs mb-1">今日到访</div><div class="text-xl font-bold">{{ stats.today_visit }}</div></div>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-3xl p-5 card-shadow">
                <h3 class="font-bold text-sm text-slate-700 mb-2">全盘转化漏斗</h3>
                <div id="funnel" class="w-full h-48"></div>
            </div>
            
            <div class="bg-white rounded-3xl p-6 card-shadow">
                <button @click="goToCompete" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-4 px-6 rounded-2xl transition-all duration-300 shadow-lg shadow-purple-500/20 flex items-center justify-center gap-2">
                    <i class="fas fa-chart-pie text-xl"></i>
                    <span class="text-lg">录入竞对</span>
                </button>
            </div>
        </div>

        <div v-if="tab==='work'">
            <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-2 mb-3 flex gap-2">
                <div class="flex-1 flex items-center bg-gray-50 rounded-lg px-3">
                    <i class="fas fa-search text-gray-400 text-sm"></i>
                    <input v-model="workSearch" type="text" class="w-full p-2 bg-transparent text-sm outline-none" placeholder="全能搜索/姓名/手机/项目/门店/公司名/销售等">
                </div>
                <button @click="searchHistory" class="w-10 h-10 bg-purple-600 text-white rounded-lg flex items-center justify-center shadow-lg active:scale-95 transition" :class="{'bg-purple-700': isSearchingHistory}"><i class="fas fa-history text-lg"></i></button>
                <button @click="simulateScan" class="w-10 h-10 bg-slate-800 text-white rounded-lg flex items-center justify-center shadow-lg active:scale-95 transition"><i class="fas fa-qrcode text-lg"></i></button>
            </div>

            <div class="flex bg-white p-1 rounded-xl mb-3 text-xs font-bold text-gray-500 shadow-sm border border-gray-100 overflow-x-auto no-scrollbar">
                <button v-for="t in tabs" :key="t.id" @click="changeMainTab(t.id)" class="flex-1 min-w-[70px] py-2.5 rounded-lg transition-all whitespace-nowrap flex items-center justify-center gap-1" :class="subTab===t.id ? 'bg-purple-50 text-purple-600 shadow-sm' : 'hover:bg-gray-50'">
                    {{ t.name }} <span class="px-1.5 py-0.5 rounded-full text-[10px]" :class="subTab===t.id ? 'bg-purple-200 text-purple-700' : 'bg-gray-100 text-gray-400'">{{ counts[t.id] || 0 }}</span>
                </button>
            </div>

            <div v-if="subTab===1 || subTab===2" class="mb-4 animate-[fadeIn_0.3s_ease-out]">
                <div v-if="subTab===1">
                    <span @click="childFilter='todo'" class="sub-chip" :class="childFilter==='todo'?'active':'inactive'">待处理</span>
                    <span @click="childFilter='valid_report'" class="sub-chip" :class="childFilter==='valid_report'?'active':'inactive'">有效报备</span>
                    <span @click="childFilter='valid'" class="sub-chip" :class="childFilter==='valid'?'active':'inactive'">有效到访</span>
                    <span @click="childFilter='invalid_report'" class="sub-chip" :class="childFilter==='invalid_report'?'active':'inactive'">报备无效</span>
                    <span @click="childFilter='invalid_visit'" class="sub-chip" :class="childFilter==='invalid_visit'?'active':'inactive'">到访无效</span>
                    <span @click="childFilter='repeat'" class="sub-chip" :class="childFilter==='repeat'?'active':'inactive'">重复</span>
                </div>
                <div v-if="subTab===2">
                    <span @click="childFilter='all'" class="sub-chip" :class="childFilter==='all'?'active':'inactive'">全部</span>
                    <span @click="childFilter='deposit'" class="sub-chip" :class="childFilter==='deposit'?'active':'inactive'">诚意金</span>
                    <span @click="childFilter='lock'" class="sub-chip" :class="childFilter==='lock'?'active':'inactive'">锁房</span>
                    <span @click="childFilter='sign'" class="sub-chip" :class="childFilter==='sign'?'active':'inactive'">认购</span>
                    <span @click="childFilter='refund'" class="sub-chip" :class="childFilter==='refund'?'active':'inactive'">退房</span>
                    <span @click="childFilter='todo'" class="sub-chip" :class="childFilter==='todo'?'active':'inactive'">待办事项 <span class="px-1.5 py-0.5 rounded-full text-[10px]" :class="childFilter==='todo' ? 'bg-purple-200 text-purple-700' : 'bg-gray-100 text-gray-400'">{{ pendingCount }}</span></span>
                </div>
            </div>

            <div class="space-y-4 pb-20">
                <div v-if="groupedWorkList.length==0" class="text-center py-16 text-gray-400 text-xs bg-white rounded-2xl border border-dashed border-gray-200">暂无任务</div>
                <div v-for="(group, idx) in groupedWorkList" :key="idx" class="bg-white rounded-2xl card-shadow overflow-hidden max-w-[800px] mx-auto">
                    <div class="bg-gray-50 p-3 border-b border-gray-100 flex justify-between items-center">
                        <div class="flex items-center gap-2">
                            <div class="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold text-xs">{{ group.client_name.charAt(0) }}</div>
                            <div class="flex-1 min-w-0">
                                <div class="font-bold text-sm text-slate-800 truncate">{{ group.client_name }} <span class="font-normal text-xs text-gray-400" v-html="formatPhone(group.client_phone)"></span></div>
                                <div class="text-[10px] text-gray-400 truncate">渠道: {{ group.items[0].agent_name || '未知' }}</div>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0 text-right">
                            <div class="text-[10px] text-gray-400 truncate">{{ group.items[0].company_name || '未知' }}</div>
                            <div class="text-[10px] text-gray-400 truncate">经纪人: {{ group.items[0].agent_name || '未知' }} <span v-html="formatPhone(group.items[0].agent_phone, true)"></span></div>
                        </div>
                        <span class="bg-white border border-gray-200 text-gray-500 text-[10px] px-2 py-1 rounded-full ml-2">{{ group.items.length }} 单</span>
                    </div>
                    <div class="divide-y divide-gray-50">
                        <div v-for="item in group.items" :key="item.id" class="p-3 relative">
                            <div class="absolute left-0 top-0 bottom-0 w-1" :class="item.status==4?'bg-green-500':'bg-purple-500'"></div>
                            <div class="flex justify-between items-start mb-2">
                                <div class="flex-1 min-w-0">
                                    <div class="font-bold text-sm text-slate-700 truncate">{{ item.project_name }}</div>
                                    <div class="text-[10px] text-gray-400 mt-0.5">报备: {{ item.created_at.substring(5,19) }}</div>
                                    <div v-if="item.status==2 && item.sub_stages" class="flex gap-1 mt-1">
                                        <span v-if="item.sub_stages.includes('deposit')" class="text-[10px] bg-purple-50 text-purple-600 px-1.5 py-0.5 rounded">定</span>
                                        <span v-if="item.sub_stages.includes('lock')" class="text-[10px] bg-orange-50 text-orange-600 px-1.5 py-0.5 rounded">锁</span>
                                        <span v-if="item.sub_stages.includes('sign')" class="text-[10px] bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded">签</span>
                                    </div>
                                </div>
                                <!-- 将按钮移到右侧，与项目名称同一行 -->
                                <div v-if="item.status < 4 || item.status == 5 || item.status == 6" class="flex items-start ml-4">
                                    <div v-if="item.status == 1" class="flex gap-2">
                                        <button @click="markAsInvalid(item)" :disabled="item.status != 1" class="bg-gray-500 text-white py-1 px-3 rounded-lg text-xs font-bold shadow active:scale-95 transition-transform flex items-center justify-center gap-1" :class="item.status != 1 ? 'opacity-50 cursor-not-allowed' : ''">
                                            <span>无效报备</span>
                                        </button>
                                        <button @click="openModal(item)" :disabled="item.status != 1" class="bg-orange-500 text-white py-1 px-3 rounded-lg text-xs font-bold shadow active:scale-95 transition-transform flex items-center justify-center gap-1" :class="item.status != 1 ? 'opacity-50 cursor-not-allowed' : ''">
                                            <span>确认到访</span>
                                        </button>
                                    </div>
                                    <div v-else-if="item.status == 2" class="flex gap-2">
                                        <button @click="markAsInvalidVisit(item)" class="bg-red-500 text-white py-1 px-3 rounded-lg text-xs font-bold shadow active:scale-95 transition-transform flex items-center justify-center gap-1">
                                            <span>无效到访</span>
                                        </button>
                                        <button @click="openModal(item)" :class="{
                                            'bg-purple-500': item.status == 2,
                                            'bg-green-500': item.status == 3,
                                            'bg-slate-700': item.status != 2 && item.status != 3
                                        }" class="text-white py-1 px-3 rounded-lg text-xs font-bold shadow active:scale-95 transition-transform flex items-center justify-center gap-1">
                                            <span>{{ item.status == 5 || item.status == 6 ? '修改状态' : getActionText(item.status) }}</span>
                                            <i class="fas fa-arrow-right opacity-50"></i>
                                        </button>
                                    </div>
                                    <button v-else-if="item.status != 2" @click="openModal(item)" :class="{
                                        'bg-purple-500': item.status == 2,
                                        'bg-green-500': item.status == 3,
                                        'bg-slate-700': item.status != 2 && item.status != 3
                                    }" class="text-white py-1 px-3 rounded-lg text-xs font-bold shadow active:scale-95 transition-transform flex items-center justify-center gap-1">
                                        <span>{{ item.status == 5 || item.status == 6 ? '修改状态' : getActionText(item.status) }}</span>
                                        <i class="fas fa-arrow-right opacity-50"></i>
                                    </button>
                                </div>
                                <div class="flex flex-col items-end gap-1 ml-2">
                                    <div class="flex gap-1 mb-1">
                                        <button @click="showTimeline(item)" class="text-blue-500 text-xs bg-blue-50 px-2 py-1 rounded flex items-center gap-1 active:bg-blue-100">
                                            <i class="fas fa-history"></i>
                                        </button>
                                        <button @click="copyFilingData(item)" class="text-purple-500 text-xs bg-purple-50 px-2 py-1 rounded flex items-center gap-1 active:bg-purple-100">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                    </div>
                                    <span v-if="item.status == 1 && (!item.visit_type || item.visit_type != 0)" class="text-[10px] bg-gray-100 text-gray-500 px-2 py-0.5 rounded border border-gray-200">待处理</span>
                                    <span v-if="item.status == 1 && item.visit_type == 0" class="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded border border-blue-200">有效报备</span>
                                    <span v-if="item.status >= 2 && item.visit_type==1" class="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded border border-green-200">有效到访</span>
                                    <span v-if="item.status == 5 && item.visit_type==2" class="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded border border-red-200">无效到访</span>
                                    <span v-if="item.status == 5 && item.visit_type==3" class="text-[10px] bg-orange-100 text-orange-700 px-2 py-0.5 rounded border border-orange-200">重复到访</span>
                                    <span v-if="item.status == 6" class="text-[10px] bg-gray-200 text-gray-600 px-2 py-0.5 rounded border border-gray-300">报备无效</span>
                                </div>
                            </div>
                            <div v-if="item.status==4" class="mb-2 bg-green-50 p-2 rounded-lg border border-green-100 text-[10px]">
                                <div class="flex items-center justify-between text-green-700 mb-1">
                                    <span>佣金: ¥{{ parseFloat(item.commission_amount).toLocaleString() }}</span>
                                    <span :class="commColor(item.commission_status)">{{ commText(item.commission_status) }}</span>
                                </div>
                                <div class="h-1.5 w-full bg-green-200 rounded-full overflow-hidden">
                                    <div class="h-full bg-green-600 transition-all duration-500" :style="`width: ${(parseInt(item.commission_status)+1)*33}%`"></div>
                                </div>
                            </div>
                            <!-- 移除原来的按钮区域 -->
                            <div v-if="item.status==4" class="text-center text-xs text-green-600 font-bold mt-2"><i class="fas fa-check-circle mr-1"></i> 订单已完成</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div v-if="tab==='list'" class="space-y-4">
            
            <div class="bg-white rounded-xl shadow-sm border border-slate-100 p-2 flex gap-2">
                <div class="flex-1 flex items-center bg-gray-50 rounded-lg px-3">
                    <i class="fas fa-search text-gray-400 text-sm"></i>
                    <input v-model="historySearch" type="text" class="w-full p-2 bg-transparent text-sm outline-none" placeholder="搜姓名/电话/项目/进度/状态...">
                </div>
            </div>

            <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <div class="p-3 flex justify-between items-center cursor-pointer bg-gray-50 border-b border-gray-100" @click="showFilters = !showFilters">
                    <div class="text-xs font-bold text-slate-700"><i class="fas fa-filter text-purple-500 mr-1"></i> 高级筛选</div>
                    <div class="text-xs text-gray-400"><i class="fas" :class="showFilters ? 'fa-chevron-up' : 'fa-chevron-down'"></i></div>
                </div>
                <div v-if="showFilters" class="p-4 bg-white animate-[slideUp_0.2s_ease-out]">
                    <div class="grid grid-cols-2 gap-3 mb-3"><div><label class="filter-label">开始日期</label><input v-model="filters.dateStart" type="date" class="filter-input"></div><div><label class="filter-label">结束日期</label><input v-model="filters.dateEnd" type="date" class="filter-input"></div></div>
                    <div class="mb-3"><label class="filter-label">所属楼盘</label><select v-model="filters.project" class="filter-input"><option value="">全部楼盘</option><option v-for="p in projects" :key="p.id" :value="p.name">{{ p.name }}</option></select></div>
                    <div class="grid grid-cols-2 gap-3">
                        <button @click="resetFilters" class="bg-gray-100 text-gray-500 py-2 rounded-lg text-xs font-bold">重置条件</button>
                        <button @click="applyFilters" class="bg-purple-600 text-white py-2 rounded-lg text-xs font-bold">确定筛选</button>
                    </div>
                </div>
            </div>
            
            <div v-if="groupedHistoryList.length===0" class="text-center py-10 text-gray-300 text-xs">没有找到符合条件的记录</div>
            <div v-for="(group, idx) in groupedHistoryList" :key="idx" class="bg-white rounded-2xl card-shadow overflow-hidden mb-3">
                <div class="bg-slate-50 p-3 border-b border-gray-100 flex justify-between items-center"><div class="font-bold text-sm text-slate-800">{{ group.client_name }} <span class="text-xs font-normal text-gray-400 font-mono">{{ group.client_phone }}</span></div><span class="text-[10px] text-gray-400">{{ group.items.length }} 记录</span></div>
                <div class="divide-y divide-gray-50"><div v-for="item in group.items" :key="item.id" class="p-3 flex justify-between items-center"><div><div class="font-bold text-xs text-slate-700">{{ item.project_name }}</div><div class="text-[10px] text-gray-400 mt-0.5">{{ item.created_at.substring(5,19) }} · {{ item.agent_name }}</div></div><div class="text-right"><span class="text-[10px] px-2 py-0.5 rounded font-bold mb-1 inline-block" :class="statusClass(item.status)">{{ statusText(item.status) }}</span><button @click="showTimeline(item)" class="block text-[10px] text-blue-500 mt-1">查看详情</button></div></div></div>
            </div>
        </div>
    </div>

    <div class="fixed bottom-0 w-full max-w-md bg-white border-t border-slate-100 flex justify-around py-3 text-[10px] text-gray-400 z-40 glass-nav">
        <div @click="tab='dash'" :class="tab=='dash'?'text-purple-600':''" class="flex flex-col items-center gap-1 cursor-pointer"><i class="fas fa-chart-line text-xl"></i><span>数据</span></div>
        <div @click="goToFiling" class="flex flex-col items-center gap-1 cursor-pointer"><i class="fas fa-file-alt text-xl"></i><span>报备</span></div>
        <div @click="tab='work'" :class="tab=='work'?'text-purple-600':''" class="flex flex-col items-center gap-1 cursor-pointer"><i class="fas fa-check-double text-xl"></i><span>工作台</span></div>
        <div @click="tab='list'" :class="tab=='list'?'text-purple-600':''" class="flex flex-col items-center gap-1 cursor-pointer"><i class="fas fa-clock text-xl"></i><span>记录</span></div>
    </div>

    <div v-if="showModal" class="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm">
        <div class="bg-white w-full rounded-t-[2rem] p-6 animate-[slideUp_0.3s_ease-out] max-h-[90vh] overflow-y-auto">
            <div class="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mb-6"></div>
            <h3 class="font-bold text-xl mb-1 text-slate-800">{{ currentItem.status == 5 || currentItem.status == 6 ? '修改状态' : getActionText(currentItem.status) }}</h3>
            <p class="text-xs text-gray-400 mb-6">客户: {{ currentItem.client_name }} - {{ currentItem.project_name }}</p>
            <div class="space-y-4 mb-6">
                <div v-if="currentItem.status==1">
                    <label class="text-xs font-bold text-slate-500 block mb-3">到访类型 (必选)</label>
                    <div class="grid grid-cols-2 gap-3 mb-4">
                            <div @click="visitType=visitType===0?null:0" class="border rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer transition hover:bg-gray-50" :class="visitType===0?'border-purple-500 bg-purple-50 text-purple-700':'border-gray-200 text-gray-400'" ><i class="fas fa-file-alt text-xl mb-1"></i><span class="text-xs font-bold">有效报备</span></div>
                            <div @click="visitType=visitType===1?null:1" class="border rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer transition hover:bg-gray-50" :class="visitType===1?'border-purple-500 bg-purple-50 text-purple-700':'border-gray-200 text-gray-400'" ><i class="fas fa-check-circle text-xl mb-1"></i><span class="text-xs font-bold">有效到访</span></div>
                            <div @click="visitType=visitType===2?null:2" class="border rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer transition hover:bg-gray-50" :class="visitType===2?'border-purple-500 bg-purple-50 text-purple-700':'border-gray-200 text-gray-400'" ><i class="fas fa-times-circle text-xl mb-1"></i><span class="text-xs font-bold">无效到访</span></div>
                            <div @click="visitType=visitType===3?null:3" class="border rounded-xl p-3 flex flex-col items-center justify-center cursor-pointer transition hover:bg-gray-50" :class="visitType===3?'border-purple-500 bg-purple-50 text-purple-700':'border-gray-200 text-gray-400'" ><i class="fas fa-clone text-xl mb-1"></i><span class="text-xs font-bold">重复到访</span></div>
                        </div>
                    <div class="bg-purple-50 rounded-2xl p-4 border border-purple-100 mb-3"><div class="flex justify-between text-xs text-purple-500 font-bold mb-2"><span><i class="fas fa-microphone mr-1"></i> 备注说明 (选填)</span></div><div class="flex gap-3 items-center"><button @click="toggleRecord" class="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center transition-all shadow-md" :class="recording?'bg-red-500 text-white mic-active':'bg-white text-purple-500'" ><i class="fas" :class="recording?'fa-stop':'fa-microphone'"></i></button><textarea v-model="voiceText" placeholder="客户意向、关注点..." class="flex-1 bg-white rounded-xl p-2 h-10 border border-purple-100 text-xs resize-none"></textarea></div></div>
                    <div class="border-2 border-dashed border-slate-200 rounded-xl p-4 bg-slate-50"><div v-if="attachmentList.length === 0" class="text-center py-4 relative cursor-pointer"><i class="fas fa-camera text-slate-300 text-2xl mb-2"></i><p class="text-xs text-slate-400">上传凭证 (选填)</p><input type="file" @change="handleFile" multiple class="absolute inset-0 opacity-0 w-full h-full"></div><div v-else class="grid grid-cols-3 gap-2"><div v-for="(url, idx) in attachmentList" :key="idx" class="relative aspect-square rounded-lg overflow-hidden border border-gray-200"><img :src="url" class="w-full h-full object-cover"><div @click="removeAttachment(idx)" class="absolute top-0 right-0 bg-red-500 text-white w-5 h-5 flex items-center justify-center rounded-bl-lg text-[10px] cursor-pointer">×</div></div><div class="relative aspect-square rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center bg-white"><i class="fas fa-plus text-gray-300"></i><input type="file" @change="handleFile" multiple class="absolute inset-0 opacity-0 w-full h-full"></div></div></div>
                </div>
                <div v-if="currentItem.status==5 || currentItem.status==6">
                    <label class="text-xs font-bold text-slate-500 block mb-3">状态修改 (必选)</label>
                    <div class="grid grid-cols-1 gap-3 mb-4">
                        <div @click="visitType=1" class="border rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition hover:bg-gray-50 border-green-500 bg-green-50 text-green-700" ><i class="fas fa-undo text-xl mb-1"></i><span class="text-xs font-bold">重新标记为待处理</span></div>
                    </div>
                    <div class="bg-purple-50 rounded-2xl p-4 border border-purple-100 mb-3"><div class="flex justify-between text-xs text-purple-500 font-bold mb-2"><span><i class="fas fa-microphone mr-1"></i> 备注说明 (选填)</span></div><textarea v-model="voiceText" placeholder="修改原因..." class="w-full bg-white rounded-xl p-2 h-10 border border-purple-100 text-xs resize-none"></textarea></div>
                    <div class="border-2 border-dashed border-slate-200 rounded-xl p-4 bg-slate-50"><div v-if="attachmentList.length === 0" class="text-center py-4 relative cursor-pointer"><i class="fas fa-camera text-slate-300 text-2xl mb-2"></i><p class="text-xs text-slate-400">上传凭证 (选填)</p><input type="file" @change="handleFile" multiple class="absolute inset-0 opacity-0 w-full h-full"></div><div v-else class="grid grid-cols-3 gap-2"><div v-for="(url, idx) in attachmentList" :key="idx" class="relative aspect-square rounded-lg overflow-hidden border border-gray-200"><img :src="url" class="w-full h-full object-cover"><div @click="removeAttachment(idx)" class="absolute top-0 right-0 bg-red-500 text-white w-5 h-5 flex items-center justify-center rounded-bl-lg text-[10px] cursor-pointer">×</div></div><div class="relative aspect-square rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center bg-white"><i class="fas fa-plus text-gray-300"></i><input type="file" @change="handleFile" multiple class="absolute inset-0 opacity-0 w-full h-full"></div></div></div>
                </div>
                <div v-if="currentItem.status==2">
                    <div class="mb-4">
                        <label class="text-xs font-bold text-slate-500 block mb-3">客户意向 (必选)</label>
                        <div class="grid grid-cols-5 gap-2">
                            <div @click="clientIntention=clientIntention===5?0:5" class="border rounded-lg p-2 flex flex-col items-center justify-center cursor-pointer transition hover:bg-gray-50" :class="clientIntention===5?'border-purple-500 bg-purple-50 text-purple-700':'border-gray-200 text-gray-400'" ><span class="text-[10px] font-bold">非常强烈</span></div>
                            <div @click="clientIntention=clientIntention===4?0:4" class="border rounded-lg p-2 flex flex-col items-center justify-center cursor-pointer transition hover:bg-gray-50" :class="clientIntention===4?'border-purple-500 bg-purple-50 text-purple-700':'border-gray-200 text-gray-400'" ><span class="text-[10px] font-bold">强烈</span></div>

                            <div @click="clientIntention=clientIntention===2?0:2" class="border rounded-lg p-2 flex flex-col items-center justify-center cursor-pointer transition hover:bg-gray-50" :class="clientIntention===2?'border-purple-500 bg-purple-50 text-purple-700':'border-gray-200 text-gray-400'" ><span class="text-[10px] font-bold">还行</span></div>
                            <div @click="clientIntention=clientIntention===1?0:1" class="border rounded-lg p-2 flex flex-col items-center justify-center cursor-pointer transition hover:bg-gray-50" :class="clientIntention===1?'border-purple-500 bg-purple-50 text-purple-700':'border-gray-200 text-gray-400'" ><span class="text-[10px] font-bold">无意向</span></div>
                        </div>
                    </div>
                    <label class="text-xs font-bold text-orange-600 block mb-2"><i class="fas fa-tasks mr-1"></i> 下定进度 (可多选/暂存)</label>
                    <div class="grid grid-cols-3 gap-3 mb-4">
                        <div @click="toggleStage('deposit')" class="stage-box" :class="{checked: subStages.includes('deposit')}"><div class="stage-icon"><i class="fas fa-check" v-if="subStages.includes('deposit')"></i></div><span class="text-xs font-bold">诚意金</span></div>
                        <div @click="toggleStage('lock')" class="stage-box" :class="{checked: subStages.includes('lock')}"><div class="stage-icon"><i class="fas fa-check" v-if="subStages.includes('lock')"></i></div><span class="text-xs font-bold">认筹</span></div>
                        <div @click="toggleStage('sign')" class="stage-box" :class="{checked: subStages.includes('sign')}"><div class="stage-icon"><i class="fas fa-check" v-if="subStages.includes('sign')"></i></div><span class="text-xs font-bold">签认购书</span></div>
                    </div>
                    <div v-if="subStages.includes('sign')" class="mb-3">
                        <label class="text-xs font-bold text-slate-500 block mb-2">补全手机号 (必填)</label>
                        <input v-model="clientPhone" type="tel" class="w-full bg-slate-50 border border-gray-200 rounded-lg p-3 text-sm outline-none" placeholder="请输入客户手机号" required>
                    </div>
                    <label class="text-xs font-bold text-slate-500 block mb-2">房号 (选填)</label><input v-model="roomNumber" class="w-full bg-slate-50 border border-gray-200 rounded-lg p-3 text-sm outline-none mb-3" placeholder="如: 1栋2单元301">
                    <div class="bg-purple-50 rounded-2xl p-4 border border-purple-100 mb-3"><div class="flex justify-between text-xs text-purple-500 font-bold mb-2"><span><i class="fas fa-microphone mr-1"></i> 备注 (选填)</span></div><textarea v-model="voiceText" placeholder="补充说明..." class="w-full bg-white rounded-xl p-2 h-16 border border-purple-100 text-xs resize-none outline-none"></textarea></div>
                    <div class="border-2 border-dashed border-slate-200 rounded-xl p-4 bg-slate-50"><div v-if="attachmentList.length === 0" class="text-center py-4 relative cursor-pointer"><i class="fas fa-file-invoice text-slate-300 text-xl mb-1"></i><p class="text-xs text-slate-400">上传单据 (选填)</p><input type="file" @change="handleFile" multiple class="absolute inset-0 opacity-0 w-full h-full"></div><div v-else class="grid grid-cols-3 gap-2"><div v-for="(url, idx) in attachmentList" :key="idx" class="relative aspect-square rounded-lg overflow-hidden border border-gray-200"><img :src="url" class="w-full h-full object-cover"><div @click="removeAttachment(idx)" class="absolute top-0 right-0 bg-red-500 text-white w-5 h-5 flex items-center justify-center rounded-bl-lg text-[10px] cursor-pointer">×</div></div><div class="relative aspect-square rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center bg-white"><i class="fas fa-plus text-gray-300"></i><input type="file" @change="handleFile" multiple class="absolute inset-0 opacity-0 w-full h-full"></div></div></div>
                </div>
                <div v-if="currentItem.status==3">
                    <div class="bg-green-50 rounded-xl p-4 border border-green-100 mb-3"><label class="text-xs font-bold text-green-600 block mb-2"><i class="fas fa-user mr-1"></i> 认购人姓名</label><input v-model="subscriberName" type="text" class="w-full bg-white border border-green-200 rounded-lg p-3 text-sm font-bold outline-none" :placeholder="currentItem.client_name"></div>
                    <div class="bg-green-50 rounded-xl p-4 border border-green-100 mb-3"><label class="text-xs font-bold text-green-600 block mb-2"><i class="fas fa-home mr-1"></i> 认购房号</label><input v-model="subscribedRoomNumber" type="text" class="w-full bg-white border border-green-200 rounded-lg p-3 text-sm font-bold outline-none" :placeholder="currentItem.room_number"></div>
                    <div class="bg-green-50 rounded-xl p-4 border border-green-100 mb-3"><label class="text-xs font-bold text-green-600 block mb-2"><i class="fas fa-ruler-combined mr-1"></i> 成交面积 (㎡)</label><input v-model="transactionArea" type="number" step="0.01" class="w-full bg-white border border-green-200 rounded-lg p-3 text-sm font-bold outline-none" placeholder="请输入成交面积"></div>
                    <div class="bg-green-50 rounded-xl p-4 border border-green-100 mb-3"><label class="text-xs font-bold text-green-600 block mb-2"><i class="fas fa-user-tie mr-1"></i> 销售人员</label><input v-model="salesperson" type="text" class="w-full bg-white border border-green-200 rounded-lg p-3 text-sm font-bold outline-none" placeholder="请输入销售人员姓名"></div>
                    <div class="bg-green-50 rounded-xl p-4 border border-green-100 mb-3"><label class="text-xs font-bold text-green-600 block mb-2"><i class="fas fa-phone mr-1"></i> 认购电话全号</label><input v-model="subscriptionPhoneFull" type="tel" class="w-full bg-white border border-green-200 rounded-lg p-3 text-sm font-bold outline-none" :placeholder="currentItem.client_phone"></div>
                    <div class="bg-green-50 rounded-xl p-4 border border-green-100 mb-3"><label class="text-xs font-bold text-green-600 block mb-2"><i class="fas fa-calendar mr-1"></i> 认购日期</label><input v-model="subscriptionDate" type="date" class="w-full bg-white border border-green-200 rounded-lg p-3 text-sm font-bold outline-none"></div>
                    <div class="bg-green-50 rounded-xl p-4 border border-green-100 mb-3"><label class="text-xs font-bold text-green-600 block mb-2"><i class="fas fa-user-edit mr-1"></i> 成交录入人</label><input v-model="transactionRecorder" type="text" class="w-full bg-white border border-green-200 rounded-lg p-3 text-sm font-bold outline-none" placeholder="请输入录入人姓名"></div>
                    <div class="bg-green-50 rounded-xl p-4 border border-green-100 mb-3"><label class="text-xs font-bold text-green-600 block mb-2"><i class="fas fa-yen-sign mr-1"></i> 成交总价 (必填)</label><input v-model="dealPrice" type="number" class="w-full bg-white border border-green-200 rounded-lg p-3 text-sm font-bold outline-none"></div>
                    <div class="border-2 border-dashed border-slate-200 rounded-xl p-4 bg-slate-50"><div v-if="attachmentList.length === 0" class="text-center py-4 relative cursor-pointer"><i class="fas fa-file-contract text-slate-300 text-xl mb-1"></i><p class="text-xs text-slate-400">上传购房合同 (必填)</p><input type="file" @change="handleFile" multiple class="absolute inset-0 opacity-0 w-full h-full"></div><div v-else class="grid grid-cols-3 gap-2"><div v-for="(url, idx) in attachmentList" :key="idx" class="relative aspect-square rounded-lg overflow-hidden border border-gray-200"><img :src="url" class="w-full h-full object-cover"><div @click="removeAttachment(idx)" class="absolute top-0 right-0 bg-red-500 text-white w-5 h-5 flex items-center justify-center rounded-bl-lg text-[10px] cursor-pointer">×</div></div><div class="relative aspect-square rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center bg-white"><i class="fas fa-plus text-gray-300"></i><input type="file" @change="handleFile" multiple class="absolute inset-0 opacity-0 w-full h-full"></div></div></div>
                </div>
            </div>
            
            <div v-if="currentItem.status==2" class="flex gap-3"><button @click="submitAction('save')" class="flex-1 bg-white border border-slate-200 text-slate-600 py-3 rounded-xl font-bold shadow-sm text-sm active:scale-95 transition">保存进度</button><button @click="submitAction('submit')" class="flex-1 bg-slate-900 text-white py-3 rounded-xl font-bold shadow-lg text-sm active:scale-95 transition">确认去签约</button></div>
            <div v-if="currentItem.status==3" class="flex gap-3 mb-3">
                <button @click="submitAction('submit')" class="flex-1 bg-slate-900 text-white py-3 rounded-xl font-bold shadow-lg text-sm active:scale-95 transition">录入成交</button>
                <button @click="submitAction('refund')" class="flex-1 bg-red-600 text-white py-3 rounded-xl font-bold shadow-lg text-sm active:scale-95 transition">退房</button>
            </div>
            <button v-else-if="currentItem.status==1 || currentItem.status==5 || currentItem.status==6" @click="submitAction('submit')" class="w-full bg-slate-900 text-white py-3 rounded-xl font-bold shadow-lg text-sm mb-3 active:scale-95 transition">确认提交</button>
            <button @click="showModal=false" class="w-full text-gray-400 text-xs py-3 mt-1">取消</button>
        </div>
    </div>
    
    <div v-if="showTime" class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-6" @click.self="showTime=false"><div class="bg-white w-full rounded-2xl p-6 shadow-2xl relative max-h-[70vh] overflow-y-auto"><button @click="showTime=false" class="absolute top-4 right-4 text-gray-400"><i class="fas fa-times"></i></button><h3 class="font-bold text-lg mb-6 text-slate-800">订单全流程</h3><div class="bg-gray-50 p-4 rounded-xl mb-6"><h4 class="font-bold text-sm text-slate-700 mb-3">报备详情</h4><div class="space-y-4">
                <div class="grid grid-cols-1 gap-2">
                    <div><span class="text-gray-500 text-sm">客户姓名:</span> <span class="font-medium text-base ml-2">{{ currentItem.client_name }}</span></div>
                    <div><span class="text-gray-500 text-sm">客户电话:</span> <a :href="'tel:' + currentItem.client_phone" class="text-blue-500 font-medium text-base ml-2">{{ currentItem.client_phone }}</a></div>
                </div>
                <div class="grid grid-cols-2 gap-3 text-xs">
                    <div><span class="text-gray-500">经纪人:</span> <span class="font-medium">{{ currentItem.agent_name || '未知' }}</span></div>
                    <div><span class="text-gray-500">经纪电话:</span> <a :href="'tel:' + currentItem.agent_phone" class="text-blue-500 font-medium">{{ currentItem.agent_phone || '未知' }}</a></div>
                    <div><span class="text-gray-500">项目:</span> <span class="font-medium text-[10px]">{{ currentItem.project_name }}</span></div>
                    <div><span class="text-gray-500">客户意向:</span> <span class="font-medium">
                        {{ currentItem.client_intention == 5 ? '非常强烈' : 
                           currentItem.client_intention == 4 ? '强烈' : 
                           currentItem.client_intention == 2 ? '还行' : 
                           currentItem.client_intention == 1 ? '无意向' : '未设置' }}
                    </span></div>
                    <div><span class="text-gray-500">报备时间:</span> <span class="font-medium">{{ currentItem.created_at }}</span></div>
                </div>
            </div></div><div class="pl-2"><div v-for="(log, idx) in parseLog(currentItem.status_log)" :key="idx" class="timeline-item"><div class="timeline-dot active"></div><div class="text-xs text-gray-400 mb-1">{{ log.time }}</div><div class="text-sm font-bold text-slate-700">{{ log.title }}</div><div v-if="log.desc" class="text-xs text-slate-500 bg-slate-50 p-2 rounded mt-1">{{ log.desc }}</div></div></div></div></div>
    
    <!-- 待处理提示弹窗 -->
    <div v-if="showPendingModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-6" @click.self="handlePendingModal('confirm')">
        <div class="bg-white w-full rounded-2xl p-6 shadow-2xl max-h-[80vh] overflow-y-auto">
            <div class="text-center mb-4">
                <h3 class="font-bold text-lg text-slate-800 mb-2">您有 {{ pendingItems.length }} 个待处理项目</h3>
                <p class="text-xs text-gray-400">请尽快处理以下项目</p>
            </div>
            <div class="space-y-3 mb-6 max-h-[40vh] overflow-y-auto">
                <div v-for="item in pendingItems" :key="item.id" class="bg-gray-50 p-3 rounded-xl">
                    <div class="flex justify-between items-start">
                        <div class="flex-1">
                            <div class="font-bold text-sm text-slate-800">{{ item.project_name }}</div>
                            <div class="text-xs text-gray-400 mt-1">客户: {{ item.client_name }}</div>
                        </div>
                        <div class="text-right">
                            <div class="text-xs text-orange-500 font-bold">{{ calculateTimeAgo(item.created_at) }}</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="space-y-3">
                <button @click="handlePendingModal('confirm')" class="w-full bg-purple-600 text-white py-3 rounded-xl font-bold shadow-lg text-sm active:scale-95 transition">确定</button>
                <div class="grid grid-cols-2 gap-3">
                    <button @click="handlePendingModal('1hour')" class="flex-1 bg-white border border-slate-200 text-slate-600 py-3 rounded-xl font-bold shadow-sm text-sm active:scale-95 transition">1小时不再提醒</button>
                    <button @click="handlePendingModal('day')" class="flex-1 bg-white border border-slate-200 text-slate-600 py-3 rounded-xl font-bold shadow-sm text-sm active:scale-95 transition">当天不再提醒</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const { createApp, ref, computed, onMounted, nextTick, watch } = Vue;
createApp({
    setup() {
        const tab = ref('work');
        const subTab = ref(0);
        const childFilter = ref('todo'); 
        const list = ref([]);
        const stats = ref({});
        const projects = ref([]);
        const workSearch = ref('');
        const historySearch = ref(''); // 新增：历史记录搜索
        const showModal = ref(false);
        const showTime = ref(false);
        const showPendingModal = ref(false);
        const pendingItems = ref([]);
        const currentItem = ref({});
        const voiceText = ref('');
        const roomNumber = ref('');
        const dealPrice = ref('');
        const visitType = ref(1);
        const clientIntention = ref(0);
        const subStages = ref([]); 
        const attachmentList = ref([]); 
        const recording = ref(false);
        const clientPhone = ref('');
        const subscriberName = ref('');
        const subscribedRoomNumber = ref('');
        const transactionArea = ref('');
        const salesperson = ref('');
        const subscriptionPhoneFull = ref('');
        const subscriptionDate = ref('');
        const transactionRecorder = ref('');
        const currentDate = ref(new Date().toLocaleDateString('zh-CN', {month:'long', day:'numeric', weekday:'long'}));
        const showFilters = ref(false);
        const isSearchingHistory = ref(false);
        const filters = ref({ dateStart: '', dateEnd: '', project: '', clientName: '', clientPhone: '', brokerName: '' });

        const tabs = [{id: 0, name: '全部'}, {id: 1, name: '待接待'}, {id: 2, name: '待下定'}, {id: 3, name: '待签约'}, {id: 4, name: '已完成'}];

        const counts = computed(() => {
            const c = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0};
            list.value.forEach(i => { c[0]++; if (c[i.status] !== undefined) c[i.status]++; });
            return c;
        });

        // 工作台筛选
        const filteredWorkList = computed(() => {
            let res = list.value;
            
            // 检查是否有日期过滤
            const hasDateFilter = filters.value.dateStart || filters.value.dateEnd;
            
            // 如果没有日期过滤，才应用状态筛选
            if (!hasDateFilter) {
                // 应用子筛选
                if (subTab.value === 1) {
                    if (childFilter.value === 'todo') {
                        res = res.filter(i => i.status == 1 && (!i.visit_type || i.visit_type != 0));
                    } else if (childFilter.value === 'valid_report') {
                        res = res.filter(i => i.status == 1 && i.visit_type == 0);
                    } else if (childFilter.value === 'valid') {
                        res = res.filter(i => i.status == 2);
                    } else if (childFilter.value === 'invalid_report') {
                        res = res.filter(i => i.status == 6);
                    } else if (childFilter.value === 'invalid_visit') {
                        res = res.filter(i => i.status == 5 && i.visit_type == 2);
                    } else if (childFilter.value === 'repeat') {
                        res = res.filter(i => i.status == 5 && i.visit_type == 3);
                    }
                } else if (subTab.value !== 0 && !(subTab.value === 2 && childFilter.value === 'todo')) {
                    // 其他状态的筛选
                    if (subTab.value === 2 && childFilter.value === 'refund') {
                        res = res.filter(i => i.status == 7);
                    } else {
                        res = res.filter(i => i.status == subTab.value);
                    }
                }
                
                if (subTab.value === 2) {
                    if (childFilter.value !== 'all') {
                        if (childFilter.value === 'todo') {
                            // 待下定状态且客户意向为0且下定进度为空的项目
                            res = res.filter(i => i.status == 2 && i.client_intention == 0 && !i.sub_stages);
                        } else if (childFilter.value !== 'refund') {
                            res = res.filter(i => i.sub_stages && i.sub_stages.includes(childFilter.value));
                        }
                    }
                }
            }
            
            // 应用日期过滤
            const f = filters.value;
            if (f.dateStart && res.length > 0) {
                res = res.filter(item => item.created_at >= f.dateStart);
            }
            if (f.dateEnd && res.length > 0) {
                res = res.filter(item => item.created_at <= f.dateEnd + ' 23:59:59');
            }
            
            // 应用项目过滤
            if (f.project && res.length > 0) {
                res = res.filter(item => item.project_name === f.project);
            }
            
            if(workSearch.value) res = res.filter(i => 
                i.client_phone.includes(workSearch.value) || 
                i.client_name.includes(workSearch.value) ||
                (i.broker_name && i.broker_name.includes(workSearch.value)) ||
                (i.broker_phone && i.broker_phone.includes(workSearch.value)) ||
                (i.agent_name && i.agent_name.includes(workSearch.value)) ||
                (i.agent_phone && i.agent_phone.includes(workSearch.value)) ||
                (i.company_name && i.company_name.includes(workSearch.value)) ||
                (i.company_full_name && i.company_full_name.includes(workSearch.value)) ||
                (i.store_name && i.store_name.includes(workSearch.value))
            );
            return res;
        });

        const groupItems = (items) => {
            const groups = {};
            items.forEach(item => {
                const k = item.client_phone;
                if(!groups[k]) groups[k] = { client_name: item.client_name, client_phone: item.client_phone, items: [] };
                groups[k].items.push(item);
            });
            // 对每个分组内的项目按时间倒序排列
            Object.values(groups).forEach(group => {
                group.items.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
            });
            // 对分组本身按最新项目时间倒序排列
            return Object.values(groups).sort((a, b) => new Date(b.items[0].created_at) - new Date(a.items[0].created_at));
        };

        const pendingCount = computed(() => {
            return list.value.filter(item => {
                // 待下定状态且客户意向为0且下定进度为空的项目
                return item.status == 2 && item.client_intention == 0 && !item.sub_stages;
            }).length;
        });

        const groupedWorkList = computed(() => groupItems(filteredWorkList.value));
        
        // 核心：历史记录全能搜索逻辑
        const filteredList = computed(() => {
            return list.value.filter(item => {
                // 1. 全能搜索 (Keyword)
                const k = historySearch.value.trim();
                if (k) {
                    const statusStr = statusText(item.status);
                    const stageText = (item.sub_stages || '').replace('deposit','交定').replace('lock','锁房').replace('sign','签约');
                    const match = item.client_name.includes(k) || item.client_phone.includes(k) || 
                                  item.project_name.includes(k) || (item.agent_name && item.agent_name.includes(k)) ||
                                  statusStr.includes(k) || stageText.includes(k) ||
                                  (item.broker_name && item.broker_name.includes(k)) ||
                                  (item.broker_phone && item.broker_phone.includes(k)) ||
                                  (item.agent_phone && item.agent_phone.includes(k)) ||
                                  (item.company_name && item.company_name.includes(k)) ||
                                  (item.company_full_name && item.company_full_name.includes(k)) ||
                                  (item.store_name && item.store_name.includes(k));
                    if (!match) return false;
                }

                // 2. 既有筛选 (Advanced Filter)
                const f = filters.value;
                if (f.dateStart && item.created_at < f.dateStart) return false;
                if (f.dateEnd && item.created_at > f.dateEnd + ' 23:59:59') return false;
                if (f.project && item.project_name !== f.project) return false;
                return true;
            });
        });
        const groupedHistoryList = computed(() => groupItems(filteredList.value));

        const getActionText = (status) => ['','确认到访','录入下定','录入成交'][status] || '';

        const calculateTimeAgo = (dateString) => {
            const now = new Date();
            const past = new Date(dateString);
            const diffInSeconds = Math.floor((now - past) / 1000);
            
            if (diffInSeconds < 60) {
                return `${diffInSeconds}秒前`;
            } else if (diffInSeconds < 3600) {
                const minutes = Math.floor(diffInSeconds / 60);
                return `${minutes}分钟前`;
            } else if (diffInSeconds < 86400) {
                const hours = Math.floor(diffInSeconds / 3600);
                return `${hours}小时前`;
            } else {
                const days = Math.floor(diffInSeconds / 86400);
                return `${days}天前`;
            }
        };
        
        const checkPendingItems = () => {
            // 检查本地存储中的提醒设置
            const lastReminder = localStorage.getItem('lastPendingReminder');
            const reminderType = localStorage.getItem('pendingReminderType');
            
            // 如果有提醒设置，检查是否应该显示
            if (lastReminder && reminderType) {
                const now = new Date().getTime();
                const lastTime = parseInt(lastReminder);
                
                if (reminderType === '1hour' && (now - lastTime) < 3600000) {
                    return; // 1小时内不再提醒
                }
                if (reminderType === 'day' && (now - lastTime) < 86400000) {
                    return; // 当天不再提醒
                }
            }
            
            // 过滤出待处理项目（status == 1）
            const pending = list.value.filter(item => item.status == 1);
            if (pending.length > 0) {
                pendingItems.value = pending;
                showPendingModal.value = true;
            }
        };
        
        const handlePendingModal = (action) => {
            const now = new Date().getTime();
            
            switch (action) {
                case '1hour':
                    localStorage.setItem('lastPendingReminder', now.toString());
                    localStorage.setItem('pendingReminderType', '1hour');
                    break;
                case 'day':
                    localStorage.setItem('lastPendingReminder', now.toString());
                    localStorage.setItem('pendingReminderType', 'day');
                    break;
                default:
                    // 确定按钮，清除提醒设置
                    localStorage.removeItem('lastPendingReminder');
                    localStorage.removeItem('pendingReminderType');
            }
            
            showPendingModal.value = false;
        };
        
        const loadData = async () => {
            const res = await fetch('?action=get_list'); list.value = await res.json();
            const sRes = await fetch('?action=get_stats'); stats.value = await sRes.json();
            if(tab.value === 'dash') drawChart();
            const pRes = await fetch('?action=get_projects'); projects.value = await pRes.json();
            // 加载数据后检查待处理项目
            checkPendingItems();
        };

        const searchHistory = async () => {
            const keyword = workSearch.value.trim();
            
            isSearchingHistory.value = true;
            try {
                if(keyword) {
                    const res = await fetch('?action=search_history&keyword=' + encodeURIComponent(keyword));
                    const data = await res.json();
                    list.value = Array.isArray(data) ? data : [];
                    
                    if(list.value.length === 0) {
                        alert('未找到匹配的历史记录');
                    } else {
                        alert(`找到 ${list.value.length} 条历史记录`);
                    }
                } else {
                    // 搜索框为空时，加载全部数据
                    const res = await fetch('?action=get_list');
                    list.value = await res.json();
                }
            } catch (e) {
                alert('搜索失败，请重试');
            } finally {
                isSearchingHistory.value = false;
            }
        };

        const resetFilters = () => {
            filters.value = { dateStart: '', dateEnd: '', project: '', clientName: '', clientPhone: '', brokerName: '' };
            historySearch.value = '';
            isSearchingHistory.value = false;
            loadData();
        };
        
        const applyFilters = () => {
            // 筛选逻辑已经在computed属性中实现，这里只需要关闭筛选面板
            showFilters.value = false;
        };

        const changeMainTab = (id) => {
            subTab.value = id;
            if(id === 1) childFilter.value = 'todo';
            else if(id === 2) childFilter.value = 'all';
        };

        const openModal = (item) => { 
            currentItem.value = item; 
            const s = parseInt(item.status);
            currentItem.value.status = s;
            voiceText.value = ''; roomNumber.value = item.room_number || ''; dealPrice.value = ''; 
            visitType.value = item.visit_type ? parseInt(item.visit_type) : null;
            clientIntention.value = item.client_intention ? parseInt(item.client_intention) : 0;
            subStages.value = item.sub_stages ? item.sub_stages.split(',') : [];
            clientPhone.value = item.client_phone || '';
            subscriberName.value = item.subscriber_name || item.client_name || '';
            subscribedRoomNumber.value = item.subscribed_room_number || item.room_number || '';
            transactionArea.value = item.transaction_area || '';
            salesperson.value = item.salesperson || '';
            subscriptionPhoneFull.value = item.subscription_phone_full || item.client_phone || '';
            subscriptionDate.value = item.subscription_date || new Date().toISOString().split('T')[0];
            transactionRecorder.value = item.transaction_recorder || '<?= $CURRENT_USER ?>';
            if (item.attachments) attachmentList.value = item.attachments.split(',').filter(x => x); else attachmentList.value = [];
            showModal.value = true; 
        };
        const showTimeline = (item) => { currentItem.value = item; showTime.value = true; };
        const toggleStage = (stage) => { if (subStages.value.includes(stage)) subStages.value = subStages.value.filter(s => s !== stage); else subStages.value.push(stage); };
        const markAsInvalid = (item) => {
            if (confirm('确定标记为无效报备吗？')) {
                fetch('?action=update', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        id: item.id,
                        curr_status: 1,
                        visit_type: 4,
                        save_type: 'submit'
                    })
                }).then(r => r.json()).then(d => {
                    if (d.status !== 'error') {
                        alert('标记成功');
                        loadData();
                    } else {
                        alert('标记失败: ' + (d.msg || '未知错误'));
                    }
                }).catch(error => {
                    console.error('标记无效报备时出错:', error);
                    alert('标记失败: 网络错误');
                });
            }
        };

        const markAsInvalidVisit = (item) => {
            if (confirm('确定标记为无效到访吗？')) {
                fetch('?action=update', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        id: item.id,
                        curr_status: 2,
                        visit_type: 2,
                        save_type: 'submit'
                    })
                }).then(r => r.json()).then(d => {
                    if (d.status !== 'error') {
                        alert('标记成功');
                        loadData();
                    } else {
                        alert('标记失败: ' + (d.msg || '未知错误'));
                    }
                }).catch(error => {
                    console.error('标记无效到访时出错:', error);
                    alert('标记失败: 网络错误');
                });
            }
        };
        
        const handleFile = async (e) => { 
            for (let i = 0; i < e.target.files.length; i++) {
                const fd=new FormData(); fd.append('file', e.target.files[i]); 
                const res=await fetch('upload.php',{method:'POST',body:fd}); const d=await res.json(); 
                if(d.status=='success') attachmentList.value.push(d.url); 
            }
        };
        const removeAttachment = (idx) => attachmentList.value.splice(idx, 1);

        const submitAction = async (saveType = 'submit') => {
            const s = parseInt(currentItem.value.status);
            let nextStatus = s + 1;
            if (s === 2) { 
                if (saveType === 'submit' && subStages.value.length < 3) return alert('必须完成所有下定进度才能去签约');
                if (subStages.value.includes('sign') && !clientPhone.value) return alert('请补全手机号');
                nextStatus = 3; 
            }
            if (s === 3) {
                if (saveType === 'submit') {
                    if(!dealPrice.value) return alert('请填写成交总价');
                    if(attachmentList.value.length === 0) return alert('请上传购房合同');
                    nextStatus = 4; 
                } else if (saveType === 'refund') {
                    if(!confirm('确定要退房吗？')) return;
                    nextStatus = 7; // 退房状态
                }
            }
            
            const fd = new FormData(); 
            fd.append('id', currentItem.value.id); fd.append('curr_status', s); fd.append('status', nextStatus); fd.append('save_type', saveType); 
            if(visitType.value !== null) {
                fd.append('visit_type', visitType.value); 
            } else {
                fd.append('visit_type', 'null');
            }
            fd.append('client_intention', clientIntention.value); fd.append('sub_stages', subStages.value.join(',')); fd.append('voice', voiceText.value); 
            fd.append('room_number', roomNumber.value); fd.append('deal_price', dealPrice.value); fd.append('attachment', attachmentList.value.join(','));
            fd.append('client_phone', clientPhone.value);
            fd.append('subscriber_name', subscriberName.value);
            fd.append('subscribed_room_number', subscribedRoomNumber.value);
            fd.append('transaction_area', transactionArea.value);
            fd.append('salesperson', salesperson.value);
            fd.append('subscription_phone_full', subscriptionPhoneFull.value);
            fd.append('subscription_date', subscriptionDate.value);
            fd.append('transaction_recorder', transactionRecorder.value);
            
            const res = await fetch('?action=update', {method:'POST', body:fd}); const d = await res.json();
            if(d.status === 'success') { showModal.value = false; loadData(); } else { alert(d.msg || '操作失败'); }
        };

        const toggleRecord = () => { recording.value = !recording.value; if(!recording.value) voiceText.value="客户反馈良好。"; };
        const simulateScan = () => { workSearch.value=''; document.querySelector('input[placeholder*="输入手机"]').focus(); }; const goToFiling = () => { window.location.href = 'agent.php'; }; const goToCompete = () => { window.location.href = 'compete.php'; };
        const parseLog = (logStr) => { if(!logStr) return []; return logStr.split('\n').filter(l => l.trim()).map(l => { const parts = l.split('] '); return { time: parts[0] ? parts[0].replace('[', '').trim() : '', title: parts[1]?.split(' (')[0] || parts[1], desc: parts[1]?.includes('(') ? parts[1].split('(')[1].replace(')', '') : '' }; }).reverse(); };
        const statusText = (s) => ['待审','有效','到访','下定','成交','无效','报备无效','退房'][s]||'';
        const statusClass = (s) => ['bg-gray-100 text-gray-500 border-gray-200','bg-blue-50 text-blue-600 border-blue-200','bg-yellow-50 text-yellow-600 border-yellow-200','bg-orange-50 text-orange-600 border-orange-200','bg-green-50 text-green-600 border-green-200','bg-red-50 text-red-500 border-red-200','bg-gray-200 text-gray-600 border-gray-300','bg-purple-50 text-purple-600 border-purple-200'][s];
        const commText = (s) => ['待确认','已确认','已发放'][s] || '未知';
        const commColor = (s) => ['text-gray-400','text-blue-500','text-green-500'][s] || '';
        const drawChart = () => { nextTick(()=>{ const d=document.getElementById('funnel'); if(d) echarts.init(d).setOption({series:[{type:'funnel',data:stats.value.funnel}]}); }); };
        const copyFilingData = (item) => { localStorage.setItem('copyFilingData', JSON.stringify(item)); window.location.href = 'agent.php'; };
        
        // 格式化电话号码显示
        const formatPhone = (phone, isAgent = false) => {
            if(!phone) return '';
            
            // 经纪人电话不需要隐藏，直接显示并可点击拨打
            if(isAgent) {
                const cleanPhone = phone.replace(/\D/g, '');
                if(cleanPhone.length >= 11) {
                    return `<a href="tel:${cleanPhone}" class="text-blue-500">${phone}</a>`;
                } else {
                    return `<a href="tel:${cleanPhone}" class="text-blue-500">${phone}</a>`;
                }
            }
            
            // 客户电话处理
            const cleanPhone = phone.replace(/\D/g, '');
            if(cleanPhone.length === 11) {
                // 11位全号，直接显示并可点击拨打
                return `<a href="tel:${cleanPhone}" class="text-blue-500">${phone}</a>`;
            } else if(cleanPhone.length > 7) {
                // 其他长度，显示前三后四位中间为星号
                return `${cleanPhone.substring(0,3)}****${cleanPhone.substring(cleanPhone.length-4)}`;
            } else {
                // 短电话，直接显示
                return phone;
            }
        };

        watch(tab, (v) => { 
            if(v==='dash') loadData(); 
            else if(v==='work' && !isSearchingHistory.value) loadData();
        });
        watch(subTab, (v) => {
            if(v===2 && pendingCount.value > 0) {
                alert(`您有${pendingCount.value}条待办事项需要处理！`);
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();
                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);
                oscillator.frequency.value = 800;
                oscillator.type = 'sine';
                gainNode.gain.value = 0.1;
                oscillator.start();
                setTimeout(() => {
                    oscillator.stop();
                    audioContext.close();
                }, 200);
            }
        });
        onMounted(() => {
            childFilter.value = 'todo';
            loadData();
        });

        return {
            tab, subTab, childFilter, list, groupedWorkList, filteredList, groupedHistoryList, showModal, showTime, showPendingModal, pendingItems, pendingCount, currentItem, 
            voiceText, roomNumber, dealPrice, workSearch, historySearch, stats, currentDate, clientPhone,
            subscriberName, subscribedRoomNumber, transactionArea, salesperson, subscriptionPhoneFull, subscriptionDate, transactionRecorder,
            showFilters, filters, projects, visitType, clientIntention, subStages, attachmentList, recording, isSearchingHistory,
            openModal, showTimeline, submitAction, handleFile, simulateScan, goToFiling, goToCompete, parseLog, commText, commColor, toggleRecord, removeAttachment, copyFilingData, searchHistory, markAsInvalid, markAsInvalidVisit,
            tabs, counts, getActionText, statusText, statusClass, resetFilters, applyFilters, toggleStage, changeMainTab,
            calculateTimeAgo, checkPendingItems, handlePendingModal, formatPhone
        }
    }
}).mount('#app');
</script>
</body>
</html>